/** @type {import('tailwindcss').Config} */
export default {
  content: [
    "./index.html",
    "./src/**/*.{js,ts,jsx,tsx}",
  ],
  darkMode: 'class',
  theme: {
    extend: {
      colors: {
        // Dark-mode base — rich plum/aubergine, not just desaturated near-black
        ink: {
          950: '#150b26',
          900: '#1e1236',
          850: '#2a1849',
          800: '#37205f',
          700: '#472a79',
          line: '#e7d9ff', // lavender-tinted hairline/border on dark surfaces
        },
        // Light-mode base (violet-tinted paper)
        paper: {
          50: '#f6f1ff',
          100: '#ece0ff',
          200: '#dcc8fb',
          line: '#170f28', // near-black plum hairline/border on light surfaces
        },
        // Off-white / off-black text extremes
        bone: '#f8f3ff',
        soot: '#170f28',
        // Brand accent — violet, reserved for primary actions/focus/links
        violet: {
          100: '#efe6ff',
          200: '#ddc9ff',
          300: '#c7a8fd',
          400: '#ab7ef9',
          500: '#8b4ff2',
          600: '#7333d6',
          700: '#5a20ad',
          800: '#481b89',
        },
        // Secondary accent — hot magenta "flare", used sparingly for pop/highlight,
        // never for risk meaning (kept fully separate from the risk scale below)
        flare: {
          100: '#ffe3f3',
          200: '#ffbde3',
          300: '#ff8ed0',
          400: '#ff5cbb',
          500: '#ff2ea8',
          600: '#e01490',
          700: '#b80b73',
        },
        // Semantic risk colors — reserved strictly for risk indicators
        risk: {
          low: '#22c55e',
          'low-ink': '#04160c',
          medium: '#f5b400',
          'medium-ink': '#241a00',
          high: '#f97316',
          'high-ink': '#2b1200',
          critical: '#ef4444',
          'critical-ink': '#2a0505',
        },
      },
      fontFamily: {
        display: ['"Space Grotesk"', 'sans-serif'],
        mono: ['"JetBrains Mono"', '"Fira Code"', 'SF Mono', 'Consolas', 'monospace'],
        sans: ['"JetBrains Mono"', 'monospace'],
      },
      borderWidth: {
        3: '3px',
      },
      borderRadius: {
        none: '0px',
        sm: '2px',
        DEFAULT: '2px',
        md: '3px',
        lg: '4px',
      },
      boxShadow: {
        // Hard offset shadows — no blur. Color is set via CSS var per theme.
        'brutal-sm': '3px 3px 0 0 var(--shadow-color)',
        brutal: '5px 5px 0 0 var(--shadow-color)',
        'brutal-lg': '8px 8px 0 0 var(--shadow-color)',
        'brutal-press': '1px 1px 0 0 var(--shadow-color)',
        'brutal-violet': '5px 5px 0 0 #8b4ff2',
        'brutal-flare': '5px 5px 0 0 #ff2ea8',
      },
      transitionTimingFunction: {
        brutal: 'linear',
      },
    },
  },
  plugins: [],
}
