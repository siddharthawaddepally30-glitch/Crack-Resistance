import React, { createContext, useContext, useState, useCallback } from 'react';
import type { NavigationStep, PersonalInfoState } from '../types';
import type { AnalysisResult } from '../analysis/types';

interface AnalysisContextType {
  currentStep: NavigationStep;
  setStep: (step: NavigationStep) => void;
  personalInfo: PersonalInfoState;
  updatePersonalInfo: (fields: Partial<PersonalInfoState>) => void;
  clearPersonalInfo: () => void;
  passwordInput: string;
  setPasswordInput: (password: string) => void;
  analysisResult: AnalysisResult | null;
  setAnalysisResult: (result: AnalysisResult | null) => void;
  isAnalyzing: boolean;
  setIsAnalyzing: (value: boolean) => void;
  analysisError: string | null;
  setAnalysisError: (value: string | null) => void;
  clearSession: () => void;
  isEphemeralActive: boolean;
}

const AnalysisContext = createContext<AnalysisContextType | undefined>(undefined);

export const AnalysisProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [currentStep, setCurrentStep] = useState<NavigationStep>('landing');
  const [personalInfo, setPersonalInfo] = useState<PersonalInfoState>({});
  const [passwordInput, setPasswordInput] = useState<string>('');
  const [analysisResult, setAnalysisResult] = useState<AnalysisResult | null>(null);
  const [isAnalyzing, setIsAnalyzing] = useState(false);
  const [analysisError, setAnalysisError] = useState<string | null>(null);

  const updatePersonalInfo = useCallback((fields: Partial<PersonalInfoState>) => {
    setPersonalInfo((prev) => ({ ...prev, ...fields }));
  }, []);

  const clearPersonalInfo = useCallback(() => {
    setPersonalInfo({});
  }, []);

  const clearSession = useCallback(() => {
    setPersonalInfo({});
    setPasswordInput('');
    setAnalysisResult(null);
    setIsAnalyzing(false);
    setAnalysisError(null);
    setCurrentStep('landing');
  }, []);

  const isEphemeralActive =
    Object.keys(personalInfo).length > 0 || passwordInput.length > 0 || analysisResult !== null;

  return (
    <AnalysisContext.Provider
      value={{
        currentStep,
        setStep: setCurrentStep,
        personalInfo,
        updatePersonalInfo,
        clearPersonalInfo,
        passwordInput,
        setPasswordInput,
        analysisResult,
        setAnalysisResult,
        isAnalyzing,
        setIsAnalyzing,
        analysisError,
        setAnalysisError,
        clearSession,
        isEphemeralActive,
      }}
    >
      {children}
    </AnalysisContext.Provider>
  );
};

export const useAnalysis = () => {
  const context = useContext(AnalysisContext);
  if (!context) {
    throw new Error('useAnalysis must be used within an AnalysisProvider');
  }
  return context;
};
