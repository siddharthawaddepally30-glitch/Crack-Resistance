// TypeScript type definitions for Crack Resistance

import type { AnalysisResult } from '../analysis/types';

export type NavigationStep = 'landing' | 'personal-info' | 'password-input' | 'pattern-analysis' | 'personal-analysis' | 'attack-simulation' | 'unrelatedness' | 'report' | 'recommendation';

export interface PersonalInfoState {
  // Identity
  firstName?: string;
  lastName?: string;
  nickname?: string;
  initials?: string;
  usernameAlias?: string;

  // Important Dates
  dateOfBirth?: string;
  birthYear?: string;
  importantDates?: string;
  importantYears?: string;
  graduationYear?: string;

  // Relationships
  partner?: string;
  familyMembers?: string;
  closeFriends?: string;

  // Pets
  petNames?: string;
  petTerms?: string;

  // Geography
  city?: string;
  town?: string;
  country?: string;
  previousLocations?: string;

  // Education
  school?: string;
  college?: string;
  university?: string;
  degreeBranch?: string;

  // Work
  company?: string;
  workplace?: string;
  jobTitle?: string;

  // Interests
  hobbies?: string;
  sports?: string;
  sportsTeams?: string;
  games?: string;
  movies?: string;
  artists?: string;
  books?: string;
  characters?: string;
  otherInterests?: string;

  // Digital Identity
  gamingNames?: string;
  onlineAliases?: string;

  // Other meaningful terms
  otherTerms?: string;
}

export interface AnalysisState {
  currentStep: NavigationStep;
  personalInfo: PersonalInfoState;
  passwordInput: string;
  isAnalyzing: boolean;
  hasAnalyzed: boolean;
  analysisError: string | null;
  result: AnalysisResult | null;
}
