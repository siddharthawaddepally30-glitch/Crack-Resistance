import React from 'react';

export const Footer: React.FC = () => {
  return (
    <footer className="w-full border-t-3 border-paper-line dark:border-ink-line bg-paper-50 dark:bg-ink-950 mt-24 py-12 text-soot dark:text-bone">
      <div className="max-w-7xl mx-auto px-6">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-12 mb-12">

          {/* Col 1 */}
          <div className="md:col-span-2 space-y-4">
            <div className="flex items-center gap-2">
              <span className="font-display font-bold text-sm tracking-wide">
                Crack Resistance
              </span>
            </div>
            <p className="text-sm text-soot/70 dark:text-bone/60 leading-relaxed max-w-md">
              An educational security analysis tool demonstrating how personal patterns can make passwords predictable to targeted attackers.
            </p>
          </div>

          {/* Col 2 */}
          <div className="space-y-4">
            <div className="text-xs font-mono font-bold uppercase tracking-wide text-violet-600 dark:text-violet-400">
              Intelligence Stages
            </div>
            <ul className="space-y-2 text-sm text-soot/70 dark:text-bone/60">
              <li className="hover:text-violet-600 dark:hover:text-violet-400 transition-colors">
                Generic Risk Intelligence
              </li>
              <li className="hover:text-violet-600 dark:hover:text-violet-400 transition-colors">
                Pattern & Grammar Intelligence
              </li>
              <li className="hover:text-violet-600 dark:hover:text-violet-400 transition-colors">
                Personalized Guessability
              </li>
              <li className="hover:text-violet-600 dark:hover:text-violet-400 transition-colors">
                Targeted Attack Simulation
              </li>
            </ul>
          </div>

        </div>

        {/* Bottom Bar */}
        <div className="pt-8 border-t-2 border-paper-line dark:border-ink-line flex flex-col sm:flex-row items-center justify-between gap-4 text-xs font-mono">
          <div className="flex items-center gap-4 text-soot/60 dark:text-bone/50">
            <span>Educational Security Analysis</span>
          </div>
          <div className="flex items-center gap-2 text-soot/60 dark:text-bone/50">
            <i className="ti ti-lock" aria-hidden="true" />
            <span>Zero Persistent Storage</span>
          </div>
        </div>

      </div>
    </footer>
  );
};
