import React from 'react';
import { useAnalysis } from '../../context/AnalysisContext';
import { Button } from '../ui/Button';
import { ThemeToggle } from '../ui/ThemeToggle';

export const Navbar: React.FC = () => {
  const { currentStep, setStep, isEphemeralActive, clearSession } = useAnalysis();

  return (
    <header className="sticky top-0 z-50 w-full bg-paper-50 dark:bg-ink-950 border-b-3 border-paper-line dark:border-ink-line">
      <div className="max-w-7xl mx-auto px-6 h-16 flex items-center justify-between gap-4">

        {/* Brand — text-only wordmark */}
        <div
          onClick={() => setStep('landing')}
          className="cursor-pointer select-none group flex items-center gap-2"
        >
          <span className="font-display font-bold text-lg tracking-tight text-soot dark:text-bone">
            Crack<span className="text-violet-600 dark:text-violet-400">Resistance</span>
          </span>
        </div>

        {/* Status & Navigation */}
        <div className="flex items-center gap-2.5">
          {/* Privacy Session Indicator */}
          <div className="hidden md:flex items-center gap-2 px-3 py-1.5 border-2 border-paper-line dark:border-ink-line bg-white dark:bg-ink-900">
            <i className="ti ti-shield-lock text-violet-600 dark:text-violet-400" style={{ fontSize: '14px' }} aria-hidden="true" />
            <span className="text-[11px] font-mono font-bold uppercase tracking-wide text-soot dark:text-bone">
              Zero Persistent Storage
            </span>
          </div>

          <ThemeToggle />

          {isEphemeralActive && (
            <Button
              variant="ghost"
              size="sm"
              icon={<i className="ti ti-refresh" aria-hidden="true" />}
              onClick={clearSession}
              title="Wipe all ephemeral personal info and candidate passwords from memory"
            >
              Reset
            </Button>
          )}

          {currentStep === 'landing' ? (
            <Button variant="primary" size="sm" onClick={() => setStep('personal-info')}>
              Start Analysis
            </Button>
          ) : (
            <Button variant="secondary" size="sm" onClick={() => setStep('landing')}>
              Overview
            </Button>
          )}
        </div>

      </div>
    </header>
  );
};
