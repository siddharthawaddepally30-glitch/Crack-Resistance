import React, { useState } from 'react';
import { ScrollPicker } from './ScrollPicker';

export interface ScrollDatePickerProps {
  label?: string;
  value?: string; // ISO 'YYYY-MM-DD'
  onChange: (isoDate: string) => void;
  startYear?: number;
  endYear?: number;
}

const MONTHS = ['JAN', 'FEB', 'MAR', 'APR', 'MAY', 'JUN', 'JUL', 'AUG', 'SEP', 'OCT', 'NOV', 'DEC'];

const daysInMonth = (monthIndex: number, year: number) => new Date(year, monthIndex + 1, 0).getDate();

const CURRENT_YEAR = new Date().getFullYear();

export const ScrollDatePicker: React.FC<ScrollDatePickerProps> = ({
  label,
  value,
  onChange,
  startYear = CURRENT_YEAR - 100,
  endYear = CURRENT_YEAR,
}) => {
  const parsed = value ? value.split('-') : undefined;
  const [year, setYear] = useState<string>(parsed?.[0] || String(CURRENT_YEAR - 25));
  const [monthIdx, setMonthIdx] = useState<number>(parsed ? Math.max(0, parseInt(parsed[1], 10) - 1) : 0);
  const [day, setDay] = useState<string>(parsed?.[2] || '01');

  const years: string[] = [];
  for (let y = startYear; y <= endYear; y++) years.push(String(y));

  const maxDay = daysInMonth(monthIdx, parseInt(year, 10));
  const days = Array.from({ length: maxDay }, (_, i) => String(i + 1).padStart(2, '0'));

  const commit = (d: string, mIdx: number, y: string) => {
    const clampedDay = Math.min(parseInt(d, 10), daysInMonth(mIdx, parseInt(y, 10)));
    onChange(`${y}-${String(mIdx + 1).padStart(2, '0')}-${String(clampedDay).padStart(2, '0')}`);
  };

  return (
    <div className="space-y-2">
      {label && (
        <label className="block text-xs font-bold uppercase tracking-wide font-mono text-soot/70 dark:text-bone/60">
          {label}
        </label>
      )}
      <div className="flex items-start gap-3">
        <ScrollPicker
          ariaLabel="Day"
          options={days}
          value={day}
          width="60px"
          onChange={(v) => { setDay(v); commit(v, monthIdx, year); }}
        />
        <ScrollPicker
          ariaLabel="Month"
          options={MONTHS}
          value={MONTHS[monthIdx]}
          width="76px"
          onChange={(v) => { const idx = MONTHS.indexOf(v); setMonthIdx(idx); commit(day, idx, year); }}
        />
        <ScrollPicker
          ariaLabel="Year"
          options={years}
          value={year}
          width="88px"
          onChange={(v) => { setYear(v); commit(day, monthIdx, v); }}
        />
      </div>
    </div>
  );
};
