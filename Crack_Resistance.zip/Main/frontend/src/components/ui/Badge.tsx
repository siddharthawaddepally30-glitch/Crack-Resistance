import React from 'react';

export type BadgeVariant = 'neutral' | 'outline' | 'accent' | 'flare' | 'low' | 'medium' | 'high' | 'critical';

export interface BadgeProps {
  children: React.ReactNode;
  variant?: BadgeVariant;
  className?: string;
  icon?: React.ReactNode;
}

// Risk levels get dedicated, non-brand colors so risk meaning is never
// diluted by the violet accent used for ordinary UI actions.
const variantStyles: Record<BadgeVariant, string> = {
  neutral: 'bg-paper-100 text-soot dark:bg-ink-800 dark:text-bone border-paper-line dark:border-ink-line',
  outline: 'bg-transparent text-soot dark:text-bone border-paper-line dark:border-ink-line',
  accent: 'bg-violet-500 text-soot border-paper-line dark:border-ink-line',
  flare: 'bg-flare-500 text-soot border-paper-line dark:border-ink-line',
  low: 'bg-risk-low text-risk-low-ink border-paper-line dark:border-ink-line',
  medium: 'bg-risk-medium text-risk-medium-ink border-paper-line dark:border-ink-line',
  high: 'bg-risk-high text-risk-high-ink border-paper-line dark:border-ink-line',
  critical: 'bg-risk-critical text-white border-paper-line dark:border-ink-line',
};

export const Badge: React.FC<BadgeProps> = ({
  children,
  variant = 'neutral',
  className = '',
  icon,
}) => {
  return (
    <span
      className={`
        inline-flex items-center gap-1.5 px-3 py-1.5
        border-2 text-xs font-mono font-bold tracking-wide uppercase
        ${variantStyles[variant]} ${className}
      `}
    >
      {icon && <span className="shrink-0 inline-flex" aria-hidden="true">{icon}</span>}
      {children}
    </span>
  );
};
