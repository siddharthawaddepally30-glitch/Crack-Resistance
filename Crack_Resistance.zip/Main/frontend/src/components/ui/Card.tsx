import React from 'react';

export interface CardProps extends React.HTMLAttributes<HTMLDivElement> {
  children: React.ReactNode;
  interactive?: boolean;
  className?: string;
  accent?: boolean;
}

export const Card: React.FC<CardProps> = ({
  children,
  interactive = false,
  accent = false,
  className = '',
  ...props
}) => {
  return (
    <div
      className={`
        relative bg-white dark:bg-ink-900
        border-3 ${accent ? 'border-violet-500' : 'border-paper-line dark:border-ink-line'}
        p-6
        shadow-brutal
        transition-[transform,box-shadow] duration-100 ease-brutal
        ${interactive ? 'cursor-pointer hover:shadow-brutal-press hover:translate-x-[5px] hover:translate-y-[5px]' : ''}
        ${className}
      `}
      {...props}
    >
      {children}
    </div>
  );
};
