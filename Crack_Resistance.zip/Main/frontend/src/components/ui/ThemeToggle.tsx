import React from 'react';
import { useTheme } from '../../context/ThemeContext';

export const ThemeToggle: React.FC<{ className?: string }> = ({ className = '' }) => {
  const { theme, toggleTheme } = useTheme();
  const isLight = theme === 'light';

  return (
    <button
      type="button"
      onClick={toggleTheme}
      aria-label={isLight ? 'Switch to dark mode' : 'Switch to light mode'}
      title={isLight ? 'Switch to dark mode' : 'Switch to light mode'}
      className={`
        inline-flex items-center justify-center w-9 h-9 shrink-0
        bg-white border-2 border-paper-line text-soot
        dark:bg-ink-900 dark:border-ink-line dark:text-bone
        shadow-brutal-sm hover:shadow-brutal-press hover:translate-x-[3px] hover:translate-y-[3px]
        active:shadow-none active:translate-x-[4px] active:translate-y-[4px]
        transition-[transform,box-shadow] duration-100 ease-brutal
        ${className}
      `}
    >
      <i className={isLight ? 'ti ti-moon' : 'ti ti-sun'} style={{ fontSize: '18px' }} aria-hidden="true" />
    </button>
  );
};
