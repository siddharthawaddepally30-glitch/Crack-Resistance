import React, { useRef, useEffect, useState, useCallback } from 'react';

export interface ScrollPickerProps {
  options: string[];
  value?: string;
  onChange: (value: string) => void;
  itemHeight?: number;
  visibleCount?: number; // should be odd, so one item sits dead-center
  width?: string;
  ariaLabel?: string;
}

/**
 * A scroll-driven wheel picker (iOS-style) built on native CSS scroll-snap —
 * no external date/picker library needed. Mouse wheel, trackpad, touch drag,
 * the up/down buttons, and arrow keys all move the selection.
 */
export const ScrollPicker: React.FC<ScrollPickerProps> = ({
  options,
  value,
  onChange,
  itemHeight = 36,
  visibleCount = 5,
  width = '84px',
  ariaLabel,
}) => {
  const containerRef = useRef<HTMLDivElement>(null);
  const scrollTimeout = useRef<ReturnType<typeof setTimeout> | null>(null);
  const hasMounted = useRef(false);

  const [activeIndex, setActiveIndex] = useState(() => {
    const idx = value ? options.indexOf(value) : -1;
    return idx >= 0 ? idx : 0;
  });

  const padding = (itemHeight * (visibleCount - 1)) / 2;
  const viewportHeight = itemHeight * visibleCount;

  const scrollToIndex = useCallback((index: number, smooth = true) => {
    const el = containerRef.current;
    if (!el) return;
    el.scrollTo({ top: index * itemHeight, behavior: smooth ? 'smooth' : 'auto' });
  }, [itemHeight]);

  // Set initial scroll position once, without animation
  useEffect(() => {
    if (hasMounted.current) return;
    hasMounted.current = true;
    scrollToIndex(activeIndex, false);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  // Re-sync if the value changes from outside (e.g. parent resets the form)
  useEffect(() => {
    if (!hasMounted.current) return;
    const idx = value ? options.indexOf(value) : -1;
    if (idx >= 0 && idx !== activeIndex) {
      setActiveIndex(idx);
      scrollToIndex(idx, false);
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [value]);

  const commit = (index: number) => {
    const clamped = Math.max(0, Math.min(options.length - 1, index));
    setActiveIndex(clamped);
    onChange(options[clamped]);
  };

  const handleScroll = () => {
    if (scrollTimeout.current) clearTimeout(scrollTimeout.current);
    scrollTimeout.current = setTimeout(() => {
      const el = containerRef.current;
      if (!el) return;
      const idx = Math.round(el.scrollTop / itemHeight);
      commit(idx);
      scrollToIndex(Math.max(0, Math.min(options.length - 1, idx)));
    }, 120);
  };

  const step = (dir: 1 | -1) => {
    const next = activeIndex + dir;
    commit(next);
    scrollToIndex(Math.max(0, Math.min(options.length - 1, next)));
  };

  const handleKeyDown = (e: React.KeyboardEvent) => {
    if (e.key === 'ArrowUp') { e.preventDefault(); step(-1); }
    if (e.key === 'ArrowDown') { e.preventDefault(); step(1); }
  };

  return (
    <div className="inline-flex flex-col items-center select-none" style={{ width }}>
      <button
        type="button"
        onClick={() => step(-1)}
        aria-label="Previous"
        className="w-full flex items-center justify-center py-1 text-soot/40 dark:text-bone/30 hover:text-violet-600 dark:hover:text-violet-400 transition-colors"
      >
        <i className="ti ti-chevron-up" aria-hidden="true" />
      </button>

      <div
        className="relative w-full border-2 border-paper-line dark:border-ink-line bg-white dark:bg-ink-900"
        style={{ height: viewportHeight }}
      >
        {/* Fixed center-selection band */}
        <div
          className="pointer-events-none absolute left-0 right-0 border-y-2 border-violet-500 bg-violet-500/10 dark:bg-violet-500/15"
          style={{ top: padding, height: itemHeight }}
          aria-hidden="true"
        />
        <div
          ref={containerRef}
          role="listbox"
          tabIndex={0}
          aria-label={ariaLabel}
          onScroll={handleScroll}
          onKeyDown={handleKeyDown}
          className="h-full overflow-y-auto outline-none focus-visible:outline-none [scrollbar-width:none] [-ms-overflow-style:none] [&::-webkit-scrollbar]:hidden"
          style={{ scrollSnapType: 'y mandatory', paddingTop: padding, paddingBottom: padding }}
        >
          {options.map((opt, i) => (
            <div
              key={`${opt}-${i}`}
              role="option"
              aria-selected={i === activeIndex}
              className={`flex items-center justify-center font-mono text-sm transition-colors ${
                i === activeIndex
                  ? 'text-violet-600 dark:text-violet-400 font-bold'
                  : 'text-soot/35 dark:text-bone/30'
              }`}
              style={{ height: itemHeight, scrollSnapAlign: 'center' }}
            >
              {opt}
            </div>
          ))}
        </div>
      </div>

      <button
        type="button"
        onClick={() => step(1)}
        aria-label="Next"
        className="w-full flex items-center justify-center py-1 text-soot/40 dark:text-bone/30 hover:text-violet-600 dark:hover:text-violet-400 transition-colors"
      >
        <i className="ti ti-chevron-down" aria-hidden="true" />
      </button>
    </div>
  );
};
