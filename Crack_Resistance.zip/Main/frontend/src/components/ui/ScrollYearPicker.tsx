import React from 'react';
import { ScrollPicker } from './ScrollPicker';

export interface ScrollYearPickerProps {
  label?: string;
  value?: string;
  onChange: (year: string) => void;
  startYear?: number;
  endYear?: number;
}

const CURRENT_YEAR = new Date().getFullYear();

export const ScrollYearPicker: React.FC<ScrollYearPickerProps> = ({
  label,
  value,
  onChange,
  startYear = CURRENT_YEAR - 100,
  endYear = CURRENT_YEAR,
}) => {
  const years: string[] = [];
  for (let y = startYear; y <= endYear; y++) years.push(String(y));

  return (
    <div className="space-y-2">
      {label && (
        <label className="block text-xs font-bold uppercase tracking-wide font-mono text-soot/70 dark:text-bone/60">
          {label}
        </label>
      )}
      <ScrollPicker ariaLabel={label || 'Year'} options={years} value={value} onChange={onChange} width="96px" />
    </div>
  );
};
