import React from 'react';

export interface ButtonProps extends React.ButtonHTMLAttributes<HTMLButtonElement> {
  variant?: 'primary' | 'secondary' | 'ghost' | 'danger';
  size?: 'sm' | 'md' | 'lg';
  children: React.ReactNode;
  icon?: React.ReactNode;
}

export const Button: React.FC<ButtonProps> = ({
  variant = 'primary',
  size = 'md',
  children,
  icon,
  className = '',
  ...props
}) => {
  const baseStyles = `
    inline-flex items-center justify-center gap-2 select-none
    font-mono font-bold uppercase tracking-wide
    border-2 whitespace-nowrap
    transition-[transform,box-shadow] duration-100 ease-brutal
    disabled:opacity-40 disabled:cursor-not-allowed disabled:hover:translate-x-0 disabled:hover:translate-y-0
    focus-visible:outline focus-visible:outline-[3px] focus-visible:outline-offset-2
  `;

  const sizeStyles = {
    sm: 'text-xs px-4 py-2',
    md: 'text-sm px-5 py-2.5',
    lg: 'text-base px-7 py-3.5',
  };

  // Every variant shares the same physical "press" behavior: hard shadow at
  // rest, shadow collapses and the button shifts into it on hover/active.
  const pressStyles = `
    shadow-brutal hover:shadow-brutal-press hover:translate-x-[4px] hover:translate-y-[4px]
    active:shadow-none active:translate-x-[5px] active:translate-y-[5px]
  `;

  const variantStyles = {
    primary: 'bg-violet-500 text-soot border-paper-line dark:border-ink-line hover:bg-violet-400',
    secondary: 'bg-white text-soot border-paper-line dark:bg-ink-900 dark:text-bone dark:border-ink-line hover:bg-paper-100 dark:hover:bg-ink-800',
    ghost: 'bg-transparent text-soot dark:text-bone border-dashed border-paper-line dark:border-ink-line shadow-none hover:bg-paper-100 dark:hover:bg-ink-900 hover:translate-x-0 hover:translate-y-0',
    danger: 'bg-risk-critical text-white border-paper-line dark:border-ink-line hover:bg-risk-critical/90',
  };

  const appliedPress = variant === 'ghost' ? '' : pressStyles;

  return (
    <button
      className={`${baseStyles} ${sizeStyles[size]} ${variantStyles[variant]} ${appliedPress} ${className}`}
      {...props}
    >
      {icon && <span className="shrink-0 inline-flex" aria-hidden="true">{icon}</span>}
      {children}
    </button>
  );
};
