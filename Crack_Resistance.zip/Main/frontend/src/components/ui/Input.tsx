import React from 'react';

export interface InputProps extends Omit<React.InputHTMLAttributes<HTMLInputElement>, 'multiline' | 'rows'> {
  label?: string;
  error?: string;
  multiline?: boolean;
  rows?: number;
  type?: string;
  onChange?: (e: React.ChangeEvent<HTMLInputElement> | React.ChangeEvent<HTMLTextAreaElement>) => void;
}

export const Input: React.FC<InputProps> = ({
  label,
  error,
  multiline = false,
  rows = 3,
  type = 'text',
  className = '',
  placeholder,
  value,
  onChange,
  ...props
}) => {
  const fieldStyles = `
    w-full px-4 py-3 font-mono text-sm
    bg-white dark:bg-ink-900
    text-soot dark:text-bone
    placeholder-paper-line/40 dark:placeholder-ink-line/30
    border-2 ${error ? 'border-risk-critical' : 'border-paper-line dark:border-ink-line'}
    outline-none
    transition-[box-shadow] duration-100 ease-brutal
    focus:shadow-brutal-violet
    resize-none
    ${className}
  `;

  return (
    <div className="space-y-2">
      {label && (
        <label className="block text-xs font-bold uppercase tracking-wide font-mono text-soot/70 dark:text-bone/60">
          {label}
        </label>
      )}
      {multiline ? (
        <textarea
          className={fieldStyles}
          rows={rows}
          placeholder={placeholder}
          value={value}
          onChange={onChange}
          {...(props as React.TextareaHTMLAttributes<HTMLTextAreaElement>)}
        />
      ) : (
        <input
          type={type}
          className={fieldStyles}
          placeholder={placeholder}
          value={value}
          onChange={onChange as React.ChangeEventHandler<HTMLInputElement>}
          {...props}
        />
      )}
      {error && (
        <p className="flex items-center gap-1.5 text-xs font-mono font-semibold text-risk-critical">
          <i className="ti ti-alert-triangle" aria-hidden="true" />
          {error}
        </p>
      )}
    </div>
  );
};
