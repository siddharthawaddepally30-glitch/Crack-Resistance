import React from 'react';
import { motion } from 'framer-motion';
import { useAnalysis } from '../context/AnalysisContext';
import { Button } from '../components/ui/Button';
import { Card } from '../components/ui/Card';

export const RecommendationPage: React.FC = () => {
  const { clearSession, setStep } = useAnalysis();

  return (
    <div className="min-h-[80vh] bg-paper-50 dark:bg-ink-950 text-soot dark:text-bone">
      <div className="max-w-4xl mx-auto px-6 pt-10 pb-24">
        <Button variant="ghost" size="sm" icon={<i className="ti ti-arrow-left" aria-hidden="true" />} onClick={() => setStep('report')} className="mb-7">
          Back to report
        </Button>

        <motion.div initial={{ opacity: 0, y: 14 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: .3 }}>
          <div className="mb-8">
            <div className="inline-flex items-center gap-2 font-mono text-[10px] uppercase tracking-widest text-violet-600 dark:text-violet-400 mb-3">
              <i className="ti ti-school" aria-hidden="true" />
              <span>Stage 7 · Recommendation &amp; Education</span>
            </div>
            <h1 className="font-display text-4xl sm:text-5xl font-bold tracking-tight">What should you change?</h1>
            <p className="font-mono text-sm leading-relaxed text-soot/65 dark:text-bone/55 max-w-3xl mt-4">
              Keep the lesson simple: avoid familiar password recipes, reduce obvious links to your life, and make memorability come from a private association.
            </p>
          </div>

          <Card accent>
            <div className="grid gap-4">
              <div>
                <p className="font-display text-xl font-bold">1. Avoid obvious personal clues</p>
                <p className="font-mono text-sm leading-relaxed mt-1 text-soot/65 dark:text-bone/55">Do not build the password around your name, favourite things, important dates, or other details that can be connected back to you.</p>
              </div>
              <div>
                <p className="font-display text-xl font-bold">2. Avoid familiar recipes</p>
                <p className="font-mono text-sm leading-relaxed mt-1 text-soot/65 dark:text-bone/55">A word with a year, 1234, a common symbol, or a keyboard sequence can still be predictable.</p>
              </div>
              <div>
                <p className="font-display text-xl font-bold">3. Use unrelated ideas</p>
                <p className="font-mono text-sm leading-relaxed mt-1 text-soot/65 dark:text-bone/55">Use the Stage 5 exercise to find an idea that is not naturally connected to your personal information.</p>
              </div>
              <div>
                <p className="font-display text-xl font-bold">4. Create the memory privately</p>
                <p className="font-mono text-sm leading-relaxed mt-1 text-soot/65 dark:text-bone/55">Build your own mental association with the unrelated idea. The application does not need to know what that association is.</p>
              </div>
            </div>
          </Card>

          <Card className="mt-6">
            <p className="font-display text-xl font-bold">The application does not generate your final password.</p>
            <p className="font-mono text-sm leading-relaxed mt-2 text-soot/65 dark:text-bone/55">Use what you learned here to create one yourself, using good length and construction choices.</p>
          </Card>

          <div className="mt-8 flex flex-col sm:flex-row justify-between gap-3">
            <Button variant="ghost" onClick={() => setStep('report')} icon={<i className="ti ti-arrow-left" aria-hidden="true" />}>Back to report</Button>
            <Button onClick={clearSession} icon={<i className="ti ti-check" aria-hidden="true" />}>Finish analysis</Button>
          </div>
        </motion.div>
      </div>
    </div>
  );
};
