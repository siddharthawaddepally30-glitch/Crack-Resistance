import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { useAnalysis } from '../context/AnalysisContext';
import { Button } from '../components/ui/Button';
import { Card } from '../components/ui/Card';
import { Badge, type BadgeVariant } from '../components/ui/Badge';
import { Input } from '../components/ui/Input';
import { analyzePassword } from '../services/analyzePassword';
import type { RiskLevel } from '../analysis/types';

const riskBadge: Record<RiskLevel, BadgeVariant> = {
  low: 'low', medium: 'medium', high: 'high', critical: 'critical',
};

const riskLabel: Record<RiskLevel, string> = {
  low: 'LOW', medium: 'MEDIUM', high: 'HIGH', critical: 'CRITICAL',
};

const riskSummary: Record<RiskLevel, string> = {
  low: 'No major weakness was found by the current checks.',
  medium: 'Some predictable choices were found. They are worth fixing.',
  high: 'Several predictable choices make this easier to guess.',
  critical: 'This password has a major weakness and should not be reused.',
};

export const PasswordInputPage: React.FC = () => {
  const {
    personalInfo, passwordInput, setPasswordInput, analysisResult, setAnalysisResult,
    isAnalyzing, setIsAnalyzing, analysisError, setAnalysisError, setStep,
  } = useAnalysis();
  const [showPassword, setShowPassword] = useState(false);

  const handleAnalyze = async () => {
    if (!passwordInput) {
      setAnalysisError('Enter a password first.');
      return;
    }

    setAnalysisError(null);
    setIsAnalyzing(true);
    try {
      const result = await analyzePassword({ password: passwordInput, personalInfo });
      setAnalysisResult(result);
    } catch {
      setAnalysisResult(null);
      setAnalysisError('The analysis could not be completed. Try again.');
    } finally {
      setIsAnalyzing(false);
    }
  };

  const clear = () => {
    setPasswordInput('');
    setAnalysisResult(null);
    setAnalysisError(null);
  };

  return (
    <div className="min-h-[80vh] bg-paper-50 dark:bg-ink-950 text-soot dark:text-bone">
      <div className="max-w-3xl mx-auto px-6 pt-12 pb-24">
        <motion.div initial={{ opacity: 0, y: 14 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.3 }}>
          <Button
            variant="ghost"
            size="sm"
            icon={<i className="ti ti-arrow-left" aria-hidden="true" />}
            onClick={() => setStep('personal-info')}
            className="mb-8"
          >
            Back
          </Button>

          <div className="mb-8">
            <div className="inline-flex items-center gap-2 font-mono text-[10px] uppercase tracking-widest text-violet-600 dark:text-violet-400 mb-3">
              <i className="ti ti-shield-lock" aria-hidden="true" />
              <span>Stage 1 · Password Risk Intelligence</span>
            </div>
            <h1 className="font-display text-4xl sm:text-5xl font-bold tracking-tight">Check your password</h1>
            <p className="font-mono text-sm leading-relaxed text-soot/60 dark:text-bone/50 max-w-2xl mt-3">
              We first examine the password on its own, without using your personal information. This is the generic risk check: common-password use, familiar words, predictable sequences, dates, keyboard paths, repetitions and other common constructions.
            </p>
          </div>

          <Card accent className="space-y-5">
            <div className="flex items-start justify-between gap-4">
              <div>
                <h2 className="font-display text-xl font-bold">Enter password</h2>
                <p className="font-mono text-[11px] text-soot/50 dark:text-bone/40 mt-1">Nothing is saved to localStorage.</p>
              </div>
              <i className="ti ti-lock text-violet-600 dark:text-violet-400 text-xl" aria-hidden="true" />
            </div>

            <div className="relative">
              <Input
                id="password-analysis-input"
                label="Password"
                type={showPassword ? 'text' : 'password'}
                value={passwordInput}
                autoComplete="off"
                spellCheck={false}
                placeholder="Type it here"
                onChange={(event) => setPasswordInput(event.target.value)}
                className="pr-14"
              />
              <button
                type="button"
                onClick={() => setShowPassword((value) => !value)}
                className="absolute right-3 bottom-1 w-9 h-9 flex items-center justify-center border-2 border-paper-line dark:border-ink-line bg-violet-500 text-soot"
                aria-label={showPassword ? 'Hide password' : 'Show password'}
              >
                <i className={`ti ${showPassword ? 'ti-eye-off' : 'ti-eye'}`} aria-hidden="true" />
              </button>
            </div>

            {analysisError && <p className="font-mono text-xs font-bold text-risk-critical">{analysisError}</p>}

            <div className="flex gap-3">
              <Button size="lg" icon={<i className="ti ti-search" aria-hidden="true" />} onClick={handleAnalyze} disabled={isAnalyzing || !passwordInput}>
                {isAnalyzing ? 'Checking...' : 'Check password'}
              </Button>
              <Button variant="ghost" size="lg" onClick={clear} disabled={!passwordInput && !analysisResult}>Clear</Button>
            </div>
          </Card>

          {!analysisResult && (
            <div className="mt-6 border-2 border-paper-line dark:border-ink-line p-5 bg-paper-100 dark:bg-ink-900">
              <div className="flex gap-3 items-start">
                <i className="ti ti-info-circle text-violet-600 dark:text-violet-400 text-lg" aria-hidden="true" />
                <div>
                  <p className="font-display font-bold">What will we check?</p>
                  <p className="font-mono text-xs leading-relaxed text-soot/55 dark:text-bone/45 mt-1">Common passwords, familiar words, dates, sequences, keyboard paths, repetitions, transformations and predictable word-number-symbol patterns. This first check looks at the password itself, without using your personal information.</p>
                </div>
              </div>
            </div>
          )}

          {analysisResult && (
            <motion.div initial={{ opacity: 0, y: 12 }} animate={{ opacity: 1, y: 0 }} className="mt-8 space-y-5">
              <Card accent className="space-y-6">
                <div className="flex flex-col sm:flex-row sm:items-end sm:justify-between gap-4">
                  <div>
                    <p className="font-mono text-[10px] uppercase tracking-widest text-violet-600 dark:text-violet-400">Generic password analysis</p>
                    <h2 className="font-display text-2xl font-bold mt-1">How predictable is it on its own?</h2>
                    <p className="font-mono text-xs leading-relaxed text-soot/55 dark:text-bone/45 mt-2 max-w-xl">This result does not use the personal information you entered. It asks what a general password checker or attacker could learn from the password itself.</p>
                  </div>
                  <div className="shrink-0 border-2 border-paper-line dark:border-ink-line bg-paper-100 dark:bg-ink-850 px-5 py-3 text-center">
                    <div className="font-mono text-[10px] uppercase tracking-widest text-soot/45 dark:text-bone/35">Risk score</div>
                    <div className="font-display text-3xl font-bold leading-none mt-1">{analysisResult.stage1.riskScore}<span className="text-sm text-soot/40 dark:text-bone/30">/100</span></div>
                    <Badge variant={riskBadge[analysisResult.stage1.riskLevel]} className="mt-2">{riskLabel[analysisResult.stage1.riskLevel]}</Badge>
                  </div>
                </div>

                <div className="border-2 border-paper-line dark:border-ink-line bg-white dark:bg-ink-900 p-4">
                  <div className="flex items-start gap-3">
                    <i className="ti ti-shield-search text-violet-600 dark:text-violet-400 text-lg mt-0.5" aria-hidden="true" />
                    <div>
                      <p className="font-display font-bold">{riskLabel[analysisResult.stage1.riskLevel]} generic risk</p>
                      <p className="font-mono text-xs leading-relaxed text-soot/55 dark:text-bone/45 mt-1">{riskSummary[analysisResult.stage1.riskLevel]}</p>
                    </div>
                  </div>
                </div>

                <div>
                  <div className="flex items-center justify-between gap-3 mb-3">
                    <h3 className="font-display font-bold text-lg">What did we find?</h3>
                    <span className="font-mono text-[10px] uppercase tracking-widest text-soot/40 dark:text-bone/30">{analysisResult.stage1.signals.length} key finding{analysisResult.stage1.signals.length === 1 ? '' : 's'}</span>
                  </div>
                  {analysisResult.stage1.signals.length > 0 ? (
                    <div className="space-y-3">
                      {analysisResult.stage1.signals.map((signal) => (
                        <div key={signal.id} className="border-2 border-paper-line dark:border-ink-line p-4 bg-paper-50 dark:bg-ink-850">
                          <div className="flex items-start gap-3">
                            <i className={`ti ${signal.level === 'critical' ? 'ti-alert-triangle' : signal.level === 'high' ? 'ti-alert-circle' : 'ti-info-circle'} text-violet-600 dark:text-violet-400 mt-0.5`} aria-hidden="true" />
                            <div className="min-w-0">
                              <p className="font-display font-bold">{signal.label}</p>
                              <p className="font-mono text-xs leading-relaxed text-soot/60 dark:text-bone/50 mt-1">{signal.explanation}</p>
                              <p className="font-mono text-xs leading-relaxed mt-2"><span className="font-bold">Why it matters:</span> {signal.action}</p>
                            </div>
                          </div>
                        </div>
                      ))}
                    </div>
                  ) : (
                    <div className="border-2 border-paper-line dark:border-ink-line p-4 bg-paper-50 dark:bg-ink-850 font-mono text-xs leading-relaxed">No major generic weakness was identified by the current checks. This does not mean the password is automatically safe, because later stages examine its construction and relationship to your personal information.</div>
                  )}
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                  <div className="border-2 border-paper-line dark:border-ink-line p-4 bg-paper-50 dark:bg-ink-850">
                    <p className="font-mono text-[10px] uppercase tracking-widest text-soot/40 dark:text-bone/30">Common-password check</p>
                    <p className="font-display font-bold mt-1">{analysisResult.stage1.dictionaryMatch ? 'A common password or common base was found' : 'No exact common-password match found'}</p>
                    <p className="font-mono text-[11px] leading-relaxed text-soot/50 dark:text-bone/40 mt-1">Current source: {analysisResult.stage1.datasetStatus === 'project-dataset' ? 'project password dataset' : 'starter common-password and dictionary set'}.</p>
                  </div>
                  <div className="border-2 border-paper-line dark:border-ink-line p-4 bg-paper-50 dark:bg-ink-850">
                    <p className="font-mono text-[10px] uppercase tracking-widest text-soot/40 dark:text-bone/30">Password structure</p>
                    <p className="font-display font-bold mt-1">{analysisResult.stage1.features.length} characters · {analysisResult.stage1.features.wordCount} word-like token{analysisResult.stage1.features.wordCount === 1 ? '' : 's'}</p>
                    <p className="font-mono text-[11px] leading-relaxed text-soot/50 dark:text-bone/40 mt-1">The next stage breaks these components down into specific construction patterns.</p>
                  </div>
                </div>

                <div className="border-2 border-paper-line dark:border-ink-line bg-paper-100 dark:bg-ink-900 p-5">
                  <div className="flex items-start gap-3">
                    <i className="ti ti-bulb text-violet-600 dark:text-violet-400 text-xl mt-0.5" aria-hidden="true" />
                    <div className="min-w-0">
                      <p className="font-mono text-[10px] uppercase tracking-widest text-violet-600 dark:text-violet-400">Useful takeaways from the generic check</p>
                      <h3 className="font-display text-xl font-bold mt-1">What the password itself tells us</h3>
                      <div className="mt-4 grid gap-3 sm:grid-cols-2">
                        {[
                          [`Length`, analysisResult.stage1.features.length >= 16 ? `At ${analysisResult.stage1.features.length} characters, the password has useful length. Length alone does not make a predictable pattern safe.` : `At ${analysisResult.stage1.features.length} characters, length is currently one of the easier weaknesses to improve.`,],
                          [`Character variety`, `${analysisResult.stage1.features.lowercaseCount} lowercase · ${analysisResult.stage1.features.uppercaseCount} uppercase · ${analysisResult.stage1.features.digitCount} digits · ${analysisResult.stage1.features.symbolCount} symbols. Variety helps, but predictable placement can still reduce its benefit.`],
                          [`Repetition`, analysisResult.stage1.features.repeatedCharacterRun >= 3 || analysisResult.stage1.features.repeatedBlockLength >= 2 ? `A repeated run/block was found, so part of the password follows a reusable structure.` : `No strong repeated run or repeated block was found by the current generic checks.`],
                          [`General dictionary exposure`, analysisResult.stage1.features.dictionaryTokenCount > 0 ? `At least one recognisable dictionary token appears in the password, giving a generic attacker a useful starting point.` : `No starter-dictionary token was found, although a larger project dataset can still reveal common vocabulary later.`],
                        ].map(([title, body]) => (
                          <div key={title} className="border-2 border-paper-line dark:border-ink-line p-4 bg-paper-50 dark:bg-ink-850">
                            <p className="font-display font-bold">{title}</p>
                            <p className="font-mono text-xs leading-relaxed text-soot/60 dark:text-bone/50 mt-1">{body}</p>
                          </div>
                        ))}
                      </div>
                    </div>
                  </div>
                </div>
              </Card>

              <Card className="border-dashed space-y-4">
                <div className="flex items-start gap-3">
                  <i className="ti ti-scan text-violet-600 dark:text-violet-400 text-xl" aria-hidden="true" />
                  <div>
                    <p className="font-mono text-[10px] uppercase tracking-widest text-soot/45 dark:text-bone/35">Next: Stage 2</p>
                    <h2 className="font-display text-xl font-bold mt-1">See how the password was built</h2>
                    <p className="font-mono text-xs leading-relaxed text-soot/55 dark:text-bone/45 mt-1">Now that we know the generic risk, we can break the password into its construction patterns and explain why those patterns are predictable.</p>
                  </div>
                </div>
                <Button size="lg" icon={<i className="ti ti-arrow-right" aria-hidden="true" />} onClick={() => setStep('pattern-analysis')}>
                  View pattern analysis
                </Button>
              </Card>
            </motion.div>
          )}
        </motion.div>
      </div>
    </div>
  );
};
