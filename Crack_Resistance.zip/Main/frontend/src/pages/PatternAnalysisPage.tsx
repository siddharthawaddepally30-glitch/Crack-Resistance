import React from 'react';
import { motion } from 'framer-motion';
import { useAnalysis } from '../context/AnalysisContext';
import { Button } from '../components/ui/Button';
import { Card } from '../components/ui/Card';
import { Badge } from '../components/ui/Badge';

const patternGuidance = {
  mixed: {
    title: 'Try a less predictable structure',
    pattern: 'UNRELATED_WORD + UNRELATED_WORD + INTERNAL_SEPARATOR + NON-DATE_TOKEN',
    body: 'Use concepts that do not connect to your life, then make your own private link between them. Avoid names, dates, favourites and familiar suffixes.',
  },
  word: {
    title: 'Break the single-word habit',
    pattern: 'UNRELATED_CONCEPT + UNRELATED_CONCEPT + INTERNAL_SEPARATOR',
    body: 'Instead of changing one familiar word with a capital letter, number or symbol, start with separate concepts that have no obvious link to you.',
  },
  sequence: { title: 'Break the easy-sequence habit', pattern: 'UNRELATED_CONCEPT + INTERNAL_SEPARATOR + UNRELATED_CONCEPT', body: 'Avoid counting runs and keyboard walks. Use separate, unrelated concepts and make the connection memorable only to you.' },
  numeric: {
    title: 'Move away from predictable number blocks',
    pattern: 'UNRELATED_CONCEPT + INTERNAL_SEPARATOR + UNRELATED_CONCEPT',
    body: 'Do not rely on a birth year, date, counting sequence or easy suffix. Build the structure around unrelated concepts instead.',
  },
};

export const PatternAnalysisPage: React.FC = () => {
  const { analysisResult, passwordInput, setStep } = useAnalysis();

  if (!analysisResult) {
    return (
      <div className="min-h-[80vh] bg-paper-50 dark:bg-ink-950 text-soot dark:text-bone">
        <div className="max-w-3xl mx-auto px-6 pt-12 pb-24">
          <Button variant="ghost" icon={<i className="ti ti-arrow-left" aria-hidden="true" />} onClick={() => setStep('password-input')}>Back</Button>
          <Card accent className="mt-8">
            <h1 className="font-display text-3xl font-bold">No analysis yet</h1>
            <p className="font-mono text-sm mt-2 text-soot/60 dark:text-bone/50">Check a password first, then open the detailed pattern analysis.</p>
            <Button className="mt-5" onClick={() => setStep('password-input')}>Go to password check</Button>
          </Card>
        </div>
      </div>
    );
  }

  const findings = analysisResult.stage2.findings;
  const hasWord = findings.some((f) => f.construction.includes('WORD') || f.category === 'Capitalization');
  const hasNumeric = findings.some((f) => f.category === 'Numbers' || f.construction.includes('NUMBER') || f.construction.includes('YEAR'));
  const hasSequence = findings.some((f) => f.category === 'Sequence' || f.category === 'Keyboard');
  const guidance = hasSequence ? patternGuidance.sequence : hasNumeric ? patternGuidance.numeric : hasWord ? patternGuidance.word : patternGuidance.mixed;

  return (
    <div className="min-h-[80vh] bg-paper-50 dark:bg-ink-950 text-soot dark:text-bone">
      <div className="max-w-4xl mx-auto px-6 pt-10 pb-24">
        <Button variant="ghost" size="sm" icon={<i className="ti ti-arrow-left" aria-hidden="true" />} onClick={() => setStep('password-input')} className="mb-7">Back</Button>

        <motion.div initial={{ opacity: 0, y: 14 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.3 }}>
          <div className="mb-8">
            <div className="inline-flex items-center gap-2 font-mono text-[10px] uppercase tracking-widest text-violet-600 dark:text-violet-400 mb-3">
              <i className="ti ti-scan" aria-hidden="true" />
              <span>Stage 2 · Pattern Intelligence</span>
            </div>
            <h1 className="font-display text-4xl sm:text-5xl font-bold tracking-tight">How was it built?</h1>
            <p className="font-mono text-sm leading-relaxed text-soot/60 dark:text-bone/50 max-w-2xl mt-3">We break the password into simple building blocks so you can see which choices are easy to predict.</p>
          </div>

          <Card className="mb-5 space-y-4">
            <div className="flex items-center justify-between gap-4">
              <div>
                <p className="font-mono text-[10px] uppercase tracking-widest text-soot/45 dark:text-bone/35">Password under review</p>
                <p className="font-mono text-lg mt-2 tracking-wider">{'•'.repeat(Math.max(4, passwordInput.length))}</p>
              </div>
              <Badge variant={findings.length ? 'high' : 'low'}>{findings.length} pattern{findings.length === 1 ? '' : 's'}</Badge>
            </div>
          </Card>

          <div className="space-y-4">
            {findings.length ? findings.map((finding) => (
              <Card key={finding.id} className="space-y-3">
                <div className="flex items-start justify-between gap-4">
                  <div>
                    <p className="font-mono text-[10px] uppercase tracking-widest text-soot/45 dark:text-bone/35">{finding.category}</p>
                    <h2 className="font-display text-xl font-bold mt-1">{finding.construction}</h2>
                  </div>
                  <Badge variant={finding.confidence === 'high' ? 'high' : finding.confidence === 'medium' ? 'medium' : 'neutral'}>{finding.confidence}</Badge>
                </div>
                <p className="font-mono text-sm leading-relaxed text-soot/65 dark:text-bone/55">{finding.explanation}</p>
                <div className="border-l-4 border-violet-500 pl-4 space-y-1">
                  <p className="font-mono text-xs leading-relaxed"><span className="font-bold">Why:</span> {finding.whyItMatters}</p>
                  <p className="font-mono text-xs leading-relaxed"><span className="font-bold">Remember:</span> {finding.userTakeaway || 'A predictable construction can be easier to model than it looks.'}</p>
                </div>
              </Card>
            )) : (
              <Card>
                <p className="font-display text-xl font-bold">No strong common pattern found.</p>
                <p className="font-mono text-sm mt-2 text-soot/60 dark:text-bone/50">That is useful, but it does not prove the password is safe.</p>
              </Card>
            )}
          </div>

          <Card accent className="mt-6 space-y-4">
            <div>
              <p className="font-mono text-[10px] uppercase tracking-widest text-violet-600 dark:text-violet-400">A better pattern to learn</p>
              <h2 className="font-display text-2xl font-bold mt-1">{guidance.title}</h2>
            </div>
            <div className="border-3 border-violet-500 bg-paper-100 dark:bg-ink-800 p-5 shadow-brutal">
              <p className="font-mono text-xs uppercase tracking-widest text-soot/45 dark:text-bone/35 mb-2">A construction idea · not a password</p>
              <p className="font-display text-base sm:text-lg font-bold break-words">{guidance.pattern}</p>
            </div>
            <p className="font-mono text-sm leading-relaxed text-soot/65 dark:text-bone/55">{guidance.body}</p>
            <p className="font-mono text-xs leading-relaxed text-soot/50 dark:text-bone/40">The system does not choose the words or build the final password for you. The point is to create the private association yourself.</p>
          </Card>

          <div className="mt-8 flex justify-between gap-3">
            <Button variant="ghost" onClick={() => setStep('password-input')} icon={<i className="ti ti-arrow-left" aria-hidden="true" />}>Back to Stage 1</Button>
            <Button onClick={() => setStep('personal-analysis')} icon={<i className="ti ti-arrow-right" aria-hidden="true" />}>Check personal links</Button>
          </div>
        </motion.div>
      </div>
    </div>
  );
};
