import React from 'react';
import { motion } from 'framer-motion';
import { useAnalysis } from '../context/AnalysisContext';
import { Button } from '../components/ui/Button';
import { Card } from '../components/ui/Card';
import { Badge, type BadgeVariant } from '../components/ui/Badge';
import type { PersonalRiskLevel } from '../analysis/types';

const variants: Record<PersonalRiskLevel, BadgeVariant> = { low: 'low', medium: 'medium', high: 'high', critical: 'critical' };
const labels: Record<PersonalRiskLevel, string> = { low: 'LOW', medium: 'MEDIUM', high: 'HIGH', critical: 'HIGH' };

export const PersonalAnalysisPage: React.FC = () => {
  const { analysisResult, setStep } = useAnalysis();

  if (!analysisResult) {
    return (
      <div className="min-h-[80vh] bg-paper-50 dark:bg-ink-950 px-6 py-12">
        <div className="max-w-3xl mx-auto">
          <Button variant="ghost" onClick={() => setStep('password-input')}>Back</Button>
          <Card accent className="mt-8">
            <h1 className="font-display text-3xl font-bold">No analysis yet</h1>
            <p className="font-mono text-sm mt-2 text-soot/60 dark:text-bone/50">Check a password first.</p>
          </Card>
        </div>
      </div>
    );
  }

  const result = analysisResult.stage3;

  return (
    <div className="min-h-[80vh] bg-paper-50 dark:bg-ink-950 text-soot dark:text-bone">
      <div className="max-w-4xl mx-auto px-6 pt-10 pb-24">
        <Button
          variant="ghost"
          size="sm"
          icon={<i className="ti ti-arrow-left" aria-hidden="true" />}
          onClick={() => setStep('pattern-analysis')}
          className="mb-7"
        >
          Back
        </Button>

        <motion.div initial={{ opacity: 0, y: 14 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: .3 }}>
          <div className="mb-8">
            <div className="inline-flex items-center gap-2 font-mono text-[10px] uppercase tracking-widest text-violet-600 dark:text-violet-400 mb-3">
              <i className="ti ti-user-search" aria-hidden="true" />
              <span>Stage 3 · Personal Guessability</span>
            </div>
            <h1 className="font-display text-4xl sm:text-5xl font-bold tracking-tight">Could your life help guess it?</h1>
            <p className="font-mono text-sm leading-relaxed text-soot/60 dark:text-bone/50 max-w-2xl mt-3">
              We break the password into meaningful pieces, then check whether those pieces can be connected to the personal information you supplied. This includes direct matches, initials, abbreviations, mnemonic structures, and related ideas.
            </p>
          </div>

          <Card accent className="space-y-5 mb-5">
            <div className="flex items-start justify-between gap-4">
              <div>
                <p className="font-mono text-[10px] uppercase tracking-widest text-soot/45 dark:text-bone/35">Personal link risk</p>
                <h2 className="font-display text-2xl font-bold mt-1">{result.riskScore}/100</h2>
              </div>
              <Badge variant={variants[result.riskLevel]}>{labels[result.riskLevel]}</Badge>
            </div>
            <div className="h-3 border-2 border-paper-line dark:border-ink-line bg-paper-100 dark:bg-ink-800 overflow-hidden">
              <div className="h-full bg-violet-500" style={{ width: `${result.riskScore}%` }} />
            </div>
            <p className="font-mono text-sm leading-relaxed text-soot/65 dark:text-bone/55">{result.summary}</p>
          </Card>

          <div className="space-y-4">
            {result.findings.length ? result.findings.map((finding) => (
              <Card key={finding.id} className="space-y-3">
                <div className="flex items-start justify-between gap-4">
                  <div>
                    <p className="font-mono text-[10px] uppercase tracking-widest text-soot/45 dark:text-bone/35">{finding.category}</p>
                    <h2 className="font-display text-xl font-bold mt-1">{finding.label}</h2>
                  </div>
                  <Badge variant={finding.confidence === 'high' ? 'high' : 'medium'}>{finding.confidence}</Badge>
                </div>
                <p className="font-mono text-sm leading-relaxed text-soot/65 dark:text-bone/55">{finding.explanation}</p>
                <p className="font-mono text-xs leading-relaxed text-soot/70 dark:text-bone/60">
                  <span className="font-bold">Why it matters:</span> {finding.whyItMatters}
                </p>
              </Card>
            )) : (
              <Card>
                <div className="flex gap-3 items-start">
                  <i className="ti ti-circle-check text-risk-low text-xl" aria-hidden="true" />
                  <div>
                    <h2 className="font-display text-xl font-bold">No clear personal link found</h2>
                    <p className="font-mono text-sm mt-2 leading-relaxed text-soot/60 dark:text-bone/50">
                      None of the supplied personal details matched the password strongly enough to report as a useful clue.
                    </p>
                  </div>
                </div>
              </Card>
            )}
          </div>

          <Card className="mt-6 border-dashed space-y-3">
            <div className="flex gap-3 items-start">
              <i className="ti ti-brain text-violet-600 dark:text-violet-400 text-xl" aria-hidden="true" />
              <div>
                <p className="font-mono text-[10px] uppercase tracking-widest text-soot/45 dark:text-bone/35">How the deeper analysis works</p>
                <h2 className="font-display text-xl font-bold mt-1">We look for meaning, not just matching letters</h2>
                <p className="font-mono text-sm leading-relaxed mt-2 text-soot/65 dark:text-bone/55">A trained relationship model is used here alongside deterministic evidence. It helps classify possible abbreviations, mnemonic structures and semantic relationships that are difficult to capture with exact string matching alone. Obvious direct matches remain rule-based, so the model cannot override clear evidence.</p>
                <div className="mt-3 grid gap-2 sm:grid-cols-2 font-mono text-xs text-soot/65 dark:text-bone/55">
                  <p><strong>Current evidence:</strong> direct matches, personal numbers, initials, abbreviations, mnemonics and semantic relationships.</p>
                  <p><strong>ML role:</strong> {result.ml.status === 'trained' ? `trained model ${result.ml.modelVersion ?? ''} contributes relationship classification.` : 'model file unavailable, so only deterministic evidence is shown.'}</p>
                </div>
              </div>
            </div>
          </Card>

          <Card className="mt-6 border-dashed">
            <div className="flex gap-3 items-start">
              <i className="ti ti-bulb text-violet-600 dark:text-violet-400 text-xl" aria-hidden="true" />
              <div>
                <p className="font-mono text-[10px] uppercase tracking-widest text-soot/45 dark:text-bone/35">What to take from this</p>
                <p className="font-mono text-sm leading-relaxed mt-2 text-soot/65 dark:text-bone/55">
                  The important question is not whether your password contains a piece of personal information by accident. It is whether someone who knows you could use those same clues to narrow down what they would try next.
                </p>
              </div>
            </div>
          </Card>

          <div className="mt-8 flex justify-between gap-3">
            <Button variant="ghost" onClick={() => setStep('pattern-analysis')} icon={<i className="ti ti-arrow-left" aria-hidden="true" />}>
              Back to patterns
            </Button>
            <Button onClick={() => setStep('attack-simulation')} icon={<i className="ti ti-arrow-right" aria-hidden="true" />}>
              Personal Attack Simulation
            </Button>
          </div>
        </motion.div>
      </div>
    </div>
  );
};
