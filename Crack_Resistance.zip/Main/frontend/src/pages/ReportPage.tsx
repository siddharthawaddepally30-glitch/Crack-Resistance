import React from 'react';
import { motion } from 'framer-motion';
import { useAnalysis } from '../context/AnalysisContext';
import { Button } from '../components/ui/Button';
import { Card } from '../components/ui/Card';
import { Badge, type BadgeVariant } from '../components/ui/Badge';
import type { RiskLevel, PersonalRiskLevel } from '../analysis/types';

const riskVariant = (level: RiskLevel): BadgeVariant => level === 'critical' ? 'critical' : level;
const personalVariant = (level: PersonalRiskLevel): BadgeVariant => level === 'critical' ? 'critical' : level;

export const ReportPage: React.FC = () => {
  const { analysisResult, passwordInput, setStep } = useAnalysis();

  if (!analysisResult) {
    return (
      <div className="min-h-[80vh] bg-paper-50 dark:bg-ink-950 px-6 py-12">
        <div className="max-w-3xl mx-auto">
          <Button variant="ghost" onClick={() => setStep('password-input')}>Back</Button>
          <Card accent className="mt-8">
            <h1 className="font-display text-3xl font-bold">No report yet</h1>
            <p className="font-mono text-sm mt-2 text-soot/60 dark:text-bone/50">Run the password analysis first.</p>
          </Card>
        </div>
      </div>
    );
  }

  const { stage1, stage2, stage3, stage5 } = analysisResult;
  const topStage1 = stage1.signals.slice(0, 5);
  const topPatterns = stage2.findings.slice(0, 6);
  const topPersonal = stage3.findings.slice(0, 6);
  const overallTone = stage1.riskLevel === 'critical' || stage3.riskLevel === 'critical'
    ? 'Several strong warning signs were found.'
    : stage1.riskLevel === 'high' || stage3.riskLevel === 'high'
      ? 'The password has meaningful weaknesses that deserve attention.'
      : 'The analysis found some useful evidence, but no overwhelming warning pattern.';

  return (
    <div className="min-h-[80vh] bg-paper-50 dark:bg-ink-950 text-soot dark:text-bone">
      <div className="max-w-5xl mx-auto px-6 pt-10 pb-24">
        <Button variant="ghost" size="sm" icon={<i className="ti ti-arrow-left" aria-hidden="true" />} onClick={() => setStep('unrelatedness')} className="mb-7">
          Back to personal unrelatedness
        </Button>

        <motion.div initial={{ opacity: 0, y: 14 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: .3 }}>
          <div className="mb-8">
            <div className="inline-flex items-center gap-2 font-mono text-[10px] uppercase tracking-widest text-violet-600 dark:text-violet-400 mb-3">
              <i className="ti ti-chart-bar" aria-hidden="true" />
              <span>Stage 6 · Explainable Security Report</span>
            </div>
            <h1 className="font-display text-4xl sm:text-5xl font-bold tracking-tight">What does the full analysis mean?</h1>
            <p className="font-mono text-sm leading-relaxed text-soot/65 dark:text-bone/55 max-w-3xl mt-4">
              This page combines the earlier stages into one security story. It does not run another analysis. It explains what the evidence means when the generic, pattern, personal and unrelatedness results are considered together.
            </p>
          </div>

          <Card accent>
            <div className="flex flex-wrap items-end justify-between gap-5">
              <div>
                <p className="font-mono text-[10px] uppercase tracking-widest text-soot/45 dark:text-bone/35">Password under review</p>
                <p className="font-mono text-lg mt-2 tracking-wide">{passwordInput ? '•'.repeat(Math.min(passwordInput.length, 18)) : 'Not available'}</p>
                <p className="font-mono text-sm leading-relaxed mt-3 text-soot/65 dark:text-bone/55">{overallTone}</p>
              </div>
              <div className="grid grid-cols-3 gap-3 w-full sm:w-auto">
                <div className="border-2 border-paper-line dark:border-ink-line p-3 min-w-24">
                  <p className="font-mono text-[9px] uppercase tracking-widest text-soot/45 dark:text-bone/35">Generic</p>
                  <p className="font-display text-xl font-bold mt-1">{stage1.riskScore}</p>
                  <Badge variant={riskVariant(stage1.riskLevel)} className="mt-2">{stage1.riskLevel}</Badge>
                </div>
                <div className="border-2 border-paper-line dark:border-ink-line p-3 min-w-24">
                  <p className="font-mono text-[9px] uppercase tracking-widest text-soot/45 dark:text-bone/35">Personal</p>
                  <p className="font-display text-xl font-bold mt-1">{stage3.riskScore}</p>
                  <Badge variant={personalVariant(stage3.riskLevel)} className="mt-2">{stage3.riskLevel}</Badge>
                </div>
                <div className="border-2 border-paper-line dark:border-ink-line p-3 min-w-24">
                  <p className="font-mono text-[9px] uppercase tracking-widest text-soot/45 dark:text-bone/35">Independent</p>
                  <p className="font-display text-xl font-bold mt-1">{stage5.score}</p>
                  <Badge variant={stage5.score >= 75 ? 'high' : stage5.score >= 50 ? 'medium' : 'critical'} className="mt-2">{stage5.score >= 75 ? 'stronger' : 'weaker'}</Badge>
                </div>
              </div>
            </div>
          </Card>

          <section className="mt-9">
            <div className="flex items-center gap-3 mb-4">
              <span className="font-mono text-xs font-bold border-2 border-red-500 bg-red-50 text-red-700 dark:bg-red-950/30 dark:text-red-300 px-2 py-1 shadow-[3px_3px_0_rgba(239,68,68,0.22)]">01</span>
              <div>
                <p className="font-mono text-[10px] uppercase tracking-widest text-soot/45 dark:text-bone/35">Generic guessability</p>
                <h2 className="font-display text-2xl font-bold mt-1">How the password looks without personal context</h2>
              </div>
            </div>
            <Card>
              <p className="font-mono text-sm leading-relaxed text-soot/70 dark:text-bone/60 mb-4">Stage 1 asks what a general attacker could learn from the password alone. These are the strongest generic signals found.</p>
              {topStage1.length ? (
                <div className="space-y-3">
                  {topStage1.map((signal) => (
                    <div key={signal.id} className="border-2 border-paper-line dark:border-ink-line p-4">
                      <div className="flex items-center justify-between gap-3">
                        <p className="font-display font-bold">{signal.label}</p>
                        <Badge variant={riskVariant(signal.level)}>{signal.level}</Badge>
                      </div>
                      <p className="font-mono text-sm leading-relaxed mt-2 text-soot/65 dark:text-bone/55">{signal.explanation}</p>
                      <p className="font-mono text-xs leading-relaxed mt-2 text-soot/50 dark:text-bone/45"><strong>What to learn:</strong> {signal.action}</p>
                    </div>
                  ))}
                </div>
              ) : <p className="font-mono text-sm text-soot/60 dark:text-bone/50">No high-impact generic signal was selected for display.</p>}
            </Card>
          </section>

          <section className="mt-9">
            <div className="flex items-center gap-3 mb-4">
              <span className="font-mono text-xs font-bold border-2 border-red-500 bg-red-50 text-red-700 dark:bg-red-950/30 dark:text-red-300 px-2 py-1 shadow-[3px_3px_0_rgba(239,68,68,0.22)]">02</span>
              <div>
                <p className="font-mono text-[10px] uppercase tracking-widest text-soot/45 dark:text-bone/35">Pattern intelligence</p>
                <h2 className="font-display text-2xl font-bold mt-1">How the password was constructed</h2>
              </div>
            </div>
            <Card>
              <p className="font-mono text-sm leading-relaxed text-soot/70 dark:text-bone/60 mb-4">Stage 2 combines rule-based evidence with the trained Pattern Intelligence model. The model is an additional signal, not a claim that a construction is guaranteed to have one interpretation.</p>
              <div className="space-y-3">
                {topPatterns.map((finding) => (
                  <div key={finding.id} className="border-2 border-paper-line dark:border-ink-line p-4">
                    <div className="flex items-center justify-between gap-3">
                      <p className="font-display font-bold">{finding.category}</p>
                      <Badge variant={finding.confidence === 'high' ? 'high' : finding.confidence === 'medium' ? 'medium' : 'low'}>{finding.confidence}</Badge>
                    </div>
                    <p className="font-mono text-xs uppercase tracking-widest mt-2 text-violet-600 dark:text-violet-400">{finding.construction}</p>
                    <p className="font-mono text-sm leading-relaxed mt-2 text-soot/65 dark:text-bone/55">{finding.explanation}</p>
                    {finding.userTakeaway && <p className="font-mono text-xs leading-relaxed mt-2 text-soot/55 dark:text-bone/45"><strong>Takeaway:</strong> {finding.userTakeaway}</p>}
                  </div>
                ))}
                {!topPatterns.length && <p className="font-mono text-sm text-soot/60 dark:text-bone/50">No strong pattern was selected for the report.</p>}
              </div>
            </Card>
          </section>

          <section className="mt-9">
            <div className="flex items-center gap-3 mb-4">
              <span className="font-mono text-xs font-bold border-2 border-red-500 bg-red-50 text-red-700 dark:bg-red-950/30 dark:text-red-300 px-2 py-1 shadow-[3px_3px_0_rgba(239,68,68,0.22)]">03</span>
              <div>
                <p className="font-mono text-[10px] uppercase tracking-widest text-soot/45 dark:text-bone/35">Personal guessability</p>
                <h2 className="font-display text-2xl font-bold mt-1">Could information about you help explain it?</h2>
              </div>
            </div>
            <Card>
              <p className="font-mono text-sm leading-relaxed text-soot/70 dark:text-bone/60 mb-4">Stage 3 looks for direct matches, initials, personal numbers, abbreviations, mnemonic structures and semantic relationships. The goal is to identify meaningful evidence, not to invent connections.</p>
              {topPersonal.length ? (
                <div className="space-y-3">
                  {topPersonal.map((finding) => (
                    <div key={finding.id} className="border-2 border-paper-line dark:border-ink-line p-4">
                      <div className="flex items-center justify-between gap-3">
                        <p className="font-display font-bold">{finding.label}</p>
                        <Badge variant={finding.confidence === 'high' ? 'high' : 'medium'}>{finding.confidence}</Badge>
                      </div>
                      <p className="font-mono text-sm leading-relaxed mt-2 text-soot/65 dark:text-bone/55">{finding.explanation}</p>
                      <p className="font-mono text-xs leading-relaxed mt-2 text-soot/50 dark:text-bone/45"><strong>Why it matters:</strong> {finding.whyItMatters}</p>
                    </div>
                  ))}
                </div>
              ) : <p className="font-mono text-sm text-soot/60 dark:text-bone/50">No strong personal relationship was found.</p>}
            </Card>
          </section>

          <section className="mt-9">
            <div className="flex items-center gap-3 mb-4">
              <span className="font-mono text-xs font-bold border-2 border-red-500 bg-red-50 text-red-700 dark:bg-red-950/30 dark:text-red-300 px-2 py-1 shadow-[3px_3px_0_rgba(239,68,68,0.22)]">04</span>
              <div>
                <p className="font-mono text-[10px] uppercase tracking-widest text-soot/45 dark:text-bone/35">Targeted reasoning</p>
                <h2 className="font-display text-2xl font-bold mt-1">How those clues can reinforce one another</h2>
              </div>
            </div>
            <Card accent>
              <ul className="space-y-3 font-mono text-sm leading-relaxed text-soot/70 dark:text-bone/60 list-disc pl-5">
                <li>A direct personal match can provide a strong starting clue.</li>
                <li>A related concept or abbreviation can widen that clue into more meaningful vocabulary.</li>
                <li>A personal number can add a predictable suffix or prefix.</li>
                <li>Common construction patterns can then make the combined structure easier to reason about.</li>
                <li>The simulation never displays real attack guesses. It explains the path that makes some constructions more plausible than others.</li>
              </ul>
            </Card>
          </section>

          <section className="mt-9">
            <div className="flex items-center gap-3 mb-4">
              <span className="font-mono text-xs font-bold border-2 border-red-500 bg-red-50 text-red-700 dark:bg-red-950/30 dark:text-red-300 px-2 py-1 shadow-[3px_3px_0_rgba(239,68,68,0.22)]">05</span>
              <div>
                <p className="font-mono text-[10px] uppercase tracking-widest text-soot/45 dark:text-bone/35">Personal independence</p>
                <h2 className="font-display text-2xl font-bold mt-1">How far does the password stand apart from your life?</h2>
              </div>
            </div>
            <Card>
              <div className="flex items-center justify-between gap-4">
                <div>
                  <p className="font-mono text-[10px] uppercase tracking-widest text-soot/45 dark:text-bone/35">Personal Unrelatedness Score</p>
                  <p className="font-display text-3xl font-bold mt-1">{stage5.score}/100</p>
                </div>
                <Badge variant={stage5.score >= 75 ? 'high' : stage5.score >= 50 ? 'medium' : 'critical'}>{stage5.score >= 75 ? 'MORE INDEPENDENT' : 'MORE CONNECTED'}</Badge>
              </div>
              <div className="grid gap-3 sm:grid-cols-2 mt-5">
                {stage5.dimensions.map((dimension) => (
                  <div key={dimension.name} className="border-2 border-paper-line dark:border-ink-line p-4">
                    <div className="flex justify-between gap-3"><p className="font-display font-bold capitalize">{dimension.name}</p><p className="font-mono font-bold">{dimension.score}</p></div>
                    <p className="font-mono text-xs leading-relaxed mt-2 text-soot/55 dark:text-bone/45">{dimension.explanation}</p>
                  </div>
                ))}
              </div>
            </Card>
          </section>

          <section className="mt-9">
            <div className="flex items-center gap-3 mb-4">
              <span className="font-mono text-xs font-bold border-2 border-red-500 bg-red-50 text-red-700 dark:bg-red-950/30 dark:text-red-300 px-2 py-1 shadow-[3px_3px_0_rgba(239,68,68,0.22)]">06</span>
              <div>
                <p className="font-mono text-[10px] uppercase tracking-widest text-soot/45 dark:text-bone/35">Overall interpretation</p>
                <h2 className="font-display text-2xl font-bold mt-1">Put the pieces together</h2>
              </div>
            </div>
            <Card accent>
              <p className="font-mono text-sm leading-relaxed text-soot/75 dark:text-bone/65">A password should be evaluated on more than one axis. Generic risk tells us how predictable the construction looks on its own. Personal risk tells us whether information associated with you helps explain it. Personal unrelatedness tells us how strongly it stands apart from that information.</p>
              <div className="mt-5 grid gap-3 sm:grid-cols-2">
                <div className="border-2 border-paper-line dark:border-ink-line p-5">
                  <p className="font-mono text-[10px] uppercase tracking-widest text-soot/45 dark:text-bone/35">Generic guessability</p>
                  <p className="font-display text-2xl font-bold mt-1">{stage1.riskScore}/100</p>
                  <p className="font-mono text-xs leading-relaxed mt-2 text-soot/55 dark:text-bone/45">How predictable the password looks without personal information.</p>
                </div>
                <div className="border-2 border-paper-line dark:border-ink-line p-5">
                  <p className="font-mono text-[10px] uppercase tracking-widest text-soot/45 dark:text-bone/35">Personal association</p>
                  <p className="font-display text-2xl font-bold mt-1">{stage3.riskScore}/100</p>
                  <p className="font-mono text-xs leading-relaxed mt-2 text-soot/55 dark:text-bone/45">How much the supplied information can help explain the password.</p>
                </div>
              </div>
              <p className="font-mono text-sm leading-relaxed mt-5 text-soot/70 dark:text-bone/60">The strongest construction is one that avoids familiar generic patterns, avoids a natural trail back to the user's life, and remains memorable through a private association rather than an obvious personal relationship.</p>
            </Card>
          </section>

          <Card className="mt-8">
            <div className="flex gap-4 items-start">
              <i className="ti ti-school text-violet-600 dark:text-violet-400 text-xl mt-0.5" aria-hidden="true" />
              <div>
                <p className="font-mono text-[10px] uppercase tracking-widest text-soot/45 dark:text-bone/35">Next learning step</p>
                <p className="font-display text-xl font-bold mt-1">The final stage turns these findings into a few practical password-construction rules.</p>
                <p className="font-mono text-sm leading-relaxed mt-2 text-soot/65 dark:text-bone/55">The next page keeps the advice short. It does not generate a finished password for you.</p>
              </div>
            </div>
          </Card>

          <div className="mt-8 flex justify-between gap-3">
            <Button variant="ghost" onClick={() => setStep('unrelatedness')} icon={<i className="ti ti-arrow-left" aria-hidden="true" />}>Back to unrelatedness</Button>
            <Button onClick={() => setStep('recommendation')} icon={<i className="ti ti-arrow-right" aria-hidden="true" />}>Practical guidance</Button>
          </div>
        </motion.div>
      </div>
    </div>
  );
};
