import React, { useEffect, useMemo, useState } from 'react';
import { motion } from 'framer-motion';
import { useAnalysis } from '../context/AnalysisContext';
import { Button } from '../components/ui/Button';
import { Card } from '../components/ui/Card';
import { Badge, type BadgeVariant } from '../components/ui/Badge';
import { predictRelatedness } from '../analysis/ml/unrelatednessModel';
import { UNRELATED_TOPIC_POOL } from '../analysis/unrelatedness/topicPool';

const scoreVariant = (score: number): BadgeVariant => score >= 75 ? 'high' : score >= 50 ? 'medium' : 'critical';

export const UnrelatednessPage: React.FC = () => {
  const { analysisResult, personalInfo, setStep } = useAnalysis();
  const [topicIndex, setTopicIndex] = useState(0);
  const [topicState, setTopicState] = useState<'checking' | 'possible-link' | 'likely-unrelated'>('checking');
  const [topicProbability, setTopicProbability] = useState<number | null>(null);
  const [acceptedTopic, setAcceptedTopic] = useState(false);

  const currentTopic = UNRELATED_TOPIC_POOL[topicIndex % UNRELATED_TOPIC_POOL.length];
  const suppliedValues = useMemo(
    () => Object.values(personalInfo).flatMap((value) => typeof value === 'string' ? value.split(/[,;\n|]+/).map((x) => x.trim()).filter(Boolean) : []).slice(0, 40),
    [personalInfo],
  );
  const result = analysisResult?.stage5;

  useEffect(() => {
    let active = true;
    setAcceptedTopic(false);
    setTopicState('checking');
    setTopicProbability(null);
    (async () => {
      if (!suppliedValues.length) {
        if (active) setTopicState('likely-unrelated');
        return;
      }
      let highest = 0;
      for (const value of suppliedValues) {
        const prediction = await predictRelatedness(currentTopic, value);
        if (prediction) highest = Math.max(highest, prediction.relatedProbability);
      }
      if (!active) return;
      setTopicProbability(highest || 0);
      setTopicState(highest >= 0.62 ? 'possible-link' : 'likely-unrelated');
    })();
    return () => { active = false; };
  }, [currentTopic, suppliedValues]);

  const nextTopic = () => {
    setTopicIndex((index) => (index + 1) % UNRELATED_TOPIC_POOL.length);
  };

  return (
    <div className="min-h-[80vh] bg-paper-50 dark:bg-ink-950 text-soot dark:text-bone">
      <div className="max-w-4xl mx-auto px-6 pt-10 pb-24">
        <Button variant="ghost" size="sm" icon={<i className="ti ti-arrow-left" aria-hidden="true" />} onClick={() => setStep('attack-simulation')} className="mb-7">
          Back to attack simulation
        </Button>

        <motion.div initial={{ opacity: 0, y: 14 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: .3 }}>
          <div className="mb-8">
            <div className="inline-flex items-center gap-2 font-mono text-[10px] uppercase tracking-widest text-violet-600 dark:text-violet-400 mb-3">
              <i className="ti ti-sparkles" aria-hidden="true" />
              <span>Stage 5 · Personal Unrelatedness</span>
            </div>
            <h1 className="font-display text-4xl sm:text-5xl font-bold tracking-tight">Can your password be memorable without pointing back to you?</h1>
            <p className="font-mono text-sm leading-relaxed text-soot/65 dark:text-bone/55 max-w-3xl mt-4">
              This page measures how independent the password is from your personal information. It also teaches a practical way to create memorability using a topic that is not already connected to your life.
            </p>
          </div>

          <Card accent>
            <div className="flex gap-4 items-start">
              <i className="ti ti-info-circle text-violet-600 dark:text-violet-400 text-2xl mt-0.5" aria-hidden="true" />
              <div>
                <p className="font-mono text-[10px] uppercase tracking-widest text-soot/45 dark:text-bone/35">The idea</p>
                <p className="font-mono text-sm leading-relaxed mt-3 text-soot/75 dark:text-bone/65">
                  A password can be memorable because it has a connection to your real life. That same connection can make it easier to reason about. Here, the goal is different: first find a simple idea that does not already connect to you, then create your own private mental connection to it. The application does not need to know what that private connection is.
                </p>
              </div>
            </div>
          </Card>

          <section className="mt-9">
            <div className="flex items-center gap-3 mb-4">
              <span className="font-mono text-xs font-bold border-2 border-red-500 bg-red-50 text-red-700 dark:bg-red-950/30 dark:text-red-300 px-2 py-1 shadow-[3px_3px_0_rgba(239,68,68,0.22)]">01</span>
              <div>
                <p className="font-mono text-[10px] uppercase tracking-widest text-soot/45 dark:text-bone/35">Your Personal Unrelatedness Score</p>
                <h2 className="font-display text-2xl font-bold mt-1">How much does the password stand apart from your information?</h2>
              </div>
            </div>
            <Card className="space-y-5">
              <div className="flex items-start justify-between gap-4">
                <div>
                  <p className="font-mono text-[10px] uppercase tracking-widest text-soot/45 dark:text-bone/35">Overall independence</p>
                  <p className="font-display text-3xl font-bold mt-1">{result?.score ?? 0}/100</p>
                </div>
                <Badge variant={scoreVariant(result?.score ?? 0)}>{result && result.score >= 75 ? 'MORE INDEPENDENT' : 'MORE CONNECTED'}</Badge>
              </div>
              <div className="h-3 border-2 border-paper-line dark:border-ink-line bg-paper-100 dark:bg-ink-800 overflow-hidden">
                <div className="h-full bg-violet-500" style={{ width: `${result?.score ?? 0}%` }} />
              </div>
              <div className="grid gap-3 sm:grid-cols-2">
                {(result?.dimensions ?? []).map((dimension) => (
                  <div key={dimension.name} className="border-2 border-paper-line dark:border-ink-line p-4">
                    <div className="flex items-center justify-between gap-3">
                      <p className="font-display font-bold capitalize">{dimension.name}</p>
                      <p className="font-mono font-bold">{dimension.score}/100</p>
                    </div>
                    <p className="font-mono text-xs leading-relaxed mt-2 text-soot/60 dark:text-bone/50">{dimension.explanation}</p>
                  </div>
                ))}
              </div>
              <p className="font-mono text-xs leading-relaxed text-soot/55 dark:text-bone/45">This score describes independence from the information supplied for this analysis. It is not a standalone proof of password strength.</p>
            </Card>
          </section>

          <section className="mt-9">
            <div className="flex items-center gap-3 mb-4">
              <span className="font-mono text-xs font-bold border-2 border-red-500 bg-red-50 text-red-700 dark:bg-red-950/30 dark:text-red-300 px-2 py-1 shadow-[3px_3px_0_rgba(239,68,68,0.22)]">02</span>
              <div>
                <p className="font-mono text-[10px] uppercase tracking-widest text-soot/45 dark:text-bone/35">Find an unrelated idea</p>
                <h2 className="font-display text-2xl font-bold mt-1">A topic you can recognise and judge for yourself</h2>
              </div>
            </div>
            <Card accent className="space-y-5">
              <p className="font-mono text-sm leading-relaxed text-soot/70 dark:text-bone/60">
                The suggestions mix specialist fields with less-common objects and familiar ideas. You do not need to know the subject in depth. You only need to decide whether the word or idea has a real connection to your life. The list is intentionally broad so you can reject a topic and try another one.
              </p>
              <div className="border-3 border-violet-500 bg-paper-100 dark:bg-ink-800 p-6 shadow-brutal">
                <p className="font-mono text-[10px] uppercase tracking-widest text-soot/45 dark:text-bone/35">Suggested topic</p>
                <p className="font-display text-4xl sm:text-5xl font-bold mt-2 capitalize">{currentTopic}</p>
                <p className="font-mono text-sm leading-relaxed mt-3 text-soot/60 dark:text-bone/50">Ask yourself: <strong>“Does this have any meaningful connection to my life?”</strong></p>
              </div>
              <div className="grid gap-3 sm:grid-cols-2">
                <div className="border-2 border-paper-line dark:border-ink-line p-4">
                  <p className="font-mono text-[10px] uppercase tracking-widest text-soot/45 dark:text-bone/35">Model check</p>
                  <p className="font-display font-bold mt-1">{topicState === 'checking' ? 'Checking...' : topicState === 'possible-link' ? 'Possible connection found' : 'No strong connection found'}</p>
                  <p className="font-mono text-xs leading-relaxed mt-1 text-soot/55 dark:text-bone/45">{topicProbability === null ? 'The model is comparing the topic with the information you supplied.' : `Highest model relatedness signal: ${(topicProbability * 100).toFixed(0)}%.`}</p>
                </div>
                <div className="border-2 border-paper-line dark:border-ink-line p-4">
                  <p className="font-mono text-[10px] uppercase tracking-widest text-soot/45 dark:text-bone/35">Your check matters most</p>
                  <p className="font-display font-bold mt-1">{acceptedTopic ? 'Topic accepted' : 'Not decided yet'}</p>
                  <p className="font-mono text-xs leading-relaxed mt-1 text-soot/55 dark:text-bone/45">You know your own life better than the model. Reject a topic whenever you know it has a real connection.</p>
                </div>
              </div>
              {!acceptedTopic ? (
                <div className="flex flex-col sm:flex-row gap-3">
                  <Button variant="ghost" onClick={nextTopic} icon={<i className="ti ti-refresh" aria-hidden="true" />}>Again</Button>
                  <Button onClick={() => setAcceptedTopic(true)} disabled={topicState === 'checking'} icon={<i className="ti ti-check" aria-hidden="true" />}>This feels unrelated · Accept</Button>
                </div>
              ) : (
                <div className="border-3 border-violet-500 p-5 bg-paper-50 dark:bg-ink-850 shadow-brutal">
                  <p className="font-display text-xl font-bold">Now create your private association.</p>
                  <p className="font-mono text-sm leading-relaxed mt-2 text-soot/65 dark:text-bone/55">Use the accepted topic as a mental anchor and privately connect it to something you can remember. Keep that connection in your head. The app does not ask you to reveal it.</p>
                </div>
              )}
            </Card>
          </section>

          <section className="mt-9">
            <div className="flex items-center gap-3 mb-4">
              <span className="font-mono text-xs font-bold border-2 border-red-500 bg-red-50 text-red-700 dark:bg-red-950/30 dark:text-red-300 px-2 py-1 shadow-[3px_3px_0_rgba(239,68,68,0.22)]">03</span>
              <div>
                <p className="font-mono text-[10px] uppercase tracking-widest text-soot/45 dark:text-bone/35">Why the Again button matters</p>
                <h2 className="font-display text-2xl font-bold mt-1">The model suggests. You decide.</h2>
              </div>
            </div>
            <Card>
              <ul className="space-y-3 font-mono text-sm leading-relaxed text-soot/70 dark:text-bone/60 list-disc pl-5">
                <li>A topic can look unrelated to a computer model while still having a personal meaning to you.</li>
                <li>A topic can look ordinary but be linked to your family, school, work, hobbies, travel, memories, or another part of your life.</li>
                <li>Whenever you notice a connection, press <strong>Again</strong> and get a different idea.</li>
                <li>Keep going until the topic genuinely feels separate from your real-world personal information.</li>
                <li>You are not required to explain why you rejected or accepted a topic.</li>
              </ul>
            </Card>
          </section>

          <section className="mt-9">
            <div className="flex items-center gap-3 mb-4">
              <span className="font-mono text-xs font-bold border-2 border-red-500 bg-red-50 text-red-700 dark:bg-red-950/30 dark:text-red-300 px-2 py-1 shadow-[3px_3px_0_rgba(239,68,68,0.22)]">04</span>
              <div>
                <p className="font-mono text-[10px] uppercase tracking-widest text-soot/45 dark:text-bone/35">The private association</p>
                <h2 className="font-display text-2xl font-bold mt-1">Create the memory yourself, without creating a personal trail</h2>
              </div>
            </div>
            <Card accent>
              <p className="font-mono text-sm leading-relaxed text-soot/70 dark:text-bone/60">Once you have an idea that feels genuinely unrelated, create a private connection to it in your own mind. The important difference is that this connection did not already exist in the personal information you supplied. That means the application does not need to know the connection, and a person looking only at your ordinary personal information does not automatically have that same trail to follow.</p>
              <div className="mt-5 border-t-2 border-paper-line dark:border-ink-line pt-5">
                <p className="font-display text-xl font-bold">Educational principle</p>
                <p className="font-mono text-sm leading-relaxed mt-2 text-soot/70 dark:text-bone/60">Make memorability come from a private association, not from an existing relationship to your real-world identity.</p>
              </div>
            </Card>
          </section>

          <section className="mt-9">
            <div className="flex items-center gap-3 mb-4">
              <span className="font-mono text-xs font-bold border-2 border-red-500 bg-red-50 text-red-700 dark:bg-red-950/30 dark:text-red-300 px-2 py-1 shadow-[3px_3px_0_rgba(239,68,68,0.22)]">05</span>
              <div>
                <p className="font-mono text-[10px] uppercase tracking-widest text-soot/45 dark:text-bone/35">What to remember</p>
                <h2 className="font-display text-2xl font-bold mt-1">Personal independence is about the trail, not just the characters</h2>
              </div>
            </div>
            <Card>
              <ul className="space-y-3 font-mono text-sm leading-relaxed text-soot/70 dark:text-bone/60 list-disc pl-5">
                <li>A password can be long and still have a strong trail back to your life.</li>
                <li>An unrelated concept gives you a way to build memorability without starting from your identity.</li>
                <li>The application can help you find an unrelated idea, but the final private association belongs only to you.</li>
                <li>The strongest result comes from combining this idea with good generic password construction from earlier stages.</li>
              </ul>
            </Card>
          </section>

          <div className="mt-8 flex justify-between gap-3">
            <Button variant="ghost" onClick={() => setStep('attack-simulation')} icon={<i className="ti ti-arrow-left" aria-hidden="true" />}>Back to attack simulation</Button>
            <Button onClick={() => setStep('report')} icon={<i className="ti ti-arrow-right" aria-hidden="true" />}>View Explainable Report</Button>
          </div>
        </motion.div>
      </div>
    </div>
  );
};
