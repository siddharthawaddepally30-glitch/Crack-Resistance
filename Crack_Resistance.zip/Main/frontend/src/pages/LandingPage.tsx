import React from 'react';
import { motion, type Variants } from 'framer-motion';
import { useAnalysis } from '../context/AnalysisContext';
import { Button } from '../components/ui/Button';
import { Card } from '../components/ui/Card';
import { Badge } from '../components/ui/Badge';

const containerVariants: Variants = {
  hidden: { opacity: 0 },
  visible: { opacity: 1, transition: { staggerChildren: 0.08 } },
};

const itemVariants: Variants = {
  hidden: { opacity: 0, y: 14 },
  visible: { opacity: 1, y: 0, transition: { duration: 0.35, ease: 'easeOut' } },
};

const revealProps = {
  initial: { opacity: 0, y: 20 },
  whileInView: { opacity: 1, y: 0 },
  viewport: { once: true, margin: '-80px' },
  transition: { duration: 0.4, ease: 'easeOut' as const },
};

const STAGES = [
  {
    stage: '01',
    title: 'Generic Risk Intelligence',
    description: 'Evaluates baseline resistance using common-password intelligence, dictionary analysis, and predictable construction checks.',
  },
  {
    stage: '02',
    title: 'Pattern & Grammar Intelligence',
    description: 'Extracts abstract password grammar — capitalized words, years, symbols, keyboard walks, and structural patterns.',
  },
  {
    stage: '03',
    title: 'Personalized Guessability',
    description: 'Dissects the password against voluntarily supplied context: direct terms, derived initials, and multi-attribute combinations.',
  },
  {
    stage: '04',
    title: 'Targeted Attack Simulation',
    description: 'Models how personal clues can influence targeted guessing and prepares the evidence used by later unrelatedness analysis.',
  },
];

const PRIVACY_POINTS = [
  'No database storage',
  'No plaintext password logs',
  'Immediate session memory wipe',
  'No external tracking or profiling',
];

export const LandingPage: React.FC = () => {
  const { setStep } = useAnalysis();

  return (
    <div className="relative bg-paper-50 dark:bg-ink-950 text-soot dark:text-bone overflow-hidden">

      <div className="relative max-w-5xl mx-auto px-6 pt-20 pb-24">

        {/* HERO */}
        <motion.div variants={containerVariants} initial="hidden" animate="visible" className="relative text-center">

          <motion.p variants={itemVariants} className="font-mono text-xs font-bold uppercase tracking-[0.15em] text-violet-600 dark:text-violet-400 mb-6">
            A password can look strong.
          </motion.p>

          <motion.h1 variants={itemVariants} className="font-display text-5xl sm:text-6xl md:text-7xl font-bold tracking-tight leading-[1.05] max-w-4xl mx-auto">
            But what if someone<br />knows you?
          </motion.h1>

          <motion.p variants={itemVariants} className="font-mono text-base sm:text-lg text-soot/70 dark:text-bone/60 leading-relaxed max-w-2xl mx-auto mt-6">
            Crack Resistance analyzes both generic password guessability and the personal patterns that can make a password predictable to a targeted attacker.
          </motion.p>

          <motion.div variants={itemVariants} className="flex flex-col sm:flex-row items-center justify-center gap-4 mt-10">
            <Button
              variant="primary"
              size="lg"
              icon={<i className="ti ti-arrow-right" aria-hidden="true" />}
              onClick={() => setStep('personal-info')}
              className="w-full sm:w-auto"
            >
              Start Personal Analysis
            </Button>
            <Button
              variant="secondary"
              size="lg"
              onClick={() => {
                const target = document.getElementById('problem');
                if (!target) return;
                const top = target.getBoundingClientRect().top + window.scrollY - 88;
                window.scrollTo({ top: Math.max(0, top), behavior: 'smooth' });
              }}
              className="w-full sm:w-auto"
            >
              How It Works
            </Button>
          </motion.div>

          <motion.div variants={itemVariants} className="mt-8 flex items-center justify-center gap-2 font-mono text-xs text-soot/50 dark:text-bone/40">
            <i className="ti ti-lock" aria-hidden="true" />
            <span>Zero persistent storage &bull; Ephemeral processing</span>
          </motion.div>
        </motion.div>

        {/* THE PROBLEM */}
        <div id="problem" className="mt-40 space-y-10">
          <motion.div {...revealProps} className="max-w-3xl mx-auto text-center space-y-5">
            <p className="font-mono text-xs font-bold uppercase tracking-[0.15em] text-violet-600 dark:text-violet-400">The Problem</p>
            <h2 className="font-display text-3xl sm:text-4xl md:text-5xl font-bold tracking-tight">
              Generic strength vs. personal predictability
            </h2>
            <p className="font-mono text-base text-soot/70 dark:text-bone/60 leading-relaxed">
              Password checkers measure entropy — mathematical randomness. But humans don't create random passwords. They create memorable ones using patterns, dates, names, and personal associations that attackers can discover.
            </p>
          </motion.div>

          <motion.div {...revealProps} className="max-w-4xl mx-auto grid grid-cols-1 md:grid-cols-2 gap-6">
            <Card>
              <div className="font-mono text-xs font-bold uppercase tracking-wide text-soot/50 dark:text-bone/40 mb-3">Generic Checkers See</div>
              <div className="font-display text-2xl font-bold mb-3">Random Entropy</div>
              <p className="font-mono text-sm text-soot/70 dark:text-bone/60 leading-relaxed">
                Length, character variety, symbol usage. They assume every character combination is equally likely.
              </p>
            </Card>
            <Card accent>
              <div className="font-mono text-xs font-bold uppercase tracking-wide text-violet-600 dark:text-violet-400 mb-3">Targeted Attackers See</div>
              <div className="font-display text-2xl font-bold mb-3">Personal Patterns</div>
              <p className="font-mono text-sm text-soot/70 dark:text-bone/60 leading-relaxed">
                Birth years, pet names, sports teams, relationships — public information that makes passwords predictable.
              </p>
            </Card>
          </motion.div>
        </div>

        {/* HOW IT THINKS */}
        <div className="mt-40 space-y-10">
          <motion.div {...revealProps} className="max-w-3xl mx-auto text-center space-y-5">
            <p className="font-mono text-xs font-bold uppercase tracking-[0.15em] text-violet-600 dark:text-violet-400">How Crack Resistance Thinks</p>
            <h2 className="font-display text-3xl sm:text-4xl md:text-5xl font-bold tracking-tight">
              Four stages of intelligence
            </h2>
            <p className="font-mono text-base text-soot/70 dark:text-bone/60 leading-relaxed">
              A modular pipeline that evaluates password risk from multiple perspectives.
            </p>
          </motion.div>

          <motion.div {...revealProps} className="max-w-4xl mx-auto space-y-4">
            {STAGES.map((item) => (
              <div key={item.stage} className="flex items-start gap-5 border-2 border-paper-line dark:border-ink-line bg-white dark:bg-ink-900 p-5">
                <div className="shrink-0 w-11 h-11 flex items-center justify-center bg-violet-500 border-2 border-paper-line dark:border-ink-line font-mono font-bold text-sm text-soot">
                  {item.stage}
                </div>
                <div className="flex-1 space-y-1.5 pt-0.5">
                  <h3 className="font-display font-bold text-lg">{item.title}</h3>
                  <p className="font-mono text-sm text-soot/70 dark:text-bone/60 leading-relaxed">{item.description}</p>
                </div>
              </div>
            ))}
          </motion.div>
        </div>

        {/* PERSONAL PREDICTABILITY EXAMPLE */}
        <div className="mt-40 space-y-10">
          <motion.div {...revealProps} className="max-w-3xl mx-auto text-center space-y-5">
            <p className="font-mono text-xs font-bold uppercase tracking-[0.15em] text-violet-600 dark:text-violet-400">Personal Predictability</p>
            <h2 className="font-display text-3xl sm:text-4xl md:text-5xl font-bold tracking-tight">
              Information + patterns = guessability
            </h2>
            <p className="font-mono text-base text-soot/70 dark:text-bone/60 leading-relaxed">
              When personal context combines with common password construction rules, the guessing space collapses dramatically.
            </p>
          </motion.div>

          <motion.div {...revealProps} className="max-w-2xl mx-auto">
            <Card className="space-y-6">
              <div>
                <div className="font-mono text-xs font-bold uppercase tracking-wide text-soot/50 dark:text-bone/40 mb-2">Example</div>
                <div className="font-display text-2xl font-bold mb-2">Max2004@Rover</div>
                <p className="font-mono text-sm text-soot/60 dark:text-bone/50">
                  Passes generic strength checks: 13 characters, mixed case, numbers, symbols.
                </p>
              </div>

              <div className="h-0.5 bg-paper-line dark:bg-ink-line" />

              <div>
                <div className="font-mono text-xs font-bold uppercase tracking-wide text-soot/50 dark:text-bone/40 mb-2">Targeted Reconstruction</div>
                <div className="font-mono text-base font-semibold mb-2">[First Name] + [Birth Year] + [@] + [Pet Name]</div>
                <p className="font-mono text-sm text-soot/60 dark:text-bone/50 mb-4">
                  An attacker who knows personal information can construct this password in fewer than 150 guesses.
                </p>
                <Badge variant="critical" icon={<i className="ti ti-flame" aria-hidden="true" />}>
                  Critical targeted risk
                </Badge>
              </div>
            </Card>
          </motion.div>
        </div>

        {/* PRIVACY */}
        <div className="mt-40 space-y-10">
          <motion.div {...revealProps} className="max-w-3xl mx-auto text-center space-y-5">
            <p className="font-mono text-xs font-bold uppercase tracking-[0.15em] text-violet-600 dark:text-violet-400">Privacy</p>
            <h2 className="font-display text-3xl sm:text-4xl md:text-5xl font-bold tracking-tight">
              Zero persistence
            </h2>
            <p className="font-mono text-base text-soot/70 dark:text-bone/60 leading-relaxed">
              Your information exists only in temporary memory during analysis. It is never stored, logged, or persisted.
            </p>
          </motion.div>

          <motion.div {...revealProps} className="max-w-2xl mx-auto grid grid-cols-1 sm:grid-cols-2 gap-3">
            {PRIVACY_POINTS.map((item) => (
              <div key={item} className="flex items-center gap-3 border-2 border-paper-line dark:border-ink-line bg-white dark:bg-ink-900 px-4 py-3">
                <i className="ti ti-circle-check text-violet-600 dark:text-violet-400 shrink-0" aria-hidden="true" />
                <span className="font-mono text-sm">{item}</span>
              </div>
            ))}
          </motion.div>
        </div>

        {/* FINAL CTA */}
        <div className="mt-40">
          <motion.div {...revealProps} className="max-w-3xl mx-auto text-center space-y-8">
            <h2 className="font-display text-3xl sm:text-4xl md:text-5xl font-bold tracking-tight">
              Analyze your password resistance
            </h2>
            <Button
              variant="primary"
              size="lg"
              icon={<i className="ti ti-arrow-right" aria-hidden="true" />}
              onClick={() => setStep('personal-info')}
            >
              Start Personal Analysis
            </Button>
          </motion.div>
        </div>

      </div>
    </div>
  );
};
