import React, { useRef, useState } from 'react';
import { motion } from 'framer-motion';
import { useAnalysis } from '../context/AnalysisContext';
import { Button } from '../components/ui/Button';
import { Input } from '../components/ui/Input';
import { ScrollDatePicker } from '../components/ui/ScrollDatePicker';
import { ScrollYearPicker } from '../components/ui/ScrollYearPicker';
import type { PersonalInfoState } from '../types';

interface FieldDef {
  key: keyof PersonalInfoState;
  label: string;
  placeholder?: string;
  multiline?: boolean;
  type?: string;
  kind?: 'text' | 'date-scroll' | 'year-scroll';
  yearRange?: [number, number];
}

interface SectionDef {
  id: string;
  tablerIcon: string;
  title: string;
  description: string;
  fields: FieldDef[];
}

const SECTIONS: SectionDef[] = [
  {
    id: 'identity',
    tablerIcon: 'ti-user',
    title: 'Identity',
    description: 'Names and identifiers that might appear in passwords',
    fields: [
      { key: 'firstName', label: 'First name' },
      { key: 'lastName', label: 'Last name' },
      { key: 'nickname', label: 'Nickname' },
      { key: 'initials', label: 'Initials' },
      { key: 'usernameAlias', label: 'Username / alias' },
    ],
  },
  {
    id: 'dates',
    tablerIcon: 'ti-calendar',
    title: 'Important Dates',
    description: 'Dates and years that could be incorporated into passwords',
    fields: [
      { key: 'dateOfBirth', label: 'Date of birth', kind: 'date-scroll' },
      { key: 'birthYear', label: 'Birth year', kind: 'year-scroll' },
      { key: 'importantDates', label: 'Important dates', placeholder: 'e.g., anniversaries, milestones (comma separated)', multiline: true },
      { key: 'importantYears', label: 'Important years', placeholder: 'e.g., graduation, marriage (comma separated)', multiline: true },
      { key: 'graduationYear', label: 'Graduation year', kind: 'year-scroll', yearRange: [new Date().getFullYear() - 60, new Date().getFullYear() + 10] },
    ],
  },
  {
    id: 'relationships',
    tablerIcon: 'ti-heart',
    title: 'Relationships',
    description: 'People who might be referenced in password construction',
    fields: [
      { key: 'partner', label: 'Partner / spouse name' },
      { key: 'familyMembers', label: 'Family members', placeholder: 'e.g., parents, siblings, children (comma separated)', multiline: true },
      { key: 'closeFriends', label: 'Close friends', placeholder: 'e.g., best friends, close colleagues (comma separated)', multiline: true },
    ],
  },
  {
    id: 'pets',
    tablerIcon: 'ti-dog',
    title: 'Pets',
    description: 'Pet names and related terms that could be password elements',
    fields: [
      { key: 'petNames', label: 'Pet names', placeholder: 'e.g., current and past pets (comma separated)', multiline: true },
      { key: 'petTerms', label: 'Other pet-related terms', placeholder: 'e.g., pet nicknames, breed names (comma separated)', multiline: true },
    ],
  },
  {
    id: 'geography',
    tablerIcon: 'ti-map-pin',
    title: 'Geography',
    description: 'Locations that might influence password choices',
    fields: [
      { key: 'city', label: 'Current city' },
      { key: 'town', label: 'Town / neighborhood' },
      { key: 'country', label: 'Country' },
      { key: 'previousLocations', label: 'Previous locations', placeholder: 'e.g., cities lived in (comma separated)', multiline: true },
    ],
  },
  {
    id: 'education',
    tablerIcon: 'ti-school',
    title: 'Education',
    description: 'Educational institutions and fields of study',
    fields: [
      { key: 'school', label: 'School' },
      { key: 'college', label: 'College' },
      { key: 'university', label: 'University' },
      { key: 'degreeBranch', label: 'Degree / branch' },
    ],
  },
  {
    id: 'work',
    tablerIcon: 'ti-briefcase',
    title: 'Work',
    description: 'Professional information that could inform password patterns',
    fields: [
      { key: 'company', label: 'Company' },
      { key: 'workplace', label: 'Workplace name' },
      { key: 'jobTitle', label: 'Job title' },
    ],
  },
  {
    id: 'interests',
    tablerIcon: 'ti-star',
    title: 'Interests',
    description: 'Hobbies, entertainment, and personal interests',
    fields: [
      { key: 'hobbies', label: 'Hobbies', placeholder: 'e.g., photography, cooking, woodworking (comma separated)', multiline: true },
      { key: 'sports', label: 'Sports', placeholder: 'e.g., tennis, swimming, cycling (comma separated)', multiline: true },
      { key: 'sportsTeams', label: 'Sports teams', placeholder: 'e.g., favorite teams (comma separated)', multiline: true },
      { key: 'games', label: 'Games', placeholder: 'e.g., video games, board games (comma separated)', multiline: true },
      { key: 'movies', label: 'Movies', placeholder: 'e.g., favorite films (comma separated)', multiline: true },
      { key: 'artists', label: 'Artists', placeholder: 'e.g., musicians, bands, painters (comma separated)', multiline: true },
      { key: 'books', label: 'Books', placeholder: 'e.g., favorite books or authors (comma separated)', multiline: true },
      { key: 'characters', label: 'Characters', placeholder: 'e.g., fictional characters (comma separated)', multiline: true },
      { key: 'otherInterests', label: 'Other interests', placeholder: 'e.g., other meaningful interests (comma separated)', multiline: true },
    ],
  },
  {
    id: 'digital',
    tablerIcon: 'ti-device-gamepad-2',
    title: 'Digital Identity',
    description: 'Online identities and gaming personas',
    fields: [
      { key: 'gamingNames', label: 'Gaming names', placeholder: 'e.g., gamertags, gaming aliases (comma separated)', multiline: true },
      { key: 'onlineAliases', label: 'Online aliases', placeholder: 'e.g., forum names, social handles (comma separated)', multiline: true },
    ],
  },
  {
    id: 'other',
    tablerIcon: 'ti-plus',
    title: 'Other',
    description: 'Any other personally meaningful words or numbers',
    fields: [
      { key: 'otherTerms', label: 'Other meaningful terms', placeholder: 'e.g., words, numbers, phrases (comma separated)', multiline: true },
    ],
  },
];

const DEV_PROFILE: PersonalInfoState = {
  firstName: 'Alex', lastName: 'Morgan', nickname: 'Lex', initials: 'AM', usernameAlias: 'alexm',
  birthYear: '1999', graduationYear: '2021', importantYears: '2017, 2021',
  partner: 'Jamie', familyMembers: 'Maya, Daniel', closeFriends: 'Sam, Chris',
  petNames: 'Nova', petTerms: 'Labrador', city: 'Pune', town: 'Kothrud', country: 'India', previousLocations: 'Nashik, Mumbai',
  school: 'Riverside School', college: 'Northbridge College', university: 'Northbridge University', degreeBranch: 'Computer Science',
  company: 'BluePeak', workplace: 'BluePeak Labs', jobTitle: 'Software Engineer',
  hobbies: 'Photography, hiking', sports: 'Football', sportsTeams: 'Arsenal', games: 'Minecraft', movies: 'Interstellar', artists: 'Daft Punk', books: 'Dune', characters: 'Paul Atreides', otherInterests: 'Astronomy',
  gamingNames: 'LexByte', onlineAliases: 'alexm_dev', otherTerms: 'Blue, 47',
};

export const PersonalInfoPage: React.FC = () => {
  const { personalInfo, updatePersonalInfo, clearPersonalInfo, setStep } = useAnalysis();
  const [showDevTools, setShowDevTools] = useState(false);
  const [expandedSection, setExpandedSection] = useState<string | null>('identity');
  const navigationRef = useRef<HTMLDivElement | null>(null);

  const handleContinue = () => setStep('password-input');

  const handleSectionToggle = (sectionId: string, isExpanded: boolean) => {
    const scrollY = window.scrollY;
    setExpandedSection(isExpanded ? null : sectionId);
    window.requestAnimationFrame(() => {
      window.scrollTo({ top: scrollY, left: 0, behavior: 'auto' });
    });
  };

  const loadDevProfile = () => {
    updatePersonalInfo(DEV_PROFILE);
    setShowDevTools(false);
    window.setTimeout(() => {
      navigationRef.current?.scrollIntoView({ behavior: 'smooth', block: 'center' });
    }, 80);
  };

  const clearDevProfile = () => {
    clearPersonalInfo();
    setShowDevTools(false);
  };

  const handleInputChange = (field: keyof PersonalInfoState, value: string) => {
    updatePersonalInfo({ [field]: value });
  };

  return (
    <div className="relative bg-paper-50 dark:bg-ink-950 text-soot dark:text-bone">
      <div className="relative max-w-4xl mx-auto px-6 pt-16 pb-24">

        {/* Header */}
        <motion.div initial={{ opacity: 0, y: 16 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.35 }} className="mb-10">
          <Button
            variant="ghost"
            size="sm"
            icon={<i className="ti ti-arrow-left" aria-hidden="true" />}
            onClick={() => setStep('landing')}
            className="mb-8"
          >
            Back to Overview
          </Button>

          <div className="relative space-y-4">
            <button
              type="button"
              onClick={() => setShowDevTools((value) => !value)}
              className="absolute right-0 top-0 w-10 h-10 border-2 border-paper-line dark:border-ink-line bg-paper-100 dark:bg-ink-850 hover:bg-violet-500 hover:text-soot transition-colors font-mono text-[10px] font-bold"
              title="Developer tools"
              aria-label="Developer tools"
            >
              DEV
            </button>
            {showDevTools && (
              <div className="absolute right-0 top-12 z-20 w-64 border-2 border-paper-line dark:border-ink-line bg-paper-50 dark:bg-ink-900 p-4 shadow-[5px_5px_0_rgba(0,0,0,0.25)]">
                <div className="flex items-center gap-2 mb-3">
                  <i className="ti ti-code" aria-hidden="true" />
                  <p className="font-mono text-[10px] font-bold uppercase tracking-widest">Developer tools</p>
                </div>
                <p className="font-mono text-[11px] leading-relaxed text-soot/55 dark:text-bone/45 mb-4">Load a fictional test profile into every field. No real person's data is used.</p>
                <div className="grid grid-cols-2 gap-2">
                  <button type="button" onClick={loadDevProfile} className="border-2 border-paper-line dark:border-ink-line px-3 py-2 bg-violet-500 text-soot font-mono text-[10px] font-bold uppercase hover:translate-x-[2px] hover:translate-y-[2px]">Fill demo</button>
                  <button type="button" onClick={clearDevProfile} className="border-2 border-paper-line dark:border-ink-line px-3 py-2 bg-paper-100 dark:bg-ink-850 font-mono text-[10px] font-bold uppercase hover:bg-paper-200 dark:hover:bg-ink-800">Clear</button>
                </div>
              </div>
            )}
            <h1 className="font-display text-3xl sm:text-4xl md:text-5xl font-bold tracking-tight">
              Personal Information
            </h1>
            <p className="font-mono text-base text-soot/70 dark:text-bone/60 leading-relaxed max-w-2xl">
              Targeted attackers often construct passwords using personal information that can be discovered through social media, public records, or casual observation. Provide information you suspect might have influenced your password construction.
            </p>
            <div className="flex items-center gap-2 font-mono text-xs text-soot/50 dark:text-bone/40">
              <i className="ti ti-lock" aria-hidden="true" />
              <span>All fields are optional &bull; Information used only for current analysis session</span>
            </div>
          </div>
        </motion.div>

        {/* Form Sections */}
        <div className="space-y-4">
          {SECTIONS.map((section, sectionIndex) => {
            const isExpanded = expandedSection === section.id;

            return (
              <motion.div
                key={section.id}
                initial={{ opacity: 0, y: 16 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.3, delay: sectionIndex * 0.03 }}
                className="border-2 border-paper-line dark:border-ink-line bg-white dark:bg-ink-900"
                style={{ overflowAnchor: 'none' }}
              >
                <button
                  type="button"
                  onClick={() => handleSectionToggle(section.id, isExpanded)}
                  className="w-full flex items-center gap-4 text-left p-5"
                >
                  <div className={`w-10 h-10 flex items-center justify-center shrink-0 border-2 border-paper-line dark:border-ink-line ${isExpanded ? 'bg-violet-500' : 'bg-paper-100 dark:bg-ink-850'}`}>
                    <i className={`ti ${section.tablerIcon} ${isExpanded ? 'text-soot' : 'text-soot/60 dark:text-bone/50'}`} style={{ fontSize: '18px' }} aria-hidden="true" />
                  </div>
                  <div className="flex-1 space-y-0.5">
                    <h3 className="font-display font-bold text-base">{section.title}</h3>
                    <p className="font-mono text-xs text-soot/50 dark:text-bone/40">{section.description}</p>
                  </div>
                  <motion.div animate={{ rotate: isExpanded ? 180 : 0 }} transition={{ duration: 0.15 }} className="shrink-0">
                    <i className="ti ti-chevron-down text-soot/60 dark:text-bone/50" aria-hidden="true" />
                  </motion.div>
                </button>

                {isExpanded && (
                  <motion.div
                    initial={{ opacity: 0, height: 0 }}
                    animate={{ opacity: 1, height: 'auto' }}
                    exit={{ opacity: 0, height: 0 }}
                    transition={{ duration: 0.2 }}
                    className="px-5 pb-5 pt-1 border-t-2 border-paper-line dark:border-ink-line space-y-4"
                  >
                    {section.fields.map((field) => {
                      if (field.kind === 'date-scroll') {
                        return (
                          <ScrollDatePicker
                            key={field.key}
                            label={field.label}
                            value={personalInfo[field.key]}
                            onChange={(v) => handleInputChange(field.key, v)}
                          />
                        );
                      }
                      if (field.kind === 'year-scroll') {
                        return (
                          <ScrollYearPicker
                            key={field.key}
                            label={field.label}
                            value={personalInfo[field.key]}
                            startYear={field.yearRange?.[0]}
                            endYear={field.yearRange?.[1]}
                            onChange={(v) => handleInputChange(field.key, v)}
                          />
                        );
                      }
                      return (
                        <Input
                          key={field.key}
                          label={field.label}
                          type={field.type || 'text'}
                          placeholder={field.placeholder}
                          multiline={field.multiline}
                          rows={field.multiline ? 3 : undefined}
                          value={personalInfo[field.key] || ''}
                          onChange={(e) => handleInputChange(field.key, e.target.value)}
                        />
                      );
                    })}
                  </motion.div>
                )}
              </motion.div>
            );
          })}
        </div>

        {/* Navigation */}
        <motion.div
          ref={navigationRef}
          initial={{ opacity: 0, y: 16 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.35, delay: 0.2 }}
          className="mt-10 pt-8 border-t-2 border-paper-line dark:border-ink-line flex flex-col sm:flex-row items-center justify-between gap-4"
        >
          <div className="flex items-center gap-2 font-mono text-xs text-soot/50 dark:text-bone/40">
            <i className="ti ti-lock" aria-hidden="true" />
            <span>Information persists only in current session memory</span>
          </div>

          <Button
            variant="primary"
            size="lg"
            icon={<i className="ti ti-arrow-right" aria-hidden="true" />}
            onClick={handleContinue}
          >
            Continue to Password Analysis
          </Button>
        </motion.div>

      </div>
    </div>
  );
};
