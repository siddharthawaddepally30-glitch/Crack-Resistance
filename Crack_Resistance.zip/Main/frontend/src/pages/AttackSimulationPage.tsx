import React from 'react';
import { motion } from 'framer-motion';
import { useAnalysis } from '../context/AnalysisContext';
import { Button } from '../components/ui/Button';
import { Card } from '../components/ui/Card';

const stepBadge = 'font-mono text-xs font-bold border-2 border-red-500 bg-red-50 text-red-700 dark:bg-red-950/30 dark:text-red-300 px-2 py-1 shadow-[3px_3px_0_rgba(239,68,68,0.22)]';

export const AttackSimulationPage: React.FC = () => {
  const { analysisResult, setStep } = useAnalysis();
  const findings = analysisResult?.stage3.findings ?? [];

  return (
    <div className="min-h-[80vh] bg-paper-50 dark:bg-ink-950 text-soot dark:text-bone">
      <div className="max-w-4xl mx-auto px-6 pt-10 pb-24">
        <Button variant="ghost" size="sm" icon={<i className="ti ti-arrow-left" aria-hidden="true" />} onClick={() => setStep('personal-analysis')} className="mb-7">
          Back to personal analysis
        </Button>

        <motion.div initial={{ opacity: 0, y: 14 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: .3 }}>
          <div className="mb-8">
            <div className="inline-flex items-center gap-2 font-mono text-[10px] uppercase tracking-widest text-violet-600 dark:text-violet-400 mb-3">
              <i className="ti ti-route" aria-hidden="true" />
              <span>Stage 4 · Personal Attack Simulation</span>
            </div>
            <h1 className="font-display text-4xl sm:text-5xl font-bold tracking-tight">How could someone who knows you think?</h1>
            <p className="font-mono text-sm leading-relaxed text-soot/65 dark:text-bone/55 max-w-3xl mt-4">
              A password can be difficult for a stranger to guess and still be easier for someone who knows you. This page turns the personal links found earlier into an understandable picture of how a targeted guesser could organise their reasoning.
            </p>
          </div>

          <Card accent>
            <div className="flex gap-4 items-start">
              <i className="ti ti-bulb text-violet-600 dark:text-violet-400 text-2xl mt-0.5" aria-hidden="true" />
              <div>
                <p className="font-mono text-[10px] uppercase tracking-widest text-soot/45 dark:text-bone/35">First, what is a targeted guess?</p>
                <p className="font-mono text-sm leading-relaxed mt-3 text-soot/75 dark:text-bone/65">
                  A general attacker starts with common password habits because they know very little about you. A targeted guesser has extra clues: your name, favourite game, team, important year, nickname, location, or another detail. Those clues help them decide which kinds of password constructions are worth considering first. This page models that <strong>reasoning process</strong>, not a real attack.
                </p>
              </div>
            </div>
          </Card>

          <section className="mt-9">
            <div className="flex items-center gap-3 mb-4">
              <span className={stepBadge}>01</span>
              <div>
                <p className="font-mono text-[10px] uppercase tracking-widest text-soot/45 dark:text-bone/35">What the simulation shows</p>
                <h2 className="font-display text-2xl font-bold mt-1">From known information to a focused guessing path</h2>
              </div>
            </div>
            <div className="grid gap-3">
              {[
                ['Start with known information', 'A targeted guesser begins with details already associated with you. They are not starting from every possible string in the universe.'],
                ['Look for the password connection', 'They check whether part of the password resembles a name, game, place, team, important year, relationship term, or another known detail.'],
                ['Notice familiar construction choices', 'Once a useful personal clue appears, familiar additions such as a capital letter, a number, a symbol, or a known sequence can become part of the reasoning.'],
                ['Combine clues', 'Two or more personal relationships can reinforce each other. A name plus a favourite game plus a personal number is more informative than any one clue alone.'],
                ['Prioritise likely paths', 'The point of targeted guessing is to reduce uncertainty. Personal clues help a guesser decide which constructions are more worth considering before less plausible ones.'],
              ].map(([title, body]) => (
                <Card key={title} className="!p-5">
                  <p className="font-display text-lg font-bold">{title}</p>
                  <p className="font-mono text-sm leading-relaxed text-soot/65 dark:text-bone/55 mt-2">{body}</p>
                </Card>
              ))}
            </div>
          </section>

          <section className="mt-9">
            <div className="flex items-center gap-3 mb-4">
              <span className={stepBadge}>02</span>
              <div>
                <p className="font-mono text-[10px] uppercase tracking-widest text-soot/45 dark:text-bone/35">Your evidence</p>
                <h2 className="font-display text-2xl font-bold mt-1">The simulation follows your actual findings</h2>
              </div>
            </div>
            <p className="font-mono text-sm leading-relaxed text-soot/65 dark:text-bone/55 mb-4">
              Stage 4 does not invent a personal story. It uses the relationships detected in Stage 3. Each finding below is one piece of evidence that could influence targeted reasoning.
            </p>
            {findings.length > 0 ? (
              <div className="space-y-3">
                {findings.map((finding, index) => (
                  <Card key={finding.id} className="!p-5">
                    <div className="flex gap-4 items-start">
                      <span className={stepBadge}>{String(index + 1).padStart(2, '0')}</span>
                      <div>
                        <p className="font-mono text-[10px] uppercase tracking-widest text-violet-600 dark:text-violet-400">{finding.category}</p>
                        <h3 className="font-display text-lg font-bold mt-1">{finding.label}</h3>
                        <p className="font-mono text-sm leading-relaxed text-soot/65 dark:text-bone/55 mt-2">{finding.explanation}</p>
                        <p className="font-mono text-xs leading-relaxed text-soot/50 dark:text-bone/45 mt-3"><span className="font-bold">Why it matters:</span> {finding.whyItMatters}</p>
                      </div>
                    </div>
                  </Card>
                ))}
              </div>
            ) : (
              <Card className="!p-5">
                <p className="font-display text-lg font-bold">No strong personal clue was identified</p>
                <p className="font-mono text-sm leading-relaxed text-soot/65 dark:text-bone/55 mt-2">This stage has little personal evidence to work with. The password can still have generic and structural weaknesses from earlier stages.</p>
              </Card>
            )}
          </section>

          <section className="mt-9">
            <div className="flex items-center gap-3 mb-4">
              <span className={stepBadge}>03</span>
              <div>
                <p className="font-mono text-[10px] uppercase tracking-widest text-soot/45 dark:text-bone/35">Safety boundary</p>
                <h2 className="font-display text-2xl font-bold mt-1">This is an educational simulation</h2>
              </div>
            </div>
            <Card>
              <ul className="space-y-3 font-mono text-sm leading-relaxed text-soot/70 dark:text-bone/60 list-disc pl-5">
                <li>It does not attempt to log into an account.</li>
                <li>It does not contact a website, application, server, or authentication service.</li>
                <li>It does not perform password cracking against a real target.</li>
                <li>It does not reveal a list of actual passwords to try.</li>
                <li>It does not claim an exact crack time for the password.</li>
                <li>It explains the reasoning pattern behind targeted guessing so the user can understand why personal information matters.</li>
              </ul>
            </Card>
          </section>

          <Card className="mt-8">
            <div className="flex gap-4 items-start">
              <i className="ti ti-arrow-right-circle text-violet-600 dark:text-violet-400 text-xl mt-0.5" aria-hidden="true" />
              <div>
                <p className="font-mono text-[10px] uppercase tracking-widest text-soot/45 dark:text-bone/35">Next</p>
                <p className="font-display text-xl font-bold mt-1">Now check how independent the password is from your personal information.</p>
                <p className="font-mono text-sm leading-relaxed mt-2 text-soot/65 dark:text-bone/55">The next page introduces Personal Unrelatedness Analysis and the private-association exercise.</p>
              </div>
            </div>
          </Card>

          <div className="mt-8 flex justify-between gap-3">
            <Button variant="ghost" onClick={() => setStep('personal-analysis')} icon={<i className="ti ti-arrow-left" aria-hidden="true" />}>Back</Button>
            <Button onClick={() => setStep('unrelatedness')} icon={<i className="ti ti-arrow-right" aria-hidden="true" />}>Personal Unrelatedness</Button>
          </div>
        </motion.div>
      </div>
    </div>
  );
};
