import type { PersonalInfoState } from '../types';
import type { AnalysisRequest, AnalysisResult } from '../analysis/types';
import { analyzeRisk } from '../analysis/risk/analyzeRisk';
import { analyzePatterns } from '../analysis/patterns/analyzePatterns';
import { analyzePersonal } from '../analysis/personal/analyzePersonal';
import { analyzeUnrelatedness } from '../analysis/unrelatedness/analyzeUnrelatedness';

export async function analyzePassword(request: AnalysisRequest): Promise<AnalysisResult> {
  const stage1 = analyzeRisk(request.password);
  const patternResult = await analyzePatterns(request.password);
  const stage3 = await analyzePersonal(request.password, request.personalInfo);
  const stage5 = await analyzeUnrelatedness(request.password, request.personalInfo, stage3.findings.length);
  const summary = patternResult.findings.length
    ? `${patternResult.findings.length} construction patterns were identified using deterministic checks plus the trained pattern-intelligence model.`
    : 'No strong construction pattern was found by the current rules or trained pattern model.';
  return {
    version: '0.8.0-pattern-ml-personal-ml-unrelatedness-page-report',
    completedAt: new Date().toISOString(),
    stage1,
    stage2: { findings: patternResult.findings, patternCount: patternResult.findings.length, summary, ml: patternResult.ml },
    stage3,
    stage5,
  };
}
export type { PersonalInfoState };
