import React, { useEffect, useRef } from 'react';
import { AnalysisProvider, useAnalysis } from './context/AnalysisContext';
import { Navbar } from './components/layout/Navbar';
import { Footer } from './components/layout/Footer';
import { LandingPage } from './pages/LandingPage';
import { PersonalInfoPage } from './pages/PersonalInfoPage';
import { PasswordInputPage } from './pages/PasswordInputPage';
import { ReportPage } from './pages/ReportPage';
import { UnrelatednessPage } from './pages/UnrelatednessPage';
import { PersonalAnalysisPage } from './pages/PersonalAnalysisPage';
import { PatternAnalysisPage } from './pages/PatternAnalysisPage';
import { AttackSimulationPage } from './pages/AttackSimulationPage';
import { RecommendationPage } from './pages/RecommendationPage';

const AppContent: React.FC = () => {
  const { currentStep } = useAnalysis();
  const previousStepRef = useRef(currentStep);

  useEffect(() => {
    if (previousStepRef.current === currentStep) return;
    previousStepRef.current = currentStep;
    window.scrollTo({ top: 0, left: 0, behavior: 'auto' });
  }, [currentStep]);

  return (
    <div className="min-h-screen flex flex-col bg-paper-50 dark:bg-ink-950 text-soot dark:text-bone antialiased transition-colors duration-150">
      <Navbar />
      
      <main className="flex-1">
        {currentStep === 'landing' && <LandingPage />}
        {currentStep === 'personal-info' && <PersonalInfoPage />}
        {currentStep === 'password-input' && <PasswordInputPage />}
        {currentStep === 'pattern-analysis' && <PatternAnalysisPage />}
        {currentStep === 'personal-analysis' && <PersonalAnalysisPage />}
        {currentStep === 'attack-simulation' && <AttackSimulationPage />}
        {currentStep === 'unrelatedness' && <UnrelatednessPage />}
        {currentStep === 'report' && <ReportPage />}
        {currentStep === 'recommendation' && <RecommendationPage />}
      </main>

      <Footer />
    </div>
  );
};

export const App: React.FC = () => {
  return (
    <AnalysisProvider>
      <AppContent />
    </AnalysisProvider>
  );
};

export default App;
