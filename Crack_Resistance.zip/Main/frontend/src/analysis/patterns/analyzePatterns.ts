import type { PatternFinding } from '../types';
import { analyzePatternRules } from './analyzePatternRules';
import { predictPatterns } from '../ml/patternModel';

const LABEL_TO_FINDING: Record<string, Partial<PatternFinding>> = {
  abbreviation_like: { category:'Token shape', construction:'POSSIBLE ABBREVIATION' },
  mnemonic_like: { category:'Token shape', construction:'POSSIBLE INITIALISM / MNEMONIC' },
  short_alpha_token: { category:'Token shape', construction:'SHORT ALPHABETIC TOKEN' },
  camel_case: { category:'Capitalization', construction:'CAMEL-CASE WORD COMBINATION' },
  mixed_separators: { category:'Separators', construction:'MULTIPLE SYMBOL SEPARATORS' },
  common_suffix: { category:'Position', construction:'COMMON PASSWORD SUFFIX' },
  common_prefix: { category:'Position', construction:'COMMON PASSWORD PREFIX' },
  long_digit_block: { category:'Numbers', construction:'LONG NUMBER BLOCK' },
};
const TAKEAWAYS: Record<string, string> = {
  abbreviation_like:'A short token may hide a longer personal word or phrase once context is known.',
  mnemonic_like:'Initials can carry meaning even when the password itself does not show the full phrase.',
  short_alpha_token:'Short alphabetic pieces are worth interpreting before treating them as random.',
  camel_case:'Capitalising the next word is a formatting change, not a source of randomness.',
  mixed_separators:'Extra punctuation can follow familiar placement recipes just as easily as one symbol.',
  common_suffix:'Attackers can add familiar endings to otherwise plausible password bases.',
  common_prefix:'Common numeric prefixes can be tested without knowing the rest of the password.',
  long_digit_block:'The meaning and construction of a number block matter more than its length alone.',
};

export interface PatternAnalysisMeta { status:'not-trained'|'trained'; modelVersion:string|null; }

export async function analyzePatterns(password: string): Promise<{ findings: PatternFinding[]; ml: PatternAnalysisMeta }> {
  const findings = analyzePatternRules(password);
  const ml = await predictPatterns(password);
  const ruleIds = new Set(findings.map((f) => f.id));
  for (const prediction of ml.predictions.slice(0, 10)) {
    if (prediction.probability < 0.83) continue;
    const mapped = LABEL_TO_FINDING[prediction.label];
    if (!mapped || ruleIds.has(prediction.label) || findings.some((f) => f.construction === mapped.construction)) continue;
    findings.push({
      id:`ml-${prediction.label}`,
      category:mapped.category ?? 'ML pattern intelligence',
      construction:mapped.construction ?? prediction.label.replaceAll('_',' ').toUpperCase(),
      confidence:prediction.probability >= 0.92 ? 'high' : 'medium',
      explanation:`The trained pattern model found a ${prediction.label.replaceAll('_',' ')} pattern with ${(prediction.probability*100).toFixed(0)}% model confidence. This is treated as an additional signal, not as proof by itself.`,
      whyItMatters:'The model is trained on many examples of recurring password construction patterns and can surface patterns that are easy to miss with simple rules.',
      userTakeaway:TAKEAWAYS[prediction.label] ?? 'A repeated construction can be predictable even when the final password looks more varied.',
    });
  }
  return { findings: findings.slice(0, 18), ml:{ status: ml.modelVersion ? 'trained' : 'not-trained', modelVersion:ml.modelVersion } };
}

export { analyzePatternRules };
