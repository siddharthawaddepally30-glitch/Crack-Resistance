import type { PersonalInfoState } from '../../types';
import type { PersonalFinding, PersonalRiskLevel, Stage3Result } from '../types';
import { getPersonalLexicon, predictPersonalRelationship, scorePersonalModel, type PersonalRelationshipLabel } from '../ml/personalModel';

const STOP = new Set(['the','and','for','with','from','this','that','your','name','city','town','india','college','school','university']);

function clean(value: string) { return value.trim().toLowerCase(); }
function splitField(value: string | undefined) { return value ? value.split(/[,;\n|]+/).map(clean).filter(Boolean) : []; }
function splitCamel(value: string) { return value.replace(/([a-z])([A-Z])/g,'$1 $2').split(/\s+/).filter(Boolean); }
function wordTokens(value: string) { return splitCamel(value.toLowerCase()).join(' ').split(/[^a-z0-9]+/).filter((t) => t.length >= 2 && !STOP.has(t)); }
function compact(value: string) { return clean(value).replace(/[^a-z0-9]/g,''); }
function initials(value: string) { const parts = wordTokens(value); return parts.length > 1 ? parts.map((p) => p[0]).join('') : ''; }

const fields: Array<[keyof PersonalInfoState,string]> = [
  ['firstName','first name'],['lastName','last name'],['nickname','nickname'],['initials','initials'],['usernameAlias','username / alias'],
  ['partner','partner'],['familyMembers','family'],['closeFriends','friends'],['petNames','pet name'],['petTerms','pet term'],
  ['city','city'],['town','town'],['country','country'],['previousLocations','previous location'],['school','school'],['college','college'],['university','university'],['degreeBranch','degree / branch'],
  ['company','company'],['workplace','workplace'],['jobTitle','job title'],['hobbies','hobby'],['sports','sport'],['sportsTeams','sports team'],['games','games'],['movies','movie'],['artists','artist'],['books','book'],['characters','character'],['otherInterests','interest'],
  ['gamingNames','gaming name'],['onlineAliases','online alias'],['otherTerms','other meaningful term'],
];

interface PersonalEntry { value:string; source:string; field:keyof PersonalInfoState; }
function buildEntries(info: PersonalInfoState): PersonalEntry[] {
  const out: PersonalEntry[] = [];
  for (const [field, source] of fields) for (const value of splitField(info[field])) out.push({ value, source, field });
  return out;
}
function passwordFragments(password: string): string[] {
  const set = new Set<string>();
  for (const match of password.match(/[A-Za-z0-9]+/g) ?? []) {
    const parts = splitCamel(match);
    for (const part of parts) {
      const c = compact(part); if (c.length >= 2) set.add(c);
      if (c.length <= 6) set.add(c);
    }
  }
  for (const match of password.match(/[A-Z]{2,8}/g) ?? []) set.add(match.toLowerCase());
  return [...set].filter((value) => value.length >= 2 && value.length <= 18).slice(0, 80);
}
function numbersIn(value: string) { return value.replace(/\D/g,''); }

function addFinding(findings: PersonalFinding[], finding: PersonalFinding) {
  const key = `${finding.category}|${finding.source}|${finding.label}`;
  if (!findings.some((x) => `${x.category}|${x.source}|${x.label}` === key)) findings.push(finding);
}

function lexiconRelation(fragment: string, personal: string, source: string, lexicon: Awaited<ReturnType<typeof getPersonalLexicon>>) : PersonalRelationshipLabel | null {
  if (!lexicon) return null;
  const f = fragment.toLowerCase(); const p = personal.toLowerCase();
  if (f === p || compact(f) === compact(p)) return 'direct';
  for (const [full, abbrs] of Object.entries(lexicon.abbreviations)) {
    if (p.includes(full) && abbrs.some((a) => a.toLowerCase() === f)) return 'abbreviation';
  }
  for (const [phrase, forms] of Object.entries(lexicon.mnemonics)) if (p.includes(phrase) && forms.some((x) => x.toLowerCase() === f)) return 'mnemonic';
  const semanticLists = Object.entries(lexicon.semantic);
  for (const [topic, related] of semanticLists) {
    const topicMatch = p.includes(topic);
    const relatedMatch = related.some((r) => r === f);
    if (topicMatch && relatedMatch) return 'semantic';
  }
  return null;
}

export async function analyzePersonal(password: string, info: PersonalInfoState): Promise<Stage3Result> {
  const findings: PersonalFinding[] = [];
  const entries = buildEntries(info);
  const fragments = passwordFragments(password);
  const lexicon = await getPersonalLexicon();

  // Direct, derived and numeric evidence is deterministic and therefore remains higher-confidence than ML.
  for (const entry of entries) {
    const normal = compact(entry.value);
    if (!normal || normal.length < 3) continue;
    if (password.toLowerCase().includes(normal)) {
      addFinding(findings,{id:`direct-${entry.source}-${normal}`,category:'Direct match',label:`“${normal}” matches your ${entry.source}`,source:entry.source,confidence:'high',explanation:`The password directly contains “${normal}”, which you supplied as your ${entry.source}.`,whyItMatters:'A targeted guesser could try this known personal detail early.'});
    }
    const initialsValue=initials(entry.value);
    if (initialsValue && password.toLowerCase().includes(initialsValue) && initialsValue.length >= 2) {
      addFinding(findings,{id:`initials-${entry.source}-${initialsValue}`,category:'Initialism',label:`“${initialsValue}” can represent your ${entry.source}`,source:entry.source,confidence:'high',explanation:`The password contains “${initialsValue}”, the initials of “${entry.value}”.`,whyItMatters:'Initials compress a known personal term into a short token without removing its meaning.'});
    }
  }

  for (const [field,label] of [[info.dateOfBirth,'date of birth'],[info.birthYear,'birth year'],[info.importantDates,'important date'],[info.importantYears,'important year'],[info.graduationYear,'graduation year'],[info.otherTerms,'other meaningful term']] as Array<[string|undefined,string]>) {
    for (const raw of splitField(field)) { const d=numbersIn(raw); if (d.length>=2 && password.includes(d)) addFinding(findings,{id:`number-${d}`,category:'Personal number',label:`Contains the personal number “${d}”`,source:label,confidence:'high',explanation:`The number “${d}” appears in the password and matches information you supplied under ${label}.`,whyItMatters:'A known date, year or personal number can sharply narrow targeted guesses.'}); }
  }

  // The trained model is applied only to plausible fragment/context pairs. Lexicon matches are used as strong contextual evidence; ML expands beyond the fixed lexicon.
  const candidates: Array<{fragment:string; entry:PersonalEntry; prediction?:Awaited<ReturnType<typeof predictPersonalRelationship>>; relation:PersonalRelationshipLabel|null}> = [];
  const semanticFields = new Set<keyof PersonalInfoState>(['games','sports','sportsTeams','hobbies','movies','artists','books','characters','otherInterests','gamingNames','onlineAliases']);
  for (const fragment of fragments.slice(0,36)) {
    const shortlist = entries.filter((entry) => {
      const p=compact(entry.value); if (!p || p===fragment) return false;
      const lex=lexiconRelation(fragment,p,entry.source,lexicon);
      const lexical = p.startsWith(fragment.slice(0, Math.min(3, fragment.length))) || fragment.startsWith(p.slice(0, Math.min(3, p.length))) || p[0] === fragment[0];
      return !!lex || lexical || semanticFields.has(entry.field);
    }).slice(0,18);
    for (const entry of shortlist) {
      const p=compact(entry.value);
      const lex=lexiconRelation(fragment,p,entry.source,lexicon);
      const prediction=await predictPersonalRelationship(fragment,entry.value);
      const relation=lex ?? prediction?.label ?? null;
      if (relation) candidates.push({fragment,entry,prediction,relation});
    }
  }

  const seen=new Set<string>();
  for (const candidate of candidates.sort((a,b)=>(b.prediction?.confidence ?? 0)-(a.prediction?.confidence ?? 0))) {
    const relation=candidate.relation; const confidence=candidate.prediction?.confidence ?? 0;
    if (!relation || relation==='unrelated' || seen.has(`${candidate.fragment}|${candidate.entry.source}|${relation}`)) continue;
    const accepted = relation==='abbreviation' ? confidence>=0.78 || lexiconRelation(candidate.fragment,compact(candidate.entry.value),candidate.entry.source,lexicon)==='abbreviation'
      : relation==='mnemonic' ? confidence>=0.85 || lexiconRelation(candidate.fragment,compact(candidate.entry.value),candidate.entry.source,lexicon)==='mnemonic'
      : relation==='semantic' ? confidence>=0.82 || lexiconRelation(candidate.fragment,compact(candidate.entry.value),candidate.entry.source,lexicon)==='semantic'
      : false;
    if (!accepted) continue;
    seen.add(`${candidate.fragment}|${candidate.entry.source}|${relation}`);
    const labelMap: Record<string,string>={abbreviation:'Possible abbreviation',mnemonic:'Possible mnemonic / initialism',semantic:'Related idea'};
    const relationWord=relation==='abbreviation'?'abbreviation of':relation==='mnemonic'?'mnemonic / initialism for':'related to';
    addFinding(findings,{id:`ml-${relation}-${candidate.fragment}-${candidate.entry.source}`,category:labelMap[relation] ?? 'Contextual relationship',label:`“${candidate.fragment}” may be ${relationWord} your ${candidate.entry.source}`,source:candidate.entry.source,confidence:(confidence>=0.82 || lexiconRelation(candidate.fragment,compact(candidate.entry.value),candidate.entry.source,lexicon))?'high':'medium',explanation:`The password contains “${candidate.fragment}”. The relationship layer connected it to “${candidate.entry.value}” from your ${candidate.entry.source}${candidate.prediction ? `; the trained model classified the relationship as ${relation} with ${(confidence*100).toFixed(0)}% confidence.` : '.'}`,whyItMatters:'Compact or related forms can reveal personal meaning that is invisible from exact string matching alone.',evidence:[`Password fragment: ${candidate.fragment}`,`Personal information: ${candidate.entry.value}`,`Relationship type: ${relation}`]});
  }

  const compactFindings=findings.slice(0,10);
  const direct=compactFindings.filter((x)=>x.category==='Direct match').length;
  const derived=compactFindings.filter((x)=>x.category==='Initialism').length;
  const numeric=compactFindings.filter((x)=>x.category==='Personal number').length;
  const semantic=compactFindings.filter((x)=>x.category==='Related idea').length;
  const contextual=compactFindings.filter((x)=>['Possible abbreviation','Possible mnemonic / initialism'].includes(x.category)).length;
  const score=Math.min(100,direct*26+derived*18+numeric*25+semantic*14+contextual*12+(compactFindings.length>=3?10:0));
  const level:PersonalRiskLevel=score>=75?'critical':score>=50?'high':score>=25?'medium':'low';
  const summary=compactFindings.length===0
    ? 'No strong personal relationship was found. The next stage can therefore focus less on personal clues and more on how a targeted guesser would reason from other evidence.'
    : `Found ${compactFindings.length} distinct personal clue${compactFindings.length===1?'':'s'} across direct matches, numbers, initials, abbreviations, mnemonic structures and semantic relationships. These clues show how knowledge about you could narrow a guessing path.`;
  const ml=await scorePersonalModel();
  return { riskLevel:level, riskScore:score, findings:compactFindings, summary, matchedSignals:compactFindings.map((f)=>f.label), ml };
}
