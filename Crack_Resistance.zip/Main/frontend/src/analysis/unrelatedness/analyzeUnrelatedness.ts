import type { PersonalInfoState } from '../../types';
import { getPersonalLexicon } from '../ml/personalModel';
import { predictRelatedness, getUnrelatednessModelStatus } from '../ml/unrelatednessModel';
import { UNRELATED_TOPIC_POOL } from './topicPool';

export interface UnrelatednessDimension { name:'direct'|'derived'|'numeric'|'semantic'|'construction'; score:number; explanation:string; }
export interface UnrelatednessResult { score:number; dimensions:UnrelatednessDimension[]; topicChecks: Array<{topic:string; relatedProbability:number|null; related:boolean; modelVersion:string|null}>; ml:{status:'trained'|'not-trained'; modelVersion:string|null; accuracy:number|null}; }

function values(info:PersonalInfoState): string[] {
  return Object.values(info).flatMap((v)=>typeof v==='string'?v.split(/[,;\n|]+/).map((x)=>x.trim()).filter(Boolean):[]).slice(0,100);
}
export async function analyzeUnrelatedness(password:string, info:PersonalInfoState, personalFindingCount:number): Promise<UnrelatednessResult> {
  const personalValues=values(info);
  const topics=[...UNRELATED_TOPIC_POOL].slice(0, personalValues.length ? 8 : 5);
  const topicChecks=[] as UnrelatednessResult['topicChecks'];
  for(const topic of topics) {
    let best:number|null=null; let version:string|null=null;
    for(const value of personalValues.slice(0,30)) {
      const result=await predictRelatedness(topic,value); if(result && (best===null || result.relatedProbability>best)){best=result.relatedProbability; version=result.modelVersion;}
    }
    topicChecks.push({topic,relatedProbability:best,related:(best??0)>=0.55,modelVersion:version});
  }
  const direct=personalFindingCount===0?100:Math.max(0,100-personalFindingCount*30);
  const derived=personalFindingCount===0?100:Math.max(10,100-personalFindingCount*22);
  const numeric=personalValues.some(v=>/\d/.test(v)&&password.includes(v.replace(/\D/g,'')))?0:100;
  const semantic=topicChecks.length ? Math.round((topicChecks.reduce((sum,t)=>sum+(t.related?35:100),0))/topicChecks.length) : 100;
  const construction=personalFindingCount>=3?35:personalFindingCount>=1?65:100;
  const dimensions=[
    {name:'direct',score:direct,explanation:'How independent the password is from direct personal matches.'},
    {name:'derived',score:derived,explanation:'How independent it is from shortened, initial or transformed personal terms.'},
    {name:'numeric',score:numeric,explanation:'How independent it is from personal dates, years or other numbers.'},
    {name:'semantic',score:semantic,explanation:'How independent the concepts are from the supplied personal information.'},
    {name:'construction',score:construction,explanation:'How independent the overall construction is from a familiar personal recipe.'},
  ] as UnrelatednessDimension[];
  const score=Math.round(dimensions.reduce((s,d)=>s+d.score,0)/dimensions.length);
  const ml=await getUnrelatednessModelStatus();
  return {score,dimensions,topicChecks,ml};
}
