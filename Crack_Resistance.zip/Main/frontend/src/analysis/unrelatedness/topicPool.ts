export const UNRELATED_TOPIC_POOL = [
  'volcanology', 'mineralogy', 'botany', 'astronomy', 'geology', 'archaeology', 'meteorology', 'cartography',
  'paleontology', 'mycology', 'zoology', 'ornithology', 'entomology', 'oceanography', 'typography', 'calligraphy',
  'etymology', 'acoustics', 'ceramics', 'folklore', 'woodworking', 'weaving', 'origami', 'astronomy', 'ecology',
  'sundial', 'weathervane', 'compass', 'hourglass', 'abacus', 'thimble', 'trellis', 'turnstile', 'kaleidoscope',
  'stained glass', 'fountain pen', 'paperweight', 'wind chime', 'lantern', 'anvil', 'quilt', 'stencil', 'pinwheel',
  'bookplate', 'bookmark', 'postcard', 'wooden crate', 'lighthouse', 'greenhouse', 'observatory', 'planetarium',
  'rainfall', 'clouds', 'tides', 'moonlight', 'sunset', 'river', 'meadow', 'orchard', 'marshland', 'canyon',
  'breeze', 'pebbles', 'driftwood', 'shells', 'pinecones', 'moss', 'ivy', 'wildflowers', 'dandelion', 'acorn',
  'tea kettle', 'hourglass', 'chessboard', 'typewriter', 'vinyl record', 'music box', 'paper lantern', 'glass bottle',
  'bridge', 'fountain', 'clock tower', 'stone arch', 'wooden bench', 'market stall', 'train platform', 'old map',
  'basket', 'umbrella', 'backpack', 'candle', 'mirror', 'pocket watch', 'shoelace', 'ribbon', 'button', 'keyhole',
  'paper clip', 'rubber band', 'soap bar', 'ceramic mug', 'wooden spoon', 'compass rose', 'garden gate', 'birdhouse'
] as const;

export type UnrelatedTopic = typeof UNRELATED_TOPIC_POOL[number];
