import type { PersonalInfoState } from '../types';

export type RiskLevel = 'low' | 'medium' | 'high' | 'critical';

export interface FeatureVector {
  length: number;
  lowercaseCount: number;
  uppercaseCount: number;
  digitCount: number;
  symbolCount: number;
  wordCount: number;
  uniqueCharacterRatio: number;
  repeatedCharacterRun: number;
  repeatedBlockLength: number;
  sequentialRun: number;
  dictionaryTokenCount: number;
  hasDateLikeStructure: boolean;
  hasYearLikeStructure: boolean;
  hasKeyboardPattern: boolean;
  transformationCount: number;
  hasPredictableSuffix: boolean;
  hasPredictablePrefix: boolean;
  hasOnlyOneCharacterClass: boolean;
}

export interface RiskSignal {
  id: string;
  label: string;
  level: RiskLevel;
  explanation: string;
  action: string;
}

export interface PatternFinding {
  id: string;
  category: string;
  construction: string;
  confidence: 'low' | 'medium' | 'high';
  explanation: string;
  whyItMatters: string;
  userTakeaway?: string;
}

export interface MlSignal {
  status: 'not-trained' | 'trained';
  score: number | null;
  label: 'not-available' | 'low' | 'medium' | 'high' | 'critical';
  modelVersion: string | null;
}

export interface PersonalMlSignal {
  status: 'not-trained' | 'trained';
  modelVersion: string | null;
  purpose: 'semantic-and-contextual-analysis';
}

export interface Stage1Result {
  riskLevel: RiskLevel;
  riskScore: number;
  signals: RiskSignal[];
  features: FeatureVector;
  dictionaryMatch: boolean;
  datasetStatus: 'starter-lexicon' | 'project-dataset';
}

export interface PatternMlSignal { status: 'not-trained' | 'trained'; modelVersion: string | null; }

export interface Stage2Result {
  findings: PatternFinding[];
  patternCount: number;
  summary: string;
  ml: PatternMlSignal;
}


export type PersonalRiskLevel = 'low' | 'medium' | 'high' | 'critical';

export interface PersonalFinding {
  id: string;
  category: string;
  label: string;
  source: string;
  confidence: 'medium' | 'high';
  explanation: string;
  whyItMatters: string;
  evidence?: string[];
}

export interface Stage3Result {
  riskLevel: PersonalRiskLevel;
  riskScore: number;
  findings: PersonalFinding[];
  summary: string;
  matchedSignals: string[];
  ml: PersonalMlSignal;
}


export interface UnrelatednessDimension { name: 'direct' | 'derived' | 'numeric' | 'semantic' | 'construction'; score: number; explanation: string; }
export interface UnrelatednessResult { score: number; dimensions: UnrelatednessDimension[]; topicChecks: Array<{ topic: string; relatedProbability: number | null; related: boolean; modelVersion: string | null }>; ml: { status: 'trained' | 'not-trained'; modelVersion: string | null; accuracy: number | null }; }

export interface AnalysisResult {
  version: string;
  completedAt: string;
  stage1: Stage1Result;
  stage2: Stage2Result;
  stage3: Stage3Result;
  stage5: UnrelatednessResult;
}

export interface AnalysisRequest {
  password: string;
  personalInfo: PersonalInfoState;
}
