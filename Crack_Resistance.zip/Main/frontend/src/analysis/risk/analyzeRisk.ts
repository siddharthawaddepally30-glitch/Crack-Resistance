import { STARTER_COMMON_PASSWORDS, STARTER_DICTIONARY_TOKENS } from './dictionary';
import { analyzePatternRules } from '../patterns/analyzePatternRules';
import type { FeatureVector, RiskLevel, RiskSignal, Stage1Result } from '../types';

const clamp = (value: number, min: number, max: number) => Math.min(max, Math.max(min, value));

function longestSequentialRun(value: string): number {
  if (value.length < 2) return value.length;
  let best = 1;
  let current = 1;
  for (let i = 1; i < value.length; i += 1) {
    const diff = value.charCodeAt(i) - value.charCodeAt(i - 1);
    if (Math.abs(diff) === 1) current += 1;
    else current = 1;
    best = Math.max(best, current);
  }
  return best;
}

function longestRepeatedRun(value: string): number {
  let best = value.length ? 1 : 0;
  let current = best;
  for (let i = 1; i < value.length; i += 1) {
    if (value[i] === value[i - 1]) current += 1;
    else current = 1;
    best = Math.max(best, current);
  }
  return best;
}

function longestRepeatedBlock(value: string): number {
  for (let size = Math.floor(value.length / 2); size >= 2; size -= 1) {
    for (let start = 0; start + size * 2 <= value.length; start += 1) {
      if (value.slice(start, start + size) === value.slice(start + size, start + size * 2)) return size;
    }
  }
  return 0;
}

function tokenize(password: string): string[] {
  return password
    .split(/[^A-Za-z]+/)
    .map((token) => token.toLowerCase())
    .filter((token) => token.length >= 3);
}

function normalizeCommonSubstitutions(value: string): string {
  return value.toLowerCase().replace(/@/g, 'a').replace(/[4]/g, 'a').replace(/[3]/g, 'e').replace(/[1!]/g, 'i').replace(/0/g, 'o').replace(/[$5]/g, 's').replace(/7/g, 't');
}

function getFeatures(password: string): FeatureVector {
  const unique = new Set(password).size;
  const tokens = tokenize(password);
  const normalized = normalizeCommonSubstitutions(password);
  const dictionaryTokenCount = tokens.filter((token) => STARTER_DICTIONARY_TOKENS.has(token)).length;
  const dateLike = /(?:\d{1,2}[-/.]){1,2}\d{2,4}|\d{6,8}/.test(password);
  const yearLike = /(?:19|20)\d{2}/.test(password);
  const keyboard = /(?:qwe|wer|ert|rty|tyu|yui|uio|iop|asd|sdf|dfg|fgh|ghj|hjk|jkl|zxc|xcv|cvb|vbn|bnm|123|234|345|456|567|678|789)/i.test(password);
  const transformations = (password.match(/[a@4e3i1o0s$5t7]/gi) || []).length > 2 && normalized !== password.toLowerCase() ? 1 : 0;
  const predictableSuffix = /(?:19|20)\d{2}|(?:[!@#$%^&*])+$|(?:123|1234|01|12|99)$/i.test(password);
  const predictablePrefix = /^(?:19|20)\d{2}|^(?:123|1234|01|12|99)/i.test(password);
  const classes = [/[a-z]/i.test(password), /\d/.test(password), /[^A-Za-z0-9]/.test(password)].filter(Boolean).length;

  return {
    length: password.length,
    lowercaseCount: (password.match(/[a-z]/g) || []).length,
    uppercaseCount: (password.match(/[A-Z]/g) || []).length,
    digitCount: (password.match(/\d/g) || []).length,
    symbolCount: (password.match(/[^A-Za-z0-9]/g) || []).length,
    wordCount: tokens.length,
    uniqueCharacterRatio: password.length ? unique / password.length : 0,
    repeatedCharacterRun: longestRepeatedRun(password),
    repeatedBlockLength: longestRepeatedBlock(password),
    sequentialRun: longestSequentialRun(password),
    dictionaryTokenCount,
    hasDateLikeStructure: dateLike,
    hasYearLikeStructure: yearLike,
    hasKeyboardPattern: keyboard,
    transformationCount: transformations,
    hasPredictableSuffix: predictableSuffix,
    hasPredictablePrefix: predictablePrefix,
    hasOnlyOneCharacterClass: classes <= 1,
  };
}

function classify(score: number): RiskLevel {
  if (score >= 80) return 'critical';
  if (score >= 60) return 'high';
  if (score >= 35) return 'medium';
  return 'low';
}

function addSignal(signals: RiskSignal[], id: string, label: string, level: RiskLevel, explanation: string, action: string) {
  signals.push({ id, label, level, explanation, action });
}

export function analyzeRisk(password: string): Stage1Result {
  const normalized = password.toLowerCase();
  const normalizedBase = normalizeCommonSubstitutions(password);
  const features = getFeatures(password);
  const patterns = analyzePatternRules(password);
  const signals: RiskSignal[] = [];
  let score = 0;

  const exactCommon = STARTER_COMMON_PASSWORDS.has(normalized);
  const normalizedCommon = STARTER_COMMON_PASSWORDS.has(normalizedBase) && !exactCommon;

  if (exactCommon) {
    score += 60;
    addSignal(signals, 'common-password', 'Known common password', 'critical', 'This exact password is in the current common-password list.', 'Treat this as unsafe. Do not rely on small edits to the same base word.');
  } else if (normalizedCommon) {
    score += 48;
    addSignal(signals, 'common-base', 'Common word after simple substitutions', 'critical', 'Changing letters into numbers or symbols still leaves a common base word.', 'Do not depend on substitutions such as @, 3, 1 or 0 to make a common word hard to guess.');
  } else if (features.dictionaryTokenCount > 0) {
    score += 24;
    addSignal(signals, 'dictionary-token', 'Common word is visible', 'high', 'At least one familiar dictionary word is part of the password.', 'A word from a common vocabulary gives an attacker a useful starting point.');
  }

  if (features.length < 8) {
    score += 32;
    addSignal(signals, 'short-length', 'Too short', 'critical', `The password is only ${features.length} characters long.`, 'Length is a major weakness here. Use a much longer passphrase instead of adding one symbol to a short word.');
  } else if (features.length < 12) {
    score += 20;
    addSignal(signals, 'short-length', 'Short password', 'high', `The password has ${features.length} characters.`, 'More length would give the password more room for an unpredictable structure.');
  } else if (features.length < 16) {
    score += 8;
  }

  if (features.hasDateLikeStructure) {
    score += 22;
    addSignal(signals, 'date-structure', 'Date-like numbers', 'high', 'The number block looks like a date.', 'Dates are useful attacker guesses, especially when they are connected to the owner.');
  } else if (features.hasYearLikeStructure) {
    score += 17;
    addSignal(signals, 'year-structure', 'Year at a glance', 'high', 'The password contains a four-digit year.', 'A year is a predictable number choice. Avoid using meaningful years as a password component.');
  }

  if (features.repeatedCharacterRun >= 3 || features.repeatedBlockLength >= 2) {
    score += 14;
    addSignal(signals, 'repetition', 'Repeated characters or block', 'high', 'Part of the password repeats in a simple way.', 'Repeating a piece does not add much new uncertainty.');
  }

  if (features.sequentialRun >= 3 || patterns.some((p) => p.id === 'sequence')) {
    score += 15;
    addSignal(signals, 'sequence', 'Easy sequence', 'high', 'Characters move in a simple forward or backward sequence.', 'Avoid predictable runs such as consecutive letters or numbers.');
  }

  if (features.hasKeyboardPattern || patterns.some((p) => p.id === 'keyboard')) {
    score += 15;
    addSignal(signals, 'keyboard', 'Keyboard path', 'high', 'The characters follow a familiar keyboard movement.', 'A keyboard pattern looks random to a person but is easy to model.');
  }

  if (features.transformationCount > 0 || patterns.some((p) => p.id === 'leet-substitution')) {
    score += 12;
    addSignal(signals, 'transformation', 'Predictable letter swaps', 'medium', 'Common substitutions change the look of a word without changing its base structure.', 'Do not count common substitutions as your main source of security.');
  }

  if (features.hasPredictableSuffix || features.hasPredictablePrefix) {
    score += 10;
    addSignal(signals, 'predictable-position', 'Predictable number or symbol position', 'medium', 'A common number, year or symbol block is placed where password patterns often put it.', 'Changing only the ending or beginning is unlikely to remove the main pattern.');
  }

  if (features.hasOnlyOneCharacterClass) {
    score += 12;
    addSignal(signals, 'single-class', 'Only one character type', 'medium', 'The password uses only letters, only numbers, or only symbols.', 'Mixing character types can help, but length and unpredictability matter more than variety alone.');
  }

  if (features.length >= 16 && features.uniqueCharacterRatio >= 0.75 && signals.length <= 1) {
    score -= 8;
  }

  score = clamp(Math.round(score), 0, 100);
  const topSignals = signals.sort((a, b) => {
    const weight: Record<RiskLevel, number> = { critical: 4, high: 3, medium: 2, low: 1 };
    return weight[b.level] - weight[a.level];
  }).slice(0, 8);

  return {
    riskLevel: classify(score),
    riskScore: score,
    signals: topSignals,
    features,
    dictionaryMatch: exactCommon || normalizedCommon,
    datasetStatus: 'starter-lexicon',
  };
}
