interface UnrelatednessModelArtifact { status: 'trained'; model_version: string; vocabulary: Record<string, number>; idf: number[]; coefficients: number[][]; intercept: number[]; accuracy: number; }
let cache: UnrelatednessModelArtifact | null | undefined;
function ngrams(text: string, min = 2, max = 5) { const out: string[] = []; const value = text.toLowerCase(); for (let n = min; n <= max; n += 1) for (let i = 0; i + n <= value.length; i += 1) out.push(value.slice(i, i + n)); return out; }
export async function predictRelatedness(left: string, right: string) {
  if (cache === undefined) { try { const r = await fetch('/ml/unrelatedness_model.json', { cache: 'force-cache' }); cache = r.ok ? await r.json() as UnrelatednessModelArtifact : null; } catch { cache = null; } }
  if (!cache) return null;
  const counts = new Map<string, number>(); for (const gram of ngrams(`${left} | ${right}`)) counts.set(gram, (counts.get(gram) ?? 0) + 1);
  const vector = new Array(cache.idf.length).fill(0); counts.forEach((count, gram) => { const i = cache?.vocabulary[gram]; if (i !== undefined) vector[i] = count * (cache?.idf[i] ?? 1); });
  const norm = Math.sqrt(vector.reduce((s, v) => s + v * v, 0)) || 1; const z = cache.coefficients[0].reduce((s, w, i) => s + w * (vector[i] / norm), cache.intercept[0]); const p = 1 / (1 + Math.exp(-Math.max(-30, Math.min(30, z))));
  return { relatedProbability: p, unrelatedProbability: 1 - p, modelVersion: cache.model_version, trainingAccuracy: cache.accuracy };
}
export async function getUnrelatednessModelStatus() { if (cache === undefined) await predictRelatedness('', ''); return { status: cache ? 'trained' as const : 'not-trained' as const, modelVersion: cache?.model_version ?? null, accuracy: cache?.accuracy ?? null }; }
