export type PersonalRelationshipLabel = 'direct' | 'derived' | 'abbreviation' | 'mnemonic' | 'semantic' | 'unrelated';

export interface PersonalModelSignal { status: 'not-trained' | 'trained'; modelVersion: string | null; purpose: 'semantic-and-contextual-analysis'; }
export interface PersonalRelationshipPrediction { label: PersonalRelationshipLabel; confidence: number; modelVersion: string; }

interface PersonalModelArtifact {
  status: 'trained'; model_version: string; classes: PersonalRelationshipLabel[]; vocabulary: Record<string, number>;
  idf: number[]; coefficients: number[][]; intercept: number[]; accuracy: number; macro_f1: number;
}
interface Lexicon { abbreviations: Record<string, string[]>; semantic: Record<string, string[]>; mnemonics: Record<string, string[]>; version: string; }
let modelCache: PersonalModelArtifact | null | undefined;
let lexiconCache: Lexicon | null | undefined;

function ngrams(text: string, min = 2, max = 5) {
  const value = text.toLowerCase();
  const out: string[] = [];
  for (let n = min; n <= max; n += 1) for (let i = 0; i + n <= value.length; i += 1) out.push(value.slice(i, i + n));
  return out;
}
function vectorise(left: string, right: string, model: PersonalModelArtifact) {
  const counts = new Map<string, number>();
  for (const gram of ngrams(`${left} | ${right}`)) counts.set(gram, (counts.get(gram) ?? 0) + 1);
  const vector = new Array(model.idf.length).fill(0);
  counts.forEach((count, gram) => { const index = model.vocabulary[gram]; if (index !== undefined) vector[index] = count * model.idf[index]; });
  const norm = Math.sqrt(vector.reduce((sum, value) => sum + value * value, 0)) || 1;
  return vector.map((value) => value / norm);
}
async function loadModel() {
  if (modelCache !== undefined) return modelCache;
  try { const r = await fetch('/ml/personal_relationship_model.json', { cache: 'force-cache' }); if (!r.ok) return (modelCache = null); const m = await r.json() as PersonalModelArtifact; return (modelCache = m.status === 'trained' ? m : null); } catch { return (modelCache = null); }
}
async function loadLexicon() {
  if (lexiconCache !== undefined) return lexiconCache;
  try { const r = await fetch('/ml/relationship_lexicon.json', { cache: 'force-cache' }); if (!r.ok) return (lexiconCache = null); return (lexiconCache = await r.json() as Lexicon); } catch { return (lexiconCache = null); }
}
export async function getPersonalLexicon() { return loadLexicon(); }
export async function predictPersonalRelationship(left: string, right: string): Promise<PersonalRelationshipPrediction | null> {
  const model = await loadModel();
  if (!model) return null;
  const vector = vectorise(left, right, model);
  const logits = model.coefficients.map((weights, row) => weights.reduce((sum, weight, index) => sum + weight * vector[index], model.intercept[row] || 0));
  const max = Math.max(...logits); const exps = logits.map((v) => Math.exp(v - max)); const total = exps.reduce((sum, v) => sum + v, 0) || 1;
  const probabilities = exps.map((v) => v / total); const best = probabilities.reduce((idx, v, i) => v > probabilities[idx] ? i : idx, 0);
  return { label: model.classes[best], confidence: probabilities[best], modelVersion: model.model_version };
}
export async function scorePersonalModel(): Promise<PersonalModelSignal> { const model = await loadModel(); return { status: model ? 'trained' : 'not-trained', modelVersion: model?.model_version ?? null, purpose: 'semantic-and-contextual-analysis' }; }
export async function getPersonalModelStatus() { return scorePersonalModel(); }
