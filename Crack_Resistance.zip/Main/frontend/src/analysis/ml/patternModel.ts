export type PatternModelLabel =
  | 'capitalized_word' | 'lowercase_word' | 'uppercase_word' | 'leet_substitution' | 'year' | 'date'
  | 'number_sequence' | 'alpha_sequence' | 'keyboard' | 'repetition' | 'repeated_block'
  | 'word_number' | 'word_symbol' | 'word_number_symbol' | 'word_year_symbol' | 'word_symbol_number_sequence'
  | 'number_word' | 'word_word' | 'word_word_number' | 'numbers_only' | 'letters_only'
  | 'short_alpha_token' | 'abbreviation_like' | 'mnemonic_like' | 'mixed_separators' | 'long_digit_block'
  | 'common_suffix' | 'common_prefix' | 'camel_case' | 'symbol_wrapper';

interface PatternModelArtifact {
  status: 'trained';
  model_version: string;
  labels: PatternModelLabel[];
  feature_count: number;
  mean: number[];
  scale: number[];
  coefficients: number[][];
  intercepts: number[];
  micro_f1: number;
}

let cached: PatternModelArtifact | null | undefined;

const NUM_SEQ = /(?:0123|1234|2345|3456|4567|5678|6789|7890|0987|9876|8765|7654|6543|5432|4321|3210|012|123|234|345|456|567|678|789|890|987|876|765|654|543|432|321|210)/;
const ALPHA_SEQ = /(?:abcd|bcde|cdef|defg|efgh|fghi|ghij|hijk|ijkl|jklm|klmn|lmno|mnop|nopq|opqr|pqrs|qrst|rstu|stuv|tuvw|uvwx|vwxy|wxyz|zyxw|yxwv|xwvu|wvut|vuts|utsr|tsrq|srqp|rqpo|qpon|ponm|onml|nmlk|mlkj|lkji|kjih|jihg|ihgf|hgfe|gfed|fedc|edcb|dcba)/i;
const KEYBOARD = /(?:qwerty|qwert|werty|asdfghjkl|asdfgh|asdf|zxcvbn|zxcvb|zxcv|qaz|wsx|edc|rfv|tgb|yhn|ujm|qwe|wer|ert|rty|tyu|yui|uio|iop|asd|sdf|dfg|fgh|ghj|hjk|jkl|zxc|xcv|cvb|vbn|bnm)/i;
const LEET = /[a@4][s$5][s$5]|[e3][l1][i1][t7]|[a@4].*[e3]|[o0].*[a@4]/i;
const DATE_RE = /(?:\d{1,2}[-/.]){1,2}\d{2,4}|\d{6,8}/;
const YEAR_RE = /(?:19|20)\d{2}/;

function longestRepeat(s: string) {
  let best = 0; let cur = 0; let prev = '';
  for (const char of s) { cur = char === prev ? cur + 1 : 1; prev = char; best = Math.max(best, cur); }
  return best;
}
function longestBlock(s: string) {
  for (let size = Math.floor(s.length / 2); size >= 2; size -= 1) {
    for (let i = 0; i + size * 2 <= s.length; i += 1) if (s.slice(i, i + size) === s.slice(i + size, i + size * 2)) return size;
  }
  return 0;
}
function longestSequence(s: string) {
  if (s.length < 2) return s.length;
  let best = 1; let cur = 1;
  for (let i = 1; i < s.length; i += 1) { cur = Math.abs(s.charCodeAt(i) - s.charCodeAt(i - 1)) === 1 ? cur + 1 : 1; best = Math.max(best, cur); }
  return best;
}

export function extractPatternFeatures(password: string): number[] {
  const alpha = password.match(/[A-Za-z]+/g) ?? [];
  const digits = password.match(/\d+/g) ?? [];
  const symbols = password.match(/[^A-Za-z0-9]+/g) ?? [];
  const firstAlpha = alpha[0] ?? '';
  const num = digits[digits.length - 1] ?? '';
  const letters = (password.match(/[A-Za-z]/g) ?? []).length;
  const nums = (password.match(/\d/g) ?? []).length;
  const syms = password.length - letters - nums;
  const classes = [/[A-Za-z]/.test(password), /\d/.test(password), /[^A-Za-z0-9]/.test(password)].filter(Boolean).length;
  const wordCount = alpha.filter((x) => x.length >= 2).length;
  return [
    password.length, letters, nums, syms, new Set(password).size / Math.max(1, password.length),
    /[a-z]/.test(password) ? 1 : 0, /[A-Z]/.test(password) ? 1 : 0, /\d/.test(password) ? 1 : 0, /[^A-Za-z0-9]/.test(password) ? 1 : 0,
    wordCount, alpha.length ? alpha.reduce((sum, x) => sum + x.length, 0) / alpha.length : 0, symbols.length,
    /^[0-9]+$/.test(password) ? 1 : 0, /^[A-Za-z]+$/.test(password) ? 1 : 0, /[A-Z][a-z]+/.test(password) ? 1 : 0,
    NUM_SEQ.test(password) ? 1 : 0, ALPHA_SEQ.test(password) ? 1 : 0, KEYBOARD.test(password) ? 1 : 0, LEET.test(password) ? 1 : 0,
    YEAR_RE.test(password) ? 1 : 0, DATE_RE.test(password) ? 1 : 0,
    longestRepeat(password) >= 3 ? 1 : 0, longestBlock(password) >= 2 ? 1 : 0, longestSequence(password) >= 3 ? 1 : 0,
    /[A-Za-z]{3,}\d+$/.test(password) ? 1 : 0, /[A-Za-z]{3,}[^A-Za-z0-9]+$/.test(password) ? 1 : 0,
    /[A-Za-z]{3,}\d+[^A-Za-z0-9]+$/.test(password) ? 1 : 0, /[A-Za-z]{3,}(?:19|20)\d{2}[^A-Za-z0-9]+$/.test(password) ? 1 : 0,
    /^\d+[A-Za-z]{3,}$/.test(password) ? 1 : 0, alpha.length >= 2 ? 1 : 0,
    /[A-Z]{2,}/.test(password) ? 1 : 0, alpha.some((x) => x.length >= 2 && x.length <= 4) ? 1 : 0,
    /[^A-Za-z0-9]{2,}/.test(password) ? 1 : 0, classes <= 1 ? 1 : 0,
    /(?:123|1234|01|12|99)[^A-Za-z0-9]*$/.test(password) ? 1 : 0,
    /^(?:123|1234|01|12|99)[A-Za-z]/.test(password) ? 1 : 0,
    /^[^A-Za-z0-9].*[^A-Za-z0-9]$/.test(password) ? 1 : 0,
    /[A-Z][a-z]+[A-Z][a-z]+/.test(password) ? 1 : 0,
    num.length >= 6 ? 1 : 0, firstAlpha ? 1 : 0,
  ];
}

async function loadModel(): Promise<PatternModelArtifact | null> {
  if (cached !== undefined) return cached;
  try {
    const response = await fetch('/ml/pattern_intelligence_model.json', { cache: 'force-cache' });
    if (!response.ok) return (cached = null);
    const model = (await response.json()) as PatternModelArtifact;
    return (cached = model.status === 'trained' ? model : null);
  } catch { return (cached = null); }
}

export async function predictPatterns(password: string) {
  const model = await loadModel();
  if (!model) return { predictions: [], modelVersion: null };
  const raw = extractPatternFeatures(password);
  const scaled = raw.map((value, i) => (value - model.mean[i]) / (model.scale[i] || 1));
  const sigmoid = (z: number) => 1 / (1 + Math.exp(-Math.max(-30, Math.min(30, z))));
  const predictions = model.labels.map((label, i) => ({ label, probability: sigmoid(model.coefficients[i].reduce((sum, weight, j) => sum + weight * scaled[j], model.intercepts[i])) }))
    .sort((a, b) => b.probability - a.probability);
  return { predictions, modelVersion: model.model_version };
}

export async function getPatternModelStatus() {
  const model = await loadModel();
  return { status: model ? 'trained' as const : 'not-trained' as const, modelVersion: model?.model_version ?? null };
}
