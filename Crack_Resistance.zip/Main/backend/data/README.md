# Crack Resistance ML data

The application does not use a machine-learning model for Stage 1 generic password risk scoring.

The ML datasets in `backend/data/ml/` are used by the later intelligence modules:

- Pattern Intelligence
- Personalized Guessability
- Personal Unrelatedness

See `backend/data/ml/README.md` for dataset sizes, model roles, provenance notes and evaluation limitations.

Do not put real user passwords into this directory. These files are project training fixtures.
