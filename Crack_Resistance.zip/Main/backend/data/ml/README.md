# Crack Resistance ML Training Data

This directory contains the project-owned training fixtures for the three new intelligence layers.

## Dataset sizes

- `pattern_training.csv`: 160,000 labelled password-construction examples.
- `personal_relationship_training.csv`: 180,000 labelled password-fragment/personal-term relationships.
- `unrelatedness_training.csv`: 140,000 labelled related/unrelated concept pairs.
- `relationship_lexicon.json`: curated abbreviation, semantic-relation and mnemonic seeds used both for training-data expansion and high-confidence browser-side evidence.

The training data is deliberately generated from many templates and permutations so that each model sees varied examples rather than a tiny hand-written list.

## Important limitation

The generated datasets are **project training fixtures**, not a representation of the world's passwords or a claim about real attacker datasets. The application combines these models with deterministic, explainable rules and conservative confidence thresholds.

The reported holdout metrics are useful for checking that the training pipeline works, but they are not proof of real-world accuracy. New, independent datasets should be used for a stronger evaluation before making claims about production-grade performance.

## Models

- `pattern_intelligence_model.json` uses a balanced multilabel classifier over engineered password-structure features.
- `personal_relationship_model.json` uses character n-gram TF-IDF with a multiclass classifier for direct, derived, abbreviation, mnemonic, semantic and unrelated relationships.
- `unrelatedness_model.json` uses character n-gram TF-IDF with a binary related/unrelated classifier.
