from __future__ import annotations
import argparse,csv,json,random
from pathlib import Path
import numpy as np
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import f1_score
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler
from .pattern_features import LABELS, extract_pattern_features

def read_rows(path):
    with path.open(encoding='utf-8') as f: return list(csv.DictReader(f))

def train(input_path: Path, output: Path):
    rows=read_rows(input_path)
    # Use up to 120k rows for the balanced per-label training pool.
    random.Random(42).shuffle(rows); rows=rows[:120000]
    X_all=np.asarray([extract_pattern_features(r['text']) for r in rows],dtype=float)
    labels=np.asarray([r['label'] for r in rows])
    scaler=StandardScaler(); X_all=scaler.fit_transform(X_all)
    coefficients=[]; intercepts=[]; metrics={}
    for label in LABELS:
        pos_idx=np.where(labels==label)[0].tolist(); neg_idx=np.where(labels!=label)[0].tolist()
        rng=random.Random(hash(label)&0xffffffff); rng.shuffle(pos_idx); rng.shuffle(neg_idx)
        n=min(3500,len(pos_idx),len(neg_idx))
        idx=pos_idx[:n]+neg_idx[:n]
        y=np.asarray([1]*n+[0]*n)
        X=X_all[idx]
        Xtr,Xte,ytr,yte=train_test_split(X,y,test_size=.2,random_state=42,stratify=y)
        model=LogisticRegression(max_iter=1000, solver='liblinear', class_weight='balanced', random_state=42, C=0.7)
        model.fit(Xtr,ytr); pred=model.predict(Xte); f1=float(f1_score(yte,pred))
        coefficients.append(model.coef_[0].astype(float).tolist()); intercepts.append(float(model.intercept_[0])); metrics[label]={'f1':f1,'training_examples':2*n}
    mean=scaler.mean_.astype(float).tolist(); scale=scaler.scale_.astype(float).tolist()
    artifact={'status':'trained','model_version':'1.2.0-pattern-balanced-logreg','labels':LABELS,'feature_count':int(X_all.shape[1]),'mean':mean,
    'scale':scale,'coefficients':coefficients,'intercepts':intercepts,'metrics':metrics,'micro_f1':float(np.mean([m['f1'] for m in metrics.values()])),
    'training_entries':len(rows),'source_dataset_entries':sum(1 for _ in open(input_path,encoding='utf-8'))-1}
    output.parent.mkdir(parents=True,exist_ok=True); output.write_text(json.dumps(artifact),encoding='utf-8')
    print('mean_f1',artifact['micro_f1']); print('weakest',sorted(metrics.items(),key=lambda x:x[1]['f1'])[:8])

if __name__=='__main__':
    p=argparse.ArgumentParser(); p.add_argument('input',type=Path); p.add_argument('--output',type=Path,default=Path('frontend/public/ml/pattern_intelligence_model.json'));
    a=p.parse_args(); train(a.input,a.output)
