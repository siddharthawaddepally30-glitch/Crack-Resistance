from __future__ import annotations
import argparse,csv,json,re
from pathlib import Path
import numpy as np
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.linear_model import SGDClassifier
from sklearn.metrics import accuracy_score, f1_score, classification_report
from sklearn.model_selection import train_test_split

CLASSES=['direct','derived','abbreviation','mnemonic','semantic','unrelated']

def read_rows(path):
    with path.open(encoding='utf-8') as f: yield from csv.DictReader(f)

def train(inp,out):
    rows=list(read_rows(inp));
    if len(rows)>90000:
        import random
        random.Random(42).shuffle(rows)
        rows=rows[:90000]
    texts=[f"{r['left']} | {r['right']}" for r in rows]; y=[r['label'] for r in rows]
    tr,te,yt,ye=train_test_split(range(len(rows)),y,test_size=.2,random_state=42,stratify=y)
    vec=TfidfVectorizer(analyzer='char',ngram_range=(2,5),min_df=2,max_features=10000,sublinear_tf=True,lowercase=True)
    X=vec.fit_transform(texts); Xt=X[tr]; Xe=X[te]
    model=SGDClassifier(loss='log_loss', max_iter=120, tol=1e-3, class_weight='balanced', random_state=42, early_stopping=True, validation_fraction=0.1, n_iter_no_change=5).fit(Xt, np.asarray(yt))
    pred=model.predict(Xe)
    acc=float(accuracy_score(ye,pred)); f1=float(f1_score(ye,pred,average='macro'))
    print(classification_report(ye,pred,zero_division=0))
    artifact={'status':'trained','model_version':'1.0.1-personal-relationship-char-sgd','classes':[str(x) for x in model.classes_.tolist()],'vocabulary':{str(k):int(v) for k,v in vec.vocabulary_.items()},'idf':vec.idf_.tolist(),'coefficients':model.coef_.tolist(),'intercept':model.intercept_.tolist(),'accuracy':acc,'macro_f1':f1,'training_entries':len(rows)}
    out.parent.mkdir(parents=True,exist_ok=True); out.write_text(json.dumps(artifact),encoding='utf-8')
    print('accuracy',acc,'macro_f1',f1,'features',len(vec.vocabulary_))

if __name__=='__main__':
    p=argparse.ArgumentParser(); p.add_argument('input',type=Path); p.add_argument('--output',type=Path,default=Path('frontend/public/ml/personal_relationship_model.json')); a=p.parse_args(); train(a.input,a.output)
