from __future__ import annotations
import json, math, re
from pathlib import Path

MODEL_PATH=Path(__file__).resolve().parents[2]/'models'/'personal_relationship_model.json'
_CACHE=None

def _ngrams(text,nmin=2,nmax=5):
    text=text.lower()
    for n in range(nmin,nmax+1):
        for i in range(len(text)-n+1): yield text[i:i+n]

def _vector(left,right,model):
    text=f'{left} | {right}'.lower()
    counts={}
    for gram in _ngrams(text): counts[gram]=counts.get(gram,0)+1
    v=[0.0]*len(model['idf'])
    for gram,c in counts.items():
        idx=model['vocabulary'].get(gram)
        if idx is not None: v[idx]=c*model['idf'][idx]
    norm=math.sqrt(sum(x*x for x in v)) or 1.0
    return [x/norm for x in v]

def predict_pair(left,right):
    global _CACHE
    if _CACHE is None:
        if not MODEL_PATH.exists(): return None
        _CACHE=json.loads(MODEL_PATH.read_text())
    v=_vector(left,right,_CACHE)
    logits=[]
    for w,b in zip(_CACHE['coefficients'],_CACHE['intercept']): logits.append(sum(a*x for a,x in zip(w,v))+b)
    m=max(logits); ex=[math.exp(x-m) for x in logits]; s=sum(ex) or 1.0; probs=[x/s for x in ex]
    i=max(range(len(probs)),key=probs.__getitem__)
    return {'label':_CACHE['classes'][i],'confidence':probs[i],'modelVersion':_CACHE['model_version']}
