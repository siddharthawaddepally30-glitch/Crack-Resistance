from __future__ import annotations
import argparse,csv,json
from pathlib import Path
import numpy as np
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.linear_model import SGDClassifier
from sklearn.metrics import accuracy_score,classification_report
from sklearn.model_selection import train_test_split

def rows(path):
  with path.open(encoding='utf-8') as f: yield from csv.DictReader(f)

def train(inp,out):
  rs=list(rows(inp))
  if len(rs)>90000:
    import random
    random.Random(42).shuffle(rs)
    rs=rs[:90000]
  texts=[f"{r['left']} | {r['right']}" for r in rs]
  y=np.asarray([int(r['related']) for r in rs])
  tr,te=train_test_split(np.arange(len(rs)),test_size=.2,random_state=42,stratify=y)
  vec=TfidfVectorizer(analyzer='char',ngram_range=(2,5),min_df=2,max_features=9000,sublinear_tf=True,lowercase=True)
  X=vec.fit_transform(texts)
  model=SGDClassifier(loss='log_loss', max_iter=120, tol=1e-3, class_weight='balanced', random_state=42, early_stopping=True, validation_fraction=0.1, n_iter_no_change=5).fit(X[tr],y[tr])
  pred=model.predict(X[te]); acc=float(accuracy_score(y[te],pred)); print(classification_report(y[te],pred,zero_division=0))
  art={'status':'trained','model_version':'1.0.1-unrelatedness-char-sgd','vocabulary':{str(k):int(v) for k,v in vec.vocabulary_.items()},
       'idf':vec.idf_.astype(float).tolist(),'coefficients':model.coef_.astype(float).tolist(),'intercept':model.intercept_.astype(float).tolist(),'accuracy':acc,'training_entries':len(rs)}
  out.parent.mkdir(parents=True,exist_ok=True); out.write_text(json.dumps(art),encoding='utf-8'); print('accuracy',acc,'features',len(vec.vocabulary_))
if __name__=='__main__':
  p=argparse.ArgumentParser(); p.add_argument('input',type=Path); p.add_argument('--output',type=Path,default=Path('frontend/public/ml/unrelatedness_model.json'));
  a=p.parse_args(); train(a.input,a.output)
