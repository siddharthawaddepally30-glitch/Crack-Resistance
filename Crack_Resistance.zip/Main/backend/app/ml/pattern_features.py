from __future__ import annotations
import re

NUM_SEQ = re.compile(r'(?:0123|1234|2345|3456|4567|5678|6789|7890|0987|9876|8765|7654|6543|5432|4321|3210|012|123|234|345|456|567|678|789|890|987|876|765|654|543|432|321|210)')
ALPHA_SEQ = re.compile(r'(?:abcd|bcde|cdef|defg|efgh|fghi|ghij|hijk|ijkl|jklm|klmn|lmno|mnop|nopq|opqr|pqrs|qrst|rstu|stuv|tuvw|uvwx|vwxy|wxyz|zyxw|yxwv|xwvu|wvut|vuts|utsr|tsrq|srqp|rqpo|qpon|ponm|onml|nmlk|mlkj|lkji|kjih|jihg|ihgf|hgfe|gfed|fedc|edcb|dcba)', re.I)
KEYBOARD = re.compile(r'(?:qwerty|qwert|werty|asdfghjkl|asdfgh|asdf|zxcvbn|zxcvb|zxcv|qaz|wsx|edc|rfv|tgb|yhn|ujm|qwe|wer|ert|rty|tyu|yui|uio|iop|asd|sdf|dfg|fgh|ghj|hjk|jkl|zxc|xcv|cvb|vbn|bnm)', re.I)
LEET = re.compile(r'[a@4][s$5][s$5]|[e3][l1][i1][t7]|[a@4].*[e3]|[o0].*[a@4]', re.I)
DATE_RE = re.compile(r'(?:\d{1,2}[-/.]){1,2}\d{2,4}|\d{6,8}')
YEAR_RE = re.compile(r'(?:19|20)\d{2}')

LABELS = ['capitalized_word','lowercase_word','uppercase_word','leet_substitution','year','date','number_sequence','alpha_sequence','keyboard','repetition','repeated_block','word_number','word_symbol','word_number_symbol','word_year_symbol','word_symbol_number_sequence','number_word','word_word','word_word_number','numbers_only','letters_only','short_alpha_token','abbreviation_like','mnemonic_like','mixed_separators','long_digit_block','common_suffix','common_prefix','camel_case','symbol_wrapper']


def longest_repeat(s: str) -> int:
    best=0; cur=0; prev=''
    for c in s:
        cur=cur+1 if c==prev else 1; prev=c; best=max(best,cur)
    return best


def longest_block(s: str) -> int:
    for n in range(len(s)//2,1,-1):
        for i in range(0,len(s)-2*n+1):
            if s[i:i+n]==s[i+n:i+2*n]: return n
    return 0


def longest_sequence(s: str) -> int:
    if len(s)<2: return len(s)
    best=cur=1
    for a,b in zip(s,s[1:]):
        if abs(ord(b)-ord(a))==1: cur+=1
        else: cur=1
        best=max(best,cur)
    return best


def extract_pattern_features(password: str) -> list[float]:
    alpha=re.findall(r'[A-Za-z]+',password)
    digits=re.findall(r'\d+',password)
    symbols=re.findall(r'[^A-Za-z0-9]+',password)
    first_alpha=alpha[0] if alpha else ''
    num=digits[-1] if digits else ''
    lower=password.lower()
    letters=sum(c.isalpha() for c in password); nums=sum(c.isdigit() for c in password); syms=len(password)-letters-nums
    classes=sum(bool(re.search(p,password)) for p in [r'[A-Za-z]',r'\d',r'[^A-Za-z0-9]'])
    word_count=len([x for x in alpha if len(x)>=2])
    sep_count=len(symbols)
    return [
        len(password),letters,nums,syms,len(set(password))/max(1,len(password)),
        float(bool(re.search(r'[a-z]',password))),float(bool(re.search(r'[A-Z]',password))),float(bool(re.search(r'\d',password))),float(bool(re.search(r'[^A-Za-z0-9]',password))),
        word_count, float(sum(map(len,alpha))/max(1,len(alpha))), sep_count,
        float(bool(re.fullmatch(r'[0-9]+',password))),float(bool(re.fullmatch(r'[A-Za-z]+',password))),
        float(bool(re.search(r'[A-Z][a-z]+',password))),
        float(bool(NUM_SEQ.search(password))),float(bool(ALPHA_SEQ.search(password))),float(bool(KEYBOARD.search(password))),float(bool(LEET.search(password))),
        float(bool(YEAR_RE.search(password))),float(bool(DATE_RE.search(password))),
        float(longest_repeat(password)>=3),float(longest_block(password)>=2),float(longest_sequence(password)>=3),
        float(bool(re.search(r'[A-Za-z]{3,}\d+$',password))),float(bool(re.search(r'[A-Za-z]{3,}[^A-Za-z0-9]+$',password))),
        float(bool(re.search(r'[A-Za-z]{3,}\d+[^A-Za-z0-9]+$',password))),float(bool(re.search(r'[A-Za-z]{3,}(?:19|20)\d{2}[^A-Za-z0-9]+$',password))),
        float(bool(re.search(r'^\d+[A-Za-z]{3,}$',password))),float(len(alpha)>=2),
        float(bool(re.search(r'[A-Z]{2,}',password))), float(any(len(x) in (2,3,4) for x in alpha)),
        float(bool(re.search(r'[^A-Za-z0-9]{2,}',password))),float(classes<=1),
        float(bool(re.search(r'(?:123|1234|01|12|99)[^A-Za-z0-9]*$',password))),
        float(bool(re.search(r'^(?:123|1234|01|12|99)[A-Za-z]',password))),
        float(bool(re.search(r'^[^A-Za-z0-9].*[^A-Za-z0-9]$',password))),
        float(bool(re.search(r'[A-Z][a-z]+[A-Z][a-z]+',password))),
        float(bool(num and len(num)>=6)), float(bool(first_alpha and first_alpha.lower()+'@' in lower)),
    ]
