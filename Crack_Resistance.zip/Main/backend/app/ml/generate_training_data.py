from __future__ import annotations
import csv, itertools, random, re
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
OUT = ROOT / 'data' / 'ml'
OUT.mkdir(parents=True, exist_ok=True)
R = random.Random(20261004)

WORDS = [
    'password','dragon','monkey','football','cricket','summer','winter','spring','autumn','welcome','shadow','sunshine','freedom','secret','master','hello','india','hyderabad','college','school','university','coding','programming','developer','gaming','gamer','minecraft','fortnite','valorant','anime','music','movies','camera','photography','bike','bikes','motorcycle','cars','racing','football','basketball','tennis','family','friend','friends','love','princess','computer','internet','purple','blue','black','red','green','coffee','travel','movie','book','books','reader','reading','cat','dog','tiger','lion','star','moon','earth','ocean','river','mountain','forest','summer','winter','pizza','coffee','chai','india','delhi','mumbai','hyderabad','chennai','kolkata','bangalore','telangana','engineering','computer','science','software','security','cyber','network','linux','android','iphone','samsung','google','apple','amazon','school','college','degree','branch','office','work','boss','team','captain','goal','keeper','striker','bat','wicket','ipl','fifa','manga','otaku','senpai','camera','lens','photo','artist','singer','song','beats','guitar','piano','book','novel','hero','villain','marvel','superman','batman','spiderman','naruto','onepiece','pokemon','mario','zelda','minecraft','creeper','nether','redstone','coding','python','java','flutter','react','node','firebase','supabase','database','doctor','teacher','engineer','manager','director','office','company','startup'
]
WORDS = list(dict.fromkeys(WORDS))
SEPARATORS = ['@','!','#','$','_','-','.','*']
YEARS = ['1998','1999','2000','2001','2002','2003','2004','2005','2006','2007','2008','2010','2012','2015','2020','2024','2025','2026']
NUMS = ['0','7','11','12','13','21','23','42','47','69','99','123','1234','321','4567','7890','0987']

PATTERNS = [
    'capitalized_word','lowercase_word','uppercase_word','leet_substitution','year','date','number_sequence','alpha_sequence','keyboard','repetition','repeated_block',
    'word_number','word_symbol','word_number_symbol','word_year_symbol','word_symbol_number_sequence','number_word','word_word','word_word_number','numbers_only','letters_only',
    'short_alpha_token','abbreviation_like','mnemonic_like','mixed_separators','long_digit_block','common_suffix','common_prefix','camel_case','symbol_wrapper'
]

def write_csv(path: Path, rows: list[dict], fields: list[str]):
    with path.open('w', newline='', encoding='utf-8') as f:
        w = csv.DictWriter(f, fieldnames=fields)
        w.writeheader(); w.writerows(rows)

# Pattern dataset: abundant, template-diverse, multi-label.
pattern_rows=[]
for _ in range(140000):
    w1,w2=R.sample(WORDS,2)
    sep=R.choice(SEPARATORS); year=R.choice(YEARS); num=R.choice(NUMS)
    kind=R.choice(PATTERNS)
    caps=lambda s: s[:1].upper()+s[1:]
    choices={
      'capitalized_word': caps(w1),
      'lowercase_word': w1,
      'uppercase_word': w1.upper(),
      'leet_substitution': w1.replace('a','4').replace('e','3').replace('i','1').replace('o','0').replace('s','5'),
      'year': year,
      'date': f"{R.randint(1,28):02d}{R.randint(1,12):02d}{R.randint(0,99):02d}",
      'number_sequence': R.choice(['123','1234','2345','4567','7890','0987','9876','3210']),
      'alpha_sequence': R.choice(['abc','abcd','bcde','wxyz','zyxw','fedc']),
      'keyboard': R.choice(['qwe','qwerty','asdf','asdfgh','zxc','zxcvb','qaz','wsx']),
      'repetition': w1[:max(2,min(4,len(w1)))]*3,
      'repeated_block': (w1[:3] if len(w1)>=3 else w1)*2,
      'word_number': w1+num,
      'word_symbol': w1+sep,
      'word_number_symbol': w1+num+sep,
      'word_year_symbol': caps(w1)+year+sep,
      'word_symbol_number_sequence': w1+sep+'1234',
      'number_word': num+w1,
      'word_word': w1+w2,
      'word_word_number': caps(w1)+w2+num,
      'numbers_only': num*R.choice([1,2]),
      'letters_only': w1+w2,
      'short_alpha_token': R.choice(['mc','am','cs','hyd','dev','bro','ily','bff','nyc','ipl']),
      'abbreviation_like': R.choice(['MC','AM','CS','HYD','NYC','SRK','IPL','FIFA','PC','PS5','UAE','USA']),
      'mnemonic_like': R.choice(['ILU','BFF','LOL','OMG','BRB','TTYL','IDK','DIY','FYI','ASAP','NVM']),
      'mixed_separators': w1+R.choice(['@#','_-','!@','$%'])+w2,
      'long_digit_block': ''.join(R.choice('0123456789') for _ in range(R.randint(6,10))),
      'common_suffix': w1+R.choice(['123','1234','01','12','99','!','@','2024','2025']),
      'common_prefix': R.choice(['123','01','12','99','!','@','2024'])+w1,
      'camel_case': caps(w1)+caps(w2),
      'symbol_wrapper': sep+w1+sep,
    }
    pattern_rows.append({'text':choices[kind],'label':kind})
# Add hard negatives / natural strings that can activate several rules.
for _ in range(20000):
    text=R.choice(WORDS)+R.choice(['']+[R.choice(SEPARATORS)])+R.choice(WORDS)
    pattern_rows.append({'text':text,'label':R.choice(['word_word','word_symbol','lowercase_word','camel_case'])})
write_csv(OUT/'pattern_training.csv', pattern_rows, ['text','label'])

# Relationship lexicon. Curated seeds are intentionally broad; data is expanded below.
ABBREVIATIONS = {
 'minecraft':['mc'],'football':['fb'],'basketball':['bb'],'cricket':['cric'],'photography':['photo','photog'],'photograph':['photo'],'developer':['dev'],'development':['dev'],'computer':['pc','comp'],'computer science':['cs'],'science':['sci'],'engineering':['eng'],'college':['clg'],'university':['uni'],'hyderabad':['hyd'],'bangalore':['blr'],'mumbai':['bom','mum'],'delhi':['del'],'india':['in'],'instagram':['ig'],'facebook':['fb'],'youtube':['yt'],'twitter':['x'],'telegram':['tg'],'whatsapp':['wa'],'birthday':['bday'],'brother':['bro'],'sister':['sis'],'family':['fam'],'friend':['frnd'],'friends':['frnds'],'girlfriend':['gf'],'boyfriend':['bf'],'mother':['mom','mum'],'father':['dad'],'photography':['photo'],'motorcycle':['mc','moto'],'motorbike':['moto'],'programming':['prog'],'python':['py'],'javascript':['js'],'typescript':['ts'],'react':['rn'],'database':['db'],'security':['sec'],'network':['net'],'password':['pw'],'information':['info'],'application':['app'],'administrator':['admin'],'manager':['mgr'],'doctor':['dr'],'mister':['mr'],'professor':['prof']
}
SEMANTIC = {
 'minecraft':['gaming','game','gamer','creeper','crafting','block','nether','redstone','sandbox'],
 'football':['soccer','fifa','goal','goals','striker','keeper','pitch','club','team','fc'],
 'cricket':['bat','bowler','wicket','ipl','runs','keeper','pitch'],
 'photography':['camera','lens','photo','photos','shutter','portrait','image'],
 'programming':['coding','code','developer','dev','software','python','java','javascript'],
 'music':['song','singer','artist','beats','guitar','piano','album','concert'],
 'anime':['manga','otaku','senpai','japan','cosplay','character'],
 'cars':['auto','vehicle','racing','drive','driver','motor','engine'],
 'bikes':['bike','motorcycle','rider','riding','helmet','moto'],
 'movies':['film','cinema','actor','actress','director','screen'],
 'books':['book','novel','reader','reading','author','library'],
 'college':['university','campus','degree','student','professor','class'],
 'school':['teacher','student','class','exam','homework'],
 'hyderabad':['hyd','telangana','charminar','deccan','city'],
 'india':['indian','delhi','mumbai','hyderabad','telangana','bharat'],
 'camera':['photography','photo','lens','shutter'],
 'python':['coding','programming','script','developer'],
 'flutter':['dart','mobile','android','ios','app'],
 'react':['javascript','frontend','web','ui','component'],
 'security':['cyber','password','network','privacy','defense'],
 'family':['mother','father','brother','sister','home'],
 'sports':['football','cricket','tennis','basketball','athlete'],
 'travel':['trip','tour','journey','flight','hotel','vacation'],
 'coffee':['chai','cafe','latte','espresso','drink'],
 'chai':['tea','coffee','cafe','drink'],
}
MNEMONICS = {
 'i love you':['ily'],'best friends forever':['bff'],'laugh out loud':['lol'],'oh my god':['omg'],'be right back':['brb'],'talk to you later':['ttyl'],'i dont know':['idk'],'do it yourself':['diy'],'for your information':['fyi'],'as soon as possible':['asap'],'never mind':['nvm'],'in my opinion':['imo'],'by the way':['btw'],'see you':['cu'],'take care':['tc']
}

semantic_pairs=[]
for left, rights in SEMANTIC.items():
    for right in rights:
        semantic_pairs.append((left,right))
        semantic_pairs.append((right,left))

# Build a broad pool for sampling negatives.
POOL=list(dict.fromkeys(WORDS+[x for x in ABBREVIATIONS]+[x for xs in ABBREVIATIONS.values() for x in xs]+[x for x in SEMANTIC]+[x for xs in SEMANTIC.values() for x in xs]+list(MNEMONICS)+[x for xs in MNEMONICS.values() for x in xs]))
POOL=list(dict.fromkeys(POOL))

rel_rows=[]
for _ in range(180000):
    label=R.choice(['direct','derived','abbreviation','mnemonic','semantic','unrelated'])
    if label=='direct':
        term=R.choice(POOL); left=term; right=R.choice([term, term.title(), term.upper(), term.replace('-','')]);
    elif label=='derived':
        base=R.choice([x for x in WORDS if len(x)>4]); left=base; right=R.choice([base+'1', base+'s', base+'2026', base.capitalize(), base.upper(), base.replace('a','4',1), base.replace('e','3',1)])
    elif label=='abbreviation':
        full, abbr=R.choice([(f,a) for f,aa in ABBREVIATIONS.items() for a in aa]); left=abbr; right=full
        if R.random()<0.35: left=left.upper()
    elif label=='mnemonic':
        phrase, abbr=R.choice(list(itertools.chain.from_iterable([[(p,a) for a in aa] for p,aa in MNEMONICS.items()]))); left=abbr; right=phrase
    elif label=='semantic':
        left,right=R.choice(semantic_pairs)
    else:
        left,right=R.sample(POOL,2)
    rel_rows.append({'left':left,'right':right,'label':label})
write_csv(OUT/'personal_relationship_training.csv', rel_rows, ['left','right','label'])

# Unrelatedness binary dataset. 1 means semantically related, 0 means unrelated.
unrel_rows=[]
for _ in range(140000):
    related=R.random()<0.5
    if related:
        left,right=R.choice(semantic_pairs)
        if R.random()<0.35: left=left.title()
    else:
        left,right=R.sample(POOL,2)
        # reject accidental known semantic pairs
        for _ in range(4):
            if (left,right) not in semantic_pairs and (right,left) not in semantic_pairs: break
            left,right=R.sample(POOL,2)
    unrel_rows.append({'left':left,'right':right,'related':int(related)})
write_csv(OUT/'unrelatedness_training.csv', unrel_rows, ['left','right','related'])

lexicon={
 'abbreviations':ABBREVIATIONS,
 'semantic':SEMANTIC,
 'mnemonics':MNEMONICS,
 'version':'1.0.0-curated-expanded'
}
import json
(OUT/'relationship_lexicon.json').write_text(json.dumps(lexicon,indent=2),encoding='utf-8')
print('generated', {p.name:p.stat().st_size for p in OUT.iterdir()})
