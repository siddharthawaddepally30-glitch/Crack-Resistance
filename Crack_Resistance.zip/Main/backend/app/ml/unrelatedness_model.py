from __future__ import annotations
import json,math
from pathlib import Path
MODEL_PATH=Path(__file__).resolve().parents[2]/'models'/'unrelatedness_model.json'; _CACHE=None

def grams(text,nmin=2,nmax=5):
  text=text.lower()
  for n in range(nmin,nmax+1):
    for i in range(len(text)-n+1): yield text[i:i+n]

def predict(left,right):
  global _CACHE
  if _CACHE is None:
    if not MODEL_PATH.exists(): return None
    _CACHE=json.loads(MODEL_PATH.read_text())
  text=f'{left} | {right}'.lower(); counts={}
  for g in grams(text): counts[g]=counts.get(g,0)+1
  v=[0.0]*len(_CACHE['idf'])
  for g,c in counts.items():
    i=_CACHE['vocabulary'].get(g)
    if i is not None:v[i]=c*_CACHE['idf'][i]
  norm=math.sqrt(sum(x*x for x in v)) or 1.0; v=[x/norm for x in v]
  z=sum(a*b for a,b in zip(_CACHE['coefficients'][0],v))+_CACHE['intercept'][0]
  p=1/(1+math.exp(-z)); return {'relatedProbability':p,'unrelatedProbability':1-p,'modelVersion':_CACHE['model_version']}
