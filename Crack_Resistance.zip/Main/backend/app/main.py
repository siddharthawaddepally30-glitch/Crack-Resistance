"""Crack Resistance Backend API
FastAPI foundation for password security & targeted guessability analysis.
"""

from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware

app = FastAPI(
    title="Crack Resistance API",
    description="Password Intelligence & Targeted Guessability Analysis Engine",
    version="1.0.0",
)

# Configure CORS for local development
app.add_middleware(
    CORSMiddleware,
    allow_origins=["http://localhost:5173", "http://127.0.0.1:5173"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

@app.get("/")
def read_root():
    return {
        "status": "online",
        "service": "Crack Resistance API",
        "version": "1.0.0",
        "privacy": "Zero persistent storage policy active. In-memory ephemeral processing only."
    }

@app.get("/health")
def health_check():
    return {
        "status": "healthy",
        "timestamp": True
    }
